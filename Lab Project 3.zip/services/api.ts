// API Service for MediLab India Frontend with Immediate Offline Detection
const API_BASE_URL = process.env.NODE_ENV === 'production' 
  ? '/api' 
  : 'http://localhost:3001/api';

const REQUEST_TIMEOUT = 2000; // Reduced to 2 seconds for faster detection
const DEVELOPMENT_MODE = process.env.NODE_ENV === 'development';

export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
}

// Mock data for offline mode
const MOCK_DATA = {
  users: [
    {
      id: '1',
      username: 'superadmin',
      role: 'super_admin',
      name: 'Super Administrator',
      email: 'admin@medilab-india.com',
      phone: '+91 9876543210',
      isActive: true,
      createdAt: '2024-01-01T00:00:00Z',
      lastLogin: new Date().toISOString()
    },
    {
      id: '2',
      username: 'testcenter',
      role: 'diagnostic_center',
      name: 'Dr. Rajesh Kumar',
      email: 'testcenter@medilab-india.com',
      phone: '+91 9876543212',
      centerId: '1',
      centerName: 'MediLab Test Center',
      isActive: true,
      createdAt: '2024-01-01T00:00:00Z',
      lastLogin: new Date().toISOString()
    },
    {
      id: '3',
      username: 'patient',
      role: 'patient',
      name: 'Priya Sharma',
      email: 'patient@medilab-india.com',
      phone: '+91 9876543215',
      isActive: true,
      createdAt: '2024-01-01T00:00:00Z',
      lastLogin: new Date().toISOString()
    }
  ],
  centers: [
    {
      id: '1',
      name: 'MediLab Test Center',
      address: '123 Healthcare Street',
      city: 'Mumbai',
      state: 'Maharashtra',
      pincode: '400001',
      phone: '+91 9876543212',
      email: 'testcenter@medilab-india.com',
      ownerName: 'Dr. Rajesh Kumar',
      ownerPhone: '+91 9876543213',
      ownerEmail: 'owner@testcenter.com',
      subscriptionType: 'gold',
      paymentType: 'online',
      username: 'testcenter',
      isActive: true,
      createdDate: '2024-01-01',
      licenseNumber: 'MH-LAB-2024-001',
      registrationNumber: 'REG-2024-001',
      website: 'https://testcenter.medilab-india.com',
      description: 'Premier diagnostic center with state-of-the-art equipment',
      services: ['Blood Tests', 'Urine Tests', 'X-Ray', 'ECG', 'Ultrasound'],
      operatingHours: 'Mon-Sat: 8:00 AM - 8:00 PM, Sun: 9:00 AM - 5:00 PM',
      emergencyContact: '+91 9876543214'
    }
  ],
  patients: [
    {
      id: '1',
      fullName: 'Priya Sharma',
      email: 'patient@medilab-india.com',
      phone: '+91 9876543215',
      address: '789 Patient Street',
      city: 'Mumbai',
      state: 'Maharashtra',
      pincode: '400002',
      whatsappNumber: '+91 9876543215',
      passcode: 'PATIENT123',
      centerId: '1',
      centerName: 'MediLab Test Center',
      createdDate: '2024-01-01',
      dateOfBirth: '1990-05-15',
      gender: 'female',
      emergencyContact: '+91 9876543216',
      bloodGroup: 'B+',
      allergies: 'None'
    }
  ],
  reports: [
    {
      id: '1',
      patientId: '1',
      patientName: 'Priya Sharma',
      centerId: '1',
      centerName: 'MediLab Test Center',
      testType: 'Blood Test',
      testName: 'Complete Blood Count (CBC)',
      referredBy: 'Dr. Amit Patel',
      sampleDate: '2024-01-15',
      reportDate: '2024-01-16',
      passcodeId: 'RPT001',
      status: 'completed',
      priority: 'normal',
      sampleType: 'Blood',
      methodology: 'Automated Analyzer',
      notes: 'All parameters within normal range',
      technician: 'Tech. Suresh Kumar',
      verifiedBy: 'Dr. Rajesh Kumar',
      createdAt: '2024-01-15T10:00:00Z',
      results: [
        { parameter: 'Hemoglobin', value: '13.5', unit: 'g/dL', reference: '12.0-16.0', status: 'normal' },
        { parameter: 'RBC Count', value: '4.8', unit: 'million/μL', reference: '4.5-5.5', status: 'normal' },
        { parameter: 'WBC Count', value: '7200', unit: '/μL', reference: '4000-11000', status: 'normal' },
        { parameter: 'Platelets', value: '285000', unit: '/μL', reference: '150000-450000', status: 'normal' }
      ]
    }
  ],
  bills: [
    {
      id: '1',
      patientId: '1',
      patientName: 'Priya Sharma',
      centerId: '1',
      centerName: 'MediLab Test Center',
      invoiceNumber: 'INV-2024-001',
      amount: 1500.00,
      discount: 150.00,
      tax: 135.00,
      totalTax: 135.00,
      finalAmount: 1485.00,
      status: 'paid',
      paymentMode: 'upi',
      paymentDate: '2024-01-16',
      createdDate: '2024-01-16',
      dueDate: '2024-01-30',
      tests: [
        { name: 'Complete Blood Count (CBC)', price: 800.00 },
        { name: 'Lipid Profile', price: 600.00 },
        { name: 'Liver Function Test', price: 400.00 }
      ]
    }
  ]
};

class ApiService {
  private isOnline = false;
  private currentUser: any = null;
  private connectionChecked = false;
  private forceOfflineMode = false;

  constructor() {
    // In development, check for offline mode flag
    if (DEVELOPMENT_MODE) {
      const urlParams = new URLSearchParams(window.location.search);
      this.forceOfflineMode = urlParams.has('offline') || localStorage.getItem('medilab-offline-mode') === 'true';
      
      if (this.forceOfflineMode) {
        console.log('🔄 Force offline mode enabled');
        this.isOnline = false;
      }
    }
  }

  private async quickConnectionCheck(): Promise<boolean> {
    if (this.forceOfflineMode) return false;
    
    try {
      // Quick ping to the server with very short timeout
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 1000); // 1 second only
      
      const response = await fetch(`${API_BASE_URL}/health`, {
        method: 'GET',
        signal: controller.signal,
        cache: 'no-cache'
      });
      
      clearTimeout(timeoutId);
      
      if (response.ok) {
        this.isOnline = true;
        return true;
      } else {
        throw new Error('Server not responding');
      }
    } catch (error) {
      this.isOnline = false;
      return false;
    }
  }

  private async requestWithFallback<T>(
    endpoint: string,
    options: RequestInit = {}
  ): Promise<ApiResponse<T>> {
    // If we know we're offline, go straight to mock data
    if (!this.isOnline && this.connectionChecked) {
      return this.handleOfflineRequest<T>(endpoint, options);
    }

    try {
      const url = `${API_BASE_URL}${endpoint}`;
      const config: RequestInit = {
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
          ...options.headers,
        },
        ...options,
      };

      // Create timeout promise
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), REQUEST_TIMEOUT);
      
      config.signal = controller.signal;

      const response = await fetch(url, config);
      clearTimeout(timeoutId);
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      
      // Mark as online on successful request
      if (!this.isOnline) {
        console.log('✅ Server connection established');
        this.isOnline = true;
      }
      
      return data;
    } catch (error) {
      // Immediately switch to offline mode on any error
      if (!this.connectionChecked) {
        console.log('🔄 Server unavailable, switching to demo mode');
        this.connectionChecked = true;
      }
      
      this.isOnline = false;
      return this.handleOfflineRequest<T>(endpoint, options);
    }
  }

  private handleOfflineRequest<T>(endpoint: string, options: RequestInit = {}): ApiResponse<T> {
    const method = options.method || 'GET';
    
    // Authentication endpoints
    if (endpoint === '/auth/login') {
      try {
        const body = JSON.parse(options.body as string);
        const user = MOCK_DATA.users.find(u => u.username === body.username);
        
        if (user && body.password === 'password') {
          this.currentUser = { ...user, lastLogin: new Date().toISOString() };
          return {
            success: true,
            data: this.currentUser as T,
            message: 'Login successful (demo mode)'
          };
        } else {
          return {
            success: false,
            error: 'Invalid credentials'
          };
        }
      } catch (error) {
        return {
          success: false,
          error: 'Invalid request format'
        };
      }
    }
    
    if (endpoint === '/auth/me') {
      return {
        success: this.currentUser ? true : false,
        data: this.currentUser as T,
        error: this.currentUser ? undefined : 'Not authenticated'
      };
    }
    
    if (endpoint === '/auth/logout') {
      this.currentUser = null;
      return {
        success: true,
        message: 'Logged out successfully (demo mode)'
      };
    }
    
    // Health check
    if (endpoint === '/health') {
      return {
        success: true,
        data: {
          message: 'Running in demo mode',
          timestamp: new Date().toISOString(),
          environment: 'development',
          version: '1.0.0',
          offline: true
        } as T
      };
    }
    
    // Data endpoints
    if (endpoint.startsWith('/centers')) {
      return {
        success: true,
        data: MOCK_DATA.centers as T
      };
    }
    
    if (endpoint.startsWith('/patients')) {
      if (endpoint.includes('find-by-passcode')) {
        try {
          const body = JSON.parse(options.body as string);
          const patient = MOCK_DATA.patients.find(p => p.passcode === body.passcode);
          return {
            success: true,
            data: patient as T
          };
        } catch (error) {
          return {
            success: false,
            error: 'Invalid request format'
          };
        }
      }
      return {
        success: true,
        data: MOCK_DATA.patients as T
      };
    }
    
    if (endpoint.startsWith('/reports')) {
      return {
        success: true,
        data: MOCK_DATA.reports as T
      };
    }
    
    if (endpoint.startsWith('/bills')) {
      return {
        success: true,
        data: MOCK_DATA.bills as T
      };
    }
    
    // Dashboard stats
    if (endpoint === '/admin/stats/dashboard') {
      return {
        success: true,
        data: {
          totalCenters: MOCK_DATA.centers.length,
          totalPatients: MOCK_DATA.patients.length,
          totalReports: MOCK_DATA.reports.length,
          totalBills: MOCK_DATA.bills.length,
          todayReports: 1,
          pendingReports: 0,
          revenue: 1485.00,
          monthlyGrowth: 15.5
        } as T
      };
    }
    
    // For POST/PUT/DELETE operations in offline mode
    if (method === 'POST' || method === 'PUT' || method === 'DELETE') {
      return {
        success: true,
        data: { id: Math.random().toString(36).substr(2, 9) } as T,
        message: `${method} operation completed (demo mode - changes not saved)`
      };
    }
    
    // Default response for unknown endpoints
    return {
      success: false,
      error: 'Endpoint not available in demo mode'
    };
  }

  // Connection management methods
  async initialize(): Promise<boolean> {
    if (this.forceOfflineMode) {
      this.isOnline = false;
      this.connectionChecked = true;
      return false;
    }

    const isOnline = await this.quickConnectionCheck();
    this.connectionChecked = true;
    return isOnline;
  }

  async checkConnection(): Promise<boolean> {
    return await this.quickConnectionCheck();
  }

  isApiOnline(): boolean {
    return this.isOnline;
  }

  getConnectionStatus(): string {
    return this.isOnline ? 'online' : 'offline';
  }

  // Toggle offline mode for development
  toggleOfflineMode(): void {
    this.forceOfflineMode = !this.forceOfflineMode;
    this.isOnline = !this.forceOfflineMode;
    
    if (this.forceOfflineMode) {
      localStorage.setItem('medilab-offline-mode', 'true');
      console.log('🔄 Switched to offline mode');
    } else {
      localStorage.removeItem('medilab-offline-mode');
      console.log('🔄 Switched to online mode');
    }
  }

  // Authentication APIs
  async login(credentials: { username: string; password: string }) {
    return this.requestWithFallback('/auth/login', {
      method: 'POST',
      body: JSON.stringify(credentials),
    });
  }

  async logout() {
    const result = await this.requestWithFallback('/auth/logout', {
      method: 'POST',
    });
    this.currentUser = null;
    return result;
  }

  async getCurrentUser() {
    return this.requestWithFallback('/auth/me');
  }

  async healthCheck() {
    return this.requestWithFallback('/health');
  }

  // Data APIs (keeping the same interface)
  async getAllCenters(filters?: Record<string, any>) {
    const params = filters ? new URLSearchParams(filters) : '';
    return this.requestWithFallback(`/centers${params ? `?${params}` : ''}`);
  }

  async getCenterById(id: string) {
    return this.requestWithFallback(`/centers/${id}`);
  }

  async createCenter(centerData: any) {
    return this.requestWithFallback('/admin/centers', {
      method: 'POST',
      body: JSON.stringify(centerData),
    });
  }

  async updateCenter(id: string, centerData: any) {
    return this.requestWithFallback(`/admin/centers/${id}`, {
      method: 'PUT',
      body: JSON.stringify(centerData),
    });
  }

  async getCenterStats(id: string) {
    return this.requestWithFallback(`/admin/centers/${id}/stats`);
  }

  async getPatients(filters?: Record<string, any>) {
    const params = filters ? new URLSearchParams(filters) : '';
    return this.requestWithFallback(`/patients${params ? `?${params}` : ''}`);
  }

  async getPatientById(id: string) {
    return this.requestWithFallback(`/patients/${id}`);
  }

  async createPatient(patientData: any) {
    return this.requestWithFallback('/patients', {
      method: 'POST',
      body: JSON.stringify(patientData),
    });
  }

  async updatePatient(id: string, patientData: any) {
    return this.requestWithFallback(`/patients/${id}`, {
      method: 'PUT',
      body: JSON.stringify(patientData),
    });
  }

  async findPatientByPasscode(passcode: string, centerId?: string) {
    return this.requestWithFallback('/patients/find-by-passcode', {
      method: 'POST',
      body: JSON.stringify({ passcode, centerId }),
    });
  }

  async generatePatientPasscode(id: string) {
    return this.requestWithFallback(`/patients/${id}/generate-passcode`, {
      method: 'POST',
    });
  }

  async getPatientStats(centerId?: string) {
    const params = centerId ? new URLSearchParams({ centerId }) : '';
    return this.requestWithFallback(`/patients/stats/overview${params ? `?${params}` : ''}`);
  }

  async getReports(filters?: Record<string, any>) {
    const params = filters ? new URLSearchParams(filters) : '';
    return this.requestWithFallback(`/reports${params ? `?${params}` : ''}`);
  }

  async getReportById(id: string) {
    return this.requestWithFallback(`/reports/${id}`);
  }

  async getReportsByPatient(patientId: string) {
    return this.requestWithFallback(`/reports/patient/${patientId}`);
  }

  async createReport(reportData: any) {
    return this.requestWithFallback('/reports', {
      method: 'POST',
      body: JSON.stringify(reportData),
    });
  }

  async updateReportStatus(id: string, status: string, reportData?: any) {
    return this.requestWithFallback(`/reports/${id}/status`, {
      method: 'PUT',
      body: JSON.stringify({ status, reportData }),
    });
  }

  async updateReportResults(id: string, results: any[]) {
    return this.requestWithFallback(`/reports/${id}/results`, {
      method: 'PUT',
      body: JSON.stringify({ results }),
    });
  }

  async searchReportsByPasscode(passcode: string) {
    return this.requestWithFallback('/reports/search-by-passcode', {
      method: 'POST',
      body: JSON.stringify({ passcode }),
    });
  }

  async getReportStats(centerId?: string) {
    const params = centerId ? new URLSearchParams({ centerId }) : '';
    return this.requestWithFallback(`/reports/stats/overview${params ? `?${params}` : ''}`);
  }

  async getBills(filters?: Record<string, any>) {
    const params = filters ? new URLSearchParams(filters) : '';
    return this.requestWithFallback(`/bills${params ? `?${params}` : ''}`);
  }

  async getBillById(id: string) {
    return this.requestWithFallback(`/bills/${id}`);
  }

  async getBillsByPatient(patientId: string) {
    return this.requestWithFallback(`/bills/patient/${patientId}`);
  }

  async createBill(billData: any) {
    return this.requestWithFallback('/bills', {
      method: 'POST',
      body: JSON.stringify(billData),
    });
  }

  async updateBillPayment(id: string, status: string, paymentData?: any) {
    return this.requestWithFallback(`/bills/${id}/payment`, {
      method: 'PUT',
      body: JSON.stringify({ status, paymentData }),
    });
  }

  async updateBillTests(id: string, tests: any[], amounts?: any) {
    return this.requestWithFallback(`/bills/${id}/tests`, {
      method: 'PUT',
      body: JSON.stringify({ tests, ...amounts }),
    });
  }

  async getBillStats(centerId?: string) {
    const params = centerId ? new URLSearchParams({ centerId }) : '';
    return this.requestWithFallback(`/bills/stats/overview${params ? `?${params}` : ''}`);
  }

  async generateInvoiceNumber(centerId?: string) {
    const params = centerId ? new URLSearchParams({ centerId }) : '';
    return this.requestWithFallback(`/bills/generate-invoice-number${params ? `?${params}` : ''}`);
  }

  async getDashboardStats() {
    return this.requestWithFallback('/admin/stats/dashboard');
  }

  async getAllUsers(role?: string, limit?: number) {
    const params = new URLSearchParams();
    if (role) params.append('role', role);
    if (limit) params.append('limit', limit.toString());
    return this.requestWithFallback(`/admin/users${params.toString() ? `?${params}` : ''}`);
  }

  async createUser(userData: any) {
    return this.requestWithFallback('/admin/users', {
      method: 'POST',
      body: JSON.stringify(userData),
    });
  }

  async getSystemSettings() {
    return this.requestWithFallback('/admin/settings');
  }

  async updateSystemSetting(key: string, value: any, description?: string) {
    return this.requestWithFallback(`/admin/settings/${key}`, {
      method: 'PUT',
      body: JSON.stringify({ value, description }),
    });
  }

  async getAuditLogs(filters?: Record<string, any>) {
    const params = filters ? new URLSearchParams(filters) : '';
    return this.requestWithFallback(`/admin/audit-logs${params ? `?${params}` : ''}`);
  }

  async initiateBackup() {
    return this.requestWithFallback('/admin/backup', {
      method: 'POST',
    });
  }

  async getSystemHealth() {
    return this.requestWithFallback('/admin/health');
  }

  async getExports() {
    return this.requestWithFallback('/exports');
  }

  async createExport(exportData: any) {
    return this.requestWithFallback('/exports', {
      method: 'POST',
      body: JSON.stringify(exportData),
    });
  }

  async getExportStatus(id: string) {
    return this.requestWithFallback(`/exports/${id}/status`);
  }

  async downloadExport(id: string) {
    return this.requestWithFallback(`/exports/${id}/download`);
  }
}

export const apiService = new ApiService();
export default apiService;