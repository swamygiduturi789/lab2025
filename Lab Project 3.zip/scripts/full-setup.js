#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

console.log('🚀 Composcale.com Full Build Setup');
console.log('=====================================');

// Colors for console output
const colors = {
  reset: '\x1b[0m',
  bright: '\x1b[1m',
  red: '\x1b[31m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  magenta: '\x1b[35m',
  cyan: '\x1b[36m',
};

function logStep(step, message) {
  console.log(`${colors.cyan}[${step}]${colors.reset} ${message}`);
}

function logSuccess(message) {
  console.log(`${colors.green}✅ ${message}${colors.reset}`);
}

function logError(message) {
  console.log(`${colors.red}❌ ${message}${colors.reset}`);
}

function logWarning(message) {
  console.log(`${colors.yellow}⚠️  ${message}${colors.reset}`);
}

function logInfo(message) {
  console.log(`${colors.blue}ℹ️  ${message}${colors.reset}`);
}

// Step 1: Check prerequisites
logStep('1/8', 'Checking Prerequisites');
try {
  // Check Node.js version
  const nodeVersion = process.version;
  const majorVersion = parseInt(nodeVersion.slice(1).split('.')[0]);
  if (majorVersion < 16) {
    throw new Error(`Node.js 16+ required. Current version: ${nodeVersion}`);
  }
  logSuccess(`Node.js version: ${nodeVersion}`);

  // Check if MySQL is available
  try {
    execSync('mysql --version', { stdio: 'ignore' });
    logSuccess('MySQL is available');
  } catch (error) {
    logWarning('MySQL client not found in PATH. Please ensure MySQL is installed.');
  }

  // Check if npm is available
  const npmVersion = execSync('npm --version', { encoding: 'utf8' }).trim();
  logSuccess(`npm version: ${npmVersion}`);

} catch (error) {
  logError(`Prerequisites check failed: ${error.message}`);
  process.exit(1);
}

// Step 2: Install dependencies
logStep('2/8', 'Installing Dependencies');
try {
  logInfo('Installing Node.js dependencies...');
  execSync('npm install', { stdio: 'inherit' });
  logSuccess('All dependencies installed successfully');
} catch (error) {
  logError(`Dependency installation failed: ${error.message}`);
  process.exit(1);
}

// Step 3: Environment setup
logStep('3/8', 'Environment Configuration');
try {
  const envPath = path.join(process.cwd(), '.env');
  const envExamplePath = path.join(process.cwd(), 'database', '.env.example');
  
  if (!fs.existsSync(envPath)) {
    if (fs.existsSync(envExamplePath)) {
      fs.copyFileSync(envExamplePath, envPath);
      logSuccess('Environment file created from template');
      logWarning('Please edit .env file with your database credentials');
    } else {
      // Create a basic .env file
      const basicEnv = `# Composcale.com Environment Configuration
DB_HOST=localhost
DB_PORT=3306
DB_USER=root
DB_PASSWORD=
DB_NAME=composcale_com
NODE_ENV=development
PORT=3001
SESSION_SECRET=composcale-dev-secret-change-in-production
JWT_SECRET=composcale-dev-jwt-secret-change-in-production
`;
      fs.writeFileSync(envPath, basicEnv);
      logSuccess('Basic environment file created');
      logWarning('Please edit .env file with your database credentials');
    }
  } else {
    logSuccess('Environment file already exists');
  }
} catch (error) {
  logError(`Environment setup failed: ${error.message}`);
  process.exit(1);
}

// Step 4: Database setup
logStep('4/8', 'Database Setup');
try {
  logInfo('Setting up database schema...');
  execSync('node database/setup.js', { stdio: 'inherit' });
  logSuccess('Database schema created successfully');
} catch (error) {
  logError(`Database setup failed: ${error.message}`);
  logWarning('Please check your database configuration in .env file');
  process.exit(1);
}

// Step 5: Initialize admin accounts
logStep('5/8', 'Initializing Admin Accounts');
try {
  logInfo('Creating default admin accounts...');
  execSync('node database/init-admin-accounts.js', { stdio: 'inherit' });
  logSuccess('Admin accounts initialized successfully');
} catch (error) {
  logError(`Admin account initialization failed: ${error.message}`);
  logWarning('You may need to create admin accounts manually');
}

// Step 6: Build frontend
logStep('6/8', 'Building Frontend Application');
try {
  logInfo('Building React application...');
  execSync('npm run build', { stdio: 'inherit' });
  logSuccess('Frontend application built successfully');
} catch (error) {
  logError(`Frontend build failed: ${error.message}`);
  process.exit(1);
}

// Step 7: Test database connection
logStep('7/8', 'Testing Database Connection');
try {
  logInfo('Testing database connectivity...');
  const testScript = `
const { testConnection } = require('./database/connection');
testConnection().then(isConnected => {
  if (isConnected) {
    console.log('✅ Database connection successful');
    process.exit(0);
  } else {
    console.log('❌ Database connection failed');
    process.exit(1);
  }
}).catch(error => {
  console.log('❌ Database connection error:', error.message);
  process.exit(1);
});
`;
  fs.writeFileSync('test-db.js', testScript);
  execSync('node test-db.js', { stdio: 'inherit' });
  fs.unlinkSync('test-db.js');
  logSuccess('Database connection test passed');
} catch (error) {
  logError(`Database connection test failed: ${error.message}`);
  if (fs.existsSync('test-db.js')) {
    fs.unlinkSync('test-db.js');
  }
}

// Step 8: Final setup
logStep('8/8', 'Final Setup');
try {
  // Create logs directory
  const logsDir = path.join(process.cwd(), 'logs');
  if (!fs.existsSync(logsDir)) {
    fs.mkdirSync(logsDir, { recursive: true });
    logSuccess('Logs directory created');
  }

  // Create uploads directory
  const uploadsDir = path.join(process.cwd(), 'uploads');
  if (!fs.existsSync(uploadsDir)) {
    fs.mkdirSync(uploadsDir, { recursive: true });
    logSuccess('Uploads directory created');
  }

  // Create backups directory
  const backupsDir = path.join(process.cwd(), 'backups');
  if (!fs.existsSync(backupsDir)) {
    fs.mkdirSync(backupsDir, { recursive: true });
    logSuccess('Backups directory created');
  }

  logSuccess('Final setup completed');
} catch (error) {
  logError(`Final setup failed: ${error.message}`);
}

// Success message
console.log('\n🎉 Setup Complete!');
console.log('==================');
console.log('');
console.log(`${colors.green}✅ Composcale.com is ready to run!${colors.reset}`);
console.log('');
console.log(`${colors.cyan}Quick Start:${colors.reset}`);
console.log(`  ${colors.yellow}Development:${colors.reset} npm run dev`);
console.log(`  ${colors.yellow}Production:${colors.reset}  npm start`);
console.log(`  ${colors.yellow}Build only:${colors.reset}   npm run build`);
console.log('');
console.log(`${colors.cyan}Default Login Credentials:${colors.reset}`);
console.log(`  ${colors.blue}Super Admin:${colors.reset}`);
console.log(`    Username: superadmin`);
console.log(`    Password: password`);
console.log('');
console.log(`  ${colors.blue}Test Center:${colors.reset}`);
console.log(`    Username: testcenter`);
console.log(`    Password: password`);
console.log('');
console.log(`  ${colors.blue}Test Patient:${colors.reset}`);
console.log(`    Username: patient`);
console.log(`    Password: password`);
console.log('');
console.log(`${colors.cyan}Important URLs:${colors.reset}`);
console.log(`  ${colors.blue}Frontend:${colors.reset} http://localhost:3000`);
console.log(`  ${colors.blue}Backend:${colors.reset}  http://localhost:3001`);
console.log(`  ${colors.blue}API Health:${colors.reset} http://localhost:3001/api/health`);
console.log('');
console.log(`${colors.yellow}⚠️  Security Notice:${colors.reset}`);
console.log('  - Change default passwords before production use');
console.log('  - Update JWT and session secrets in .env file');
console.log('  - Configure proper database credentials');
console.log('  - Set up SSL certificates for production');
console.log('');
console.log(`${colors.magenta}🚀 Happy coding!${colors.reset}`);