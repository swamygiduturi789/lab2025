const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');
const util = require('util');
const execPromise = util.promisify(exec);

require('dotenv').config();

// cPanel deployment configuration
const CPANEL_CONFIG = {
  host: process.env.CPANEL_HOST || 'your-domain.com',
  username: process.env.CPANEL_USERNAME || 'your-username',
  password: process.env.CPANEL_PASSWORD || 'your-password',
  domain: process.env.CPANEL_DOMAIN || 'your-domain.com',
  publicHtmlPath: process.env.CPANEL_PUBLIC_HTML || 'public_html',
  nodeAppPath: process.env.CPANEL_NODE_APP_PATH || 'medilab-app',
  nodeVersion: process.env.NODE_VERSION || '18'
};

console.log('🚀 Starting cPanel deployment for MediLab India...\n');

async function deployToCPanel() {
  try {
    // Step 1: Build the application
    console.log('1️⃣ Building application...');
    await execPromise('npm run build');
    console.log('✅ Application built successfully\n');

    // Step 2: Create deployment package
    console.log('2️⃣ Creating deployment package...');
    await createDeploymentPackage();
    console.log('✅ Deployment package created\n');

    // Step 3: Generate cPanel configuration files
    console.log('3️⃣ Generating cPanel configuration...');
    await generateCPanelConfig();
    console.log('✅ cPanel configuration generated\n');

    // Step 4: Create database setup script
    console.log('4️⃣ Creating database setup script...');
    await createDatabaseSetupScript();
    console.log('✅ Database setup script created\n');

    // Step 5: Generate deployment instructions
    console.log('5️⃣ Generating deployment instructions...');
    await generateDeploymentInstructions();
    console.log('✅ Deployment instructions generated\n');

    console.log('🎉 Deployment package ready! Check the "deployment" folder.');
    console.log('📖 Follow the instructions in DEPLOYMENT_INSTRUCTIONS.md');
    
  } catch (error) {
    console.error('❌ Deployment failed:', error.message);
    process.exit(1);
  }
}

async function createDeploymentPackage() {
  const deploymentDir = path.join(__dirname, '../deployment');
  
  // Create deployment directory
  if (!fs.existsSync(deploymentDir)) {
    fs.mkdirSync(deploymentDir, { recursive: true });
  }

  // Copy necessary files
  const filesToCopy = [
    { src: 'build', dest: 'public_html' },
    { src: 'server', dest: 'server' },
    { src: 'database', dest: 'database' },
    { src: 'package.json', dest: 'package.json' },
    { src: '.env.production', dest: '.env' },
    { src: 'public/.htaccess', dest: 'public_html/.htaccess' }
  ];

  for (const file of filesToCopy) {
    const srcPath = path.join(__dirname, '../', file.src);
    const destPath = path.join(deploymentDir, file.dest);
    
    if (fs.existsSync(srcPath)) {
      await copyRecursive(srcPath, destPath);
    }
  }

  // Create production package.json
  const packageJson = JSON.parse(fs.readFileSync(path.join(__dirname, '../package.json'), 'utf8'));
  const prodPackageJson = {
    name: packageJson.name,
    version: packageJson.version,
    description: packageJson.description,
    main: packageJson.main,
    scripts: {
      start: 'node server/index.js',
      'setup:db': 'node database/setup.js',
      'migrate': 'node scripts/migrate.js'
    },
    dependencies: packageJson.dependencies,
    engines: packageJson.engines
  };

  fs.writeFileSync(
    path.join(deploymentDir, 'package.json'),
    JSON.stringify(prodPackageJson, null, 2)
  );
}

async function generateCPanelConfig() {
  const deploymentDir = path.join(__dirname, '../deployment');
  
  // Create app.js for cPanel Node.js app
  const appJs = `
const app = require('./server/index.js');

// Export the app for cPanel
module.exports = app;
`;

  fs.writeFileSync(path.join(deploymentDir, 'app.js'), appJs);

  // Create startup file
  const startupFile = `
#!/bin/bash
# MediLab India Startup Script

# Set environment variables
export NODE_ENV=production
export PORT=3001

# Start the application
node app.js
`;

  fs.writeFileSync(path.join(deploymentDir, 'startup.sh'), startupFile);
  
  // Make startup file executable
  try {
    await execPromise(`chmod +x ${path.join(deploymentDir, 'startup.sh')}`);
  } catch (error) {
    console.warn('Could not make startup.sh executable:', error.message);
  }

  // Create .htaccess for public_html
  const htaccess = `
# MediLab India - cPanel Deployment Configuration

RewriteEngine On

# Handle Angular and React Router
RewriteBase /
RewriteRule ^index\\.html$ - [L]
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule . /index.html [L]

# Security headers
Header always set X-Content-Type-Options nosniff
Header always set X-Frame-Options DENY
Header always set X-XSS-Protection "1; mode=block"
Header always set Strict-Transport-Security "max-age=63072000; includeSubDomains; preload"
Header always set Referrer-Policy "strict-origin-when-cross-origin"

# Enable compression
<IfModule mod_deflate.c>
    AddOutputFilterByType DEFLATE text/plain
    AddOutputFilterByType DEFLATE text/html
    AddOutputFilterByType DEFLATE text/xml
    AddOutputFilterByType DEFLATE text/css
    AddOutputFilterByType DEFLATE application/xml
    AddOutputFilterByType DEFLATE application/xhtml+xml
    AddOutputFilterByType DEFLATE application/rss+xml
    AddOutputFilterByType DEFLATE application/javascript
    AddOutputFilterByType DEFLATE application/x-javascript
</IfModule>

# Cache static assets
<IfModule mod_expires.c>
    ExpiresActive on
    ExpiresByType text/css "access plus 1 year"
    ExpiresByType application/javascript "access plus 1 year"
    ExpiresByType image/png "access plus 1 year"
    ExpiresByType image/jpg "access plus 1 year"
    ExpiresByType image/jpeg "access plus 1 year"
    ExpiresByType image/gif "access plus 1 year"
    ExpiresByType image/svg+xml "access plus 1 year"
</IfModule>

# API routing to Node.js app
RewriteCond %{REQUEST_URI} ^/api/
RewriteRule ^api/(.*)$ http://localhost:3001/api/$1 [P,L]
`;

  fs.writeFileSync(path.join(deploymentDir, 'public_html/.htaccess'), htaccess);
}

async function createDatabaseSetupScript() {
  const deploymentDir = path.join(__dirname, '../deployment');
  
  const dbSetupScript = `
#!/bin/bash
# Database Setup Script for cPanel

echo "Setting up MediLab India Database..."

# Create database (you'll need to do this manually in cPanel)
echo "1. Create database 'medilab_india' in cPanel MySQL Databases"
echo "2. Create database user and assign to database"
echo "3. Update .env file with database credentials"

# Install Node.js dependencies
echo "Installing dependencies..."
npm install --production

# Setup database schema
echo "Setting up database schema..."
node database/setup.js

echo "Database setup complete!"
echo "Don't forget to:"
echo "- Update .env with your database credentials"
echo "- Set NODE_ENV=production"
echo "- Configure your domain in cPanel Node.js Apps"
`;

  fs.writeFileSync(path.join(deploymentDir, 'setup-database.sh'), dbSetupScript);
  
  try {
    await execPromise(`chmod +x ${path.join(deploymentDir, 'setup-database.sh')}`);
  } catch (error) {
    console.warn('Could not make setup-database.sh executable:', error.message);
  }
}

async function generateDeploymentInstructions() {
  const deploymentDir = path.join(__dirname, '../deployment');
  
  const instructions = `
# MediLab India - cPanel Deployment Instructions

## Prerequisites
- cPanel hosting account with Node.js support
- MySQL database access
- SSH access (optional but recommended)

## Step 1: Upload Files
1. Upload all files from the deployment folder to your cPanel file manager
2. Extract files to your domain's root directory
3. Ensure \`public_html\` contains the frontend files
4. Ensure the Node.js app files are in the correct directory

## Step 2: Database Setup
1. **Create MySQL Database:**
   - Go to cPanel → MySQL Databases
   - Create database: \`medilab_india\`
   - Create database user with full privileges
   - Note the database credentials

2. **Configure Environment:**
   - Edit \`.env\` file with your database credentials:
   \`\`\`
   DB_HOST=localhost
   DB_PORT=3306
   DB_USER=your_db_user
   DB_PASSWORD=your_db_password
   DB_NAME=medilab_india
   
   NODE_ENV=production
   PORT=3001
   
   JWT_SECRET=your_secure_jwt_secret
   SESSION_SECRET=your_secure_session_secret
   
   CORS_ORIGINS=https://yourdomain.com
   \`\`\`

## Step 3: Node.js App Configuration
1. **Setup Node.js App in cPanel:**
   - Go to cPanel → Node.js Apps
   - Click "Create App"
   - Set Node.js version: ${CPANEL_CONFIG.nodeVersion}
   - Set Application root: \`${CPANEL_CONFIG.nodeAppPath}\`
   - Set Application URL: \`yourdomain.com\`
   - Set Startup file: \`app.js\`

2. **Install Dependencies:**
   - Click "Run NPM Install" in cPanel Node.js Apps
   - Or run via SSH: \`npm install --production\`

## Step 4: Database Initialization
1. **Run Database Setup:**
   - Via SSH: \`cd /path/to/app && ./setup-database.sh\`
   - Or manually: \`node database/setup.js\`

## Step 5: SSL Certificate (Recommended)
1. Go to cPanel → SSL/TLS
2. Install SSL certificate for your domain
3. Force HTTPS redirect

## Step 6: Final Configuration
1. **Test the Application:**
   - Visit \`https://yourdomain.com\`
   - Check API endpoints: \`https://yourdomain.com/api/health\`

2. **Default Login Credentials:**
   - Super Admin: \`superadmin\` / \`password\`
   - Change default passwords immediately!

## Troubleshooting

### Common Issues:
1. **Database Connection Failed:**
   - Check database credentials in \`.env\`
   - Ensure database user has correct privileges
   - Verify database name exists

2. **404 Errors:**
   - Check \`.htaccess\` file in public_html
   - Ensure mod_rewrite is enabled

3. **API Not Working:**
   - Check Node.js app is running in cPanel
   - Verify port configuration
   - Check error logs in cPanel

4. **Permission Errors:**
   - Set correct file permissions (644 for files, 755 for directories)
   - Ensure Node.js app has write access to logs directory

### Log Files:
- Application logs: \`logs/app.log\`
- Error logs: \`logs/error.log\`
- cPanel logs: Available in cPanel → Errors

## Maintenance

### Regular Tasks:
1. **Database Backups:**
   - Use cPanel backup tools
   - Or run: \`node scripts/backup-database.js\`

2. **Updates:**
   - Upload new files to replace existing ones
   - Restart Node.js app in cPanel
   - Run migrations if needed: \`node scripts/migrate.js\`

3. **Monitoring:**
   - Check application health: \`/api/health\`
   - Monitor error logs regularly
   - Review user activity in admin dashboard

## Security Checklist
- [ ] Change default passwords
- [ ] Enable SSL certificate
- [ ] Configure firewall rules
- [ ] Set up regular backups
- [ ] Monitor access logs
- [ ] Keep dependencies updated

## Support
For technical support, check:
1. Application logs
2. Database connection
3. cPanel error logs
4. Contact your hosting provider

---

**Important:** Always test the deployment on a staging environment first!
`;

  fs.writeFileSync(path.join(deploymentDir, 'DEPLOYMENT_INSTRUCTIONS.md'), instructions);
}

// Helper function to copy files recursively
async function copyRecursive(src, dest) {
  const stats = fs.statSync(src);
  
  if (stats.isDirectory()) {
    if (!fs.existsSync(dest)) {
      fs.mkdirSync(dest, { recursive: true });
    }
    
    const files = fs.readdirSync(src);
    for (const file of files) {
      const srcPath = path.join(src, file);
      const destPath = path.join(dest, file);
      await copyRecursive(srcPath, destPath);
    }
  } else {
    const destDir = path.dirname(dest);
    if (!fs.existsSync(destDir)) {
      fs.mkdirSync(destDir, { recursive: true });
    }
    fs.copyFileSync(src, dest);
  }
}

// Run deployment if called directly
if (require.main === module) {
  deployToCPanel();
}

module.exports = { deployToCPanel };
`;