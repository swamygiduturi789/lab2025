# 🏥 Composcale.com - Diagnostic Center Management System

A comprehensive full-stack web application for managing diagnostic centers, built with React, TypeScript, Node.js, Express, and MySQL.

![Version](https://img.shields.io/badge/version-1.0.0-blue.svg)
![Node](https://img.shields.io/badge/node-%3E%3D16.0.0-green.svg)
![MySQL](https://img.shields.io/badge/mysql-%3E%3D8.0-orange.svg)
![License](https://img.shields.io/badge/license-MIT-green.svg)

## 🚀 Features

### 🔐 Multi-Role Authentication System
- **Super Admin**: Complete system management and analytics
- **Diagnostic Centers**: Patient and test management
- **Patients**: Report access and bill viewing

### 🏢 Diagnostic Center Management
- Center registration and profile management
- Subscription plans (Free, Standard, Gold)
- Service catalog and certifications
- Real-time analytics and reporting

### 👥 Patient Management
- Complete patient registration system
- Medical history and test tracking
- Secure passcode-based report access
- WhatsApp and email notifications

### 📊 Test & Report Management
- Comprehensive test report generation
- Multiple test types and parameters
- PDF report generation with branding
- Real-time status tracking

### 💰 Billing & Payment System
- Invoice generation and management
- Multiple payment modes support
- Discount and tax calculations
- Payment tracking and reporting

### 📈 Analytics Dashboard
- Real-time business intelligence
- Revenue and growth analytics
- Interactive charts and graphs
- Exportable reports

## 🛠️ Technology Stack

### Frontend
- **React 18** with TypeScript
- **Tailwind CSS v4** for styling
- **shadcn/ui** component library
- **Recharts** for analytics
- **Lucide React** for icons
- **Vite** for build tooling

### Backend
- **Node.js** with Express.js
- **MySQL** database with connection pooling
- **bcrypt** for password hashing
- **express-session** with MySQL store
- **helmet** for security
- **cors** for cross-origin requests

### Database
- **MySQL 8.0+** with optimized schema
- **15 interconnected tables**
- **Foreign key constraints**
- **Indexed queries** for performance
- **Transaction support**

## 📋 Prerequisites

Before you begin, ensure you have the following installed:

- **Node.js** (>= 16.0.0)
- **npm** (>= 8.0.0)
- **MySQL** (>= 8.0)
- **Git**

## 🚀 Quick Start

### 1. Clone the Repository
```bash
git clone https://github.com/your-username/composcale-com.git
cd composcale-com
```

### 2. One-Command Setup
```bash
npm run setup
```

This command will:
- ✅ Install all dependencies
- ✅ Create environment configuration
- ✅ Set up MySQL database
- ✅ Create tables and indexes
- ✅ Initialize sample data
- ✅ Build the frontend
- ✅ Test database connection

### 3. Start Development
```bash
npm run dev
```

Your application will be available at:
- **Frontend**: http://localhost:3000
- **Backend API**: http://localhost:3001
- **Health Check**: http://localhost:3001/api/health

## 🔧 Manual Setup (Alternative)

If you prefer to set up manually:

### 1. Install Dependencies
```bash
npm install
```

### 2. Environment Configuration
```bash
# Copy environment template
cp database/.env.example .env

# Edit with your database credentials
nano .env
```

### 3. Database Setup
```bash
# Create database
mysql -u root -p
CREATE DATABASE composcale_com CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
exit

# Initialize database
npm run setup:db
npm run setup:admin
```

### 4. Build and Start
```bash
# Development
npm run dev

# Production
npm run build
npm start
```

## 🗄️ Database Configuration

### Environment Variables (.env)
```bash
# Database Configuration
DB_HOST=localhost
DB_PORT=3306
DB_USER=root
DB_PASSWORD=your_mysql_password
DB_NAME=composcale_com

# Application Configuration
NODE_ENV=development
PORT=3001
SESSION_SECRET=your_secure_session_secret
JWT_SECRET=your_secure_jwt_secret
```

### Database Schema
The application uses a comprehensive MySQL schema with 15 tables:

- **users** - Authentication and user management
- **diagnostic_centers** - Center information and profiles
- **patients** - Patient records and medical history
- **test_reports** - Medical test reports and results
- **bills** - Billing and payment information
- **center_profiles** - Extended center profile data
- **audit_logs** - System activity tracking
- And more...

## 👤 Default Login Credentials

After setup, use these credentials to access the system:

### Super Admin
- **Username**: `superadmin`
- **Password**: `password`
- **Access**: Complete system management

### Test Diagnostic Center
- **Username**: `testcenter`
- **Password**: `password`
- **Access**: Center management dashboard

### Test Patient
- **Username**: `patient`
- **Password**: `password`
- **Access**: Patient portal

⚠️ **Security Note**: Change these passwords before production deployment!

## 📜 Available Scripts

| Script | Description |
|--------|-------------|
| `npm run setup` | Complete application setup |
| `npm run dev` | Start development servers |
| `npm run build` | Build for production |
| `npm start` | Start production server |
| `npm run db:reset` | Reset database |
| `npm run db:health` | Check database health |
| `npm run lint` | Run ESLint |
| `npm run test` | Run tests |

## 🔍 API Endpoints

### Authentication
- `POST /api/auth/login` - User login
- `GET /api/auth/me` - Get current user
- `POST /api/auth/logout` - User logout

### Admin Management
- `GET /api/admin/centers` - Get all diagnostic centers
- `POST /api/admin/centers` - Create new center
- `PUT /api/admin/centers/:id` - Update center
- `DELETE /api/admin/centers/:id` - Delete center

### Center Management
- `GET /api/centers/patients` - Get center patients
- `POST /api/centers/patients` - Add new patient
- `GET /api/centers/reports` - Get center reports
- `POST /api/centers/reports` - Create new report

### Patient Access
- `GET /api/patients/reports` - Get patient reports
- `GET /api/patients/bills` - Get patient bills

## 🏗️ Project Structure

```
composcale-com/
├── components/              # React components
│   ├── ui/                 # Reusable UI components
│   ├── SuperAdminDashboard.tsx
│   ├── DiagnosticCenterDashboard.tsx
│   └── PatientDashboard.tsx
├── contexts/               # React contexts
│   ├── AuthContext.tsx
│   ├── DataContext.tsx
│   └── SidebarContext.tsx
├── database/               # Database files
│   ├── schema.sql
│   ├── setup.js
│   ├── connection.js
│   └── models.js
├── server/                 # Backend API
│   ├── routes/            # API routes
│   ├── middleware/        # Express middleware
│   └── index.js          # Server entry point
├── styles/                # Global styles
│   └── globals.css       # Tailwind CSS
└── scripts/               # Utility scripts
```

## 🚢 Production Deployment

### Build for Production
```bash
npm run build:prod
```

### cPanel Deployment
```bash
npm run deploy
```

### Environment Setup
1. Create production `.env` file
2. Set up MySQL database
3. Configure SSL certificates
4. Set up domain and DNS

## 🔒 Security Features

- **Password Hashing**: bcrypt with salt rounds
- **Session Management**: Secure MySQL session store
- **CORS Protection**: Configured origins
- **Rate Limiting**: API request throttling
- **SQL Injection Prevention**: Parameterized queries
- **Input Validation**: Comprehensive data validation
- **Audit Logging**: Complete activity tracking

## 📊 Performance Optimizations

- **Database Indexing**: Optimized query performance
- **Connection Pooling**: Efficient database connections
- **Caching**: Session and data caching
- **Compression**: Gzip compression enabled
- **Code Splitting**: Optimized bundle sizes
- **Lazy Loading**: Components loaded on demand

## 🧪 Testing

```bash
# Run tests
npm test

# Run with coverage
npm run test:coverage

# Database health check
npm run db:health
```

## 🐛 Troubleshooting

### Database Connection Issues
```bash
# Check database status
npm run db:health

# Reset database
npm run db:reset
npm run setup:db
```

### Common Problems

1. **"Database connection failed"**
   - Check MySQL service is running
   - Verify credentials in `.env` file
   - Ensure database exists

2. **"Port already in use"**
   - Change PORT in `.env` file
   - Kill existing processes

3. **"Module not found"**
   - Run `npm install`
   - Clear node_modules and reinstall

## 📝 Contributing

1. Fork the repository
2. Create your feature branch
3. Commit your changes
4. Push to the branch
5. Create a Pull Request

## 📄 License

This project is licensed under the MIT License. See the [LICENSE](LICENSE) file for details.

## 🆘 Support

For support and questions:

- **Email**: support@composcale.com
- **Documentation**: [GitHub Wiki](https://github.com/your-username/composcale-com/wiki)
- **Issues**: [GitHub Issues](https://github.com/your-username/composcale-com/issues)

## 🙏 Acknowledgments

- **React Team** for the amazing framework
- **Tailwind CSS** for the utility-first styling
- **shadcn/ui** for beautiful components
- **MySQL** for reliable database management
- **Node.js** community for excellent packages

---

Made with ❤️ by the **Composcale.com Team**

⭐ **Star this repository if you find it helpful!**