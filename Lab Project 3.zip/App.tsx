import React from 'react';
import { SuperAdminDashboard } from './components/SuperAdminDashboard';
import { DiagnosticCenterDashboard } from './components/DiagnosticCenterDashboard';
import { PatientDashboard } from './components/PatientDashboard';
import { LoginForm } from './components/LoginForm';
import { SidebarProvider } from './contexts/SidebarContext';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { DataProvider } from './contexts/DataContext';
import { Alert, AlertDescription } from './components/ui/alert';
import { Badge } from './components/ui/badge';
import { Button } from './components/ui/button';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuLabel, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from './components/ui/dropdown-menu';
import { Avatar, AvatarFallback } from './components/ui/avatar';
import { 
  Wifi, 
  WifiOff, 
  Loader2, 
  AlertCircle, 
  Settings, 
  User as UserIcon, 
  LogOut, 
  ChevronDown 
} from 'lucide-react';

// Development Mode Toggle (only in development)
const DevelopmentModeToggle = () => {
  const { connectionStatus, toggleOfflineMode, isAuthenticated, logout } = useAuth();

  if (process.env.NODE_ENV !== 'development') {
    return null;
  }

  return (
    <div className="fixed bottom-4 right-4 z-50 flex flex-col gap-2">
      {toggleOfflineMode && (
        <Button
          variant="outline"
          size="sm"
          onClick={toggleOfflineMode}
          className="bg-background/80 backdrop-blur-sm"
        >
          <Settings className="w-3 h-3 mr-1" />
          {connectionStatus === 'online' ? 'Switch to Demo' : 'Switch to Online'}
        </Button>
      )}
      {isAuthenticated && (
        <Button
          variant="destructive"
          size="sm"
          onClick={logout}
          className="bg-red-600/80 hover:bg-red-700/80 backdrop-blur-sm"
        >
          <LogOut className="w-3 h-3 mr-1" />
          Dev Logout
        </Button>
      )}
    </div>
  );
};

// Connection Status Component
const ConnectionStatus = () => {
  const { connectionStatus } = useAuth();

  if (connectionStatus === 'online') {
    return (
      <Badge variant="secondary" className="bg-success/10 text-success border-success/20">
        <Wifi className="w-3 h-3 mr-1" />
        Online
      </Badge>
    );
  }

  if (connectionStatus === 'offline') {
    return (
      <Badge variant="secondary" className="bg-warning/10 text-warning border-warning/20">
        <WifiOff className="w-3 h-3 mr-1" />
        Demo Mode
      </Badge>
    );
  }

  return null;
};

// User Menu Component
const UserMenu = ({ user, onLogout }: { user: any; onLogout: () => void }) => {
  const getRoleLabel = (role: string) => {
    switch (role) {
      case 'super_admin':
        return 'Super Admin';
      case 'diagnostic_center':
        return 'Diagnostic Center';
      case 'patient':
        return 'Patient';
      default:
        return 'User';
    }
  };

  const getUserInitials = (name: string) => {
    return name
      .split(' ')
      .map(word => word[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" className="flex items-center gap-2 h-auto p-2 hover:bg-muted/50">
          <Avatar className="h-8 w-8">
            <AvatarFallback className="text-xs font-medium bg-primary/10 text-primary">
              {getUserInitials(user.name)}
            </AvatarFallback>
          </Avatar>
          <div className="hidden md:flex flex-col items-start">
            <span className="text-sm font-medium">{user.name}</span>
            <span className="text-xs text-muted-foreground">{getRoleLabel(user.role)}</span>
          </div>
          <ChevronDown className="h-4 w-4 text-muted-foreground" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-56">
        <DropdownMenuLabel>
          <div className="flex flex-col space-y-1">
            <p className="text-sm font-medium leading-none">{user.name}</p>
            <p className="text-xs leading-none text-muted-foreground">
              {user.email || user.username}
            </p>
            <Badge variant="outline" className="w-fit text-xs mt-1">
              {getRoleLabel(user.role)}
            </Badge>
          </div>
        </DropdownMenuLabel>
        <DropdownMenuSeparator />
        <DropdownMenuItem className="cursor-pointer">
          <UserIcon className="mr-2 h-4 w-4" />
          <span>Profile</span>
        </DropdownMenuItem>
        <DropdownMenuItem className="cursor-pointer">
          <Settings className="mr-2 h-4 w-4" />
          <span>Settings</span>
        </DropdownMenuItem>
        <DropdownMenuSeparator />
        <DropdownMenuItem 
          className="cursor-pointer text-red-600 focus:text-red-600 focus:bg-red-50 dark:focus:bg-red-950/50"
          onClick={onLogout}
        >
          <LogOut className="mr-2 h-4 w-4" />
          <span>Logout</span>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
};

// Top Header Component
const TopHeader = ({ user, onLogout }: { user: any; onLogout: () => void }) => {
  return (
    <div className="flex items-center justify-between p-4 bg-background border-b border-border">
      <div className="flex items-center gap-4">
        <h1 className="text-lg font-semibold text-foreground">
          Composcale.com
        </h1>
      </div>
      <div className="flex items-center gap-4">
        <ConnectionStatus />
        <UserMenu user={user} onLogout={onLogout} />
      </div>
    </div>
  );
};

// Enhanced Loading Screen
const LoadingScreen = () => {
  const { connectionStatus, initialized } = useAuth();
  
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 via-teal-50 to-cyan-50 dark:from-blue-950 dark:via-teal-950 dark:to-cyan-950">
      <div className="flex flex-col items-center gap-6 p-8 max-w-md text-center">
        <div className="relative">
          <div className="w-20 h-20 bg-gradient-to-br from-blue-600 to-teal-600 rounded-2xl flex items-center justify-center shadow-lg">
            <Loader2 className="w-10 h-10 text-white animate-spin" />
          </div>
          {connectionStatus === 'offline' && (
            <div className="absolute -top-2 -right-2 w-6 h-6 bg-warning rounded-full flex items-center justify-center">
              <WifiOff className="w-3 h-3 text-warning-foreground" />
            </div>
          )}
        </div>
        
        <div className="space-y-2">
          <h1 className="text-xl font-semibold text-foreground">
            {!initialized ? 'Starting Composcale.com...' : 'Loading Application...'}
          </h1>
          
          <p className="text-sm text-muted-foreground">
            {connectionStatus === 'connecting' ? 'Checking server status...' : 
             connectionStatus === 'offline' ? 'Running in demo mode' : 
             connectionStatus === 'online' ? 'Connected to server' :
             'Preparing your healthcare dashboard...'}
          </p>
        </div>

        {connectionStatus === 'offline' && (
          <Alert className="border-warning/20 bg-warning/10 text-sm">
            <AlertCircle className="h-4 w-4 text-warning" />
            <AlertDescription className="text-warning">
              <strong>Demo Mode Active:</strong> Using sample data for development.
            </AlertDescription>
          </Alert>
        )}

        {process.env.NODE_ENV === 'development' && (
          <div className="text-xs text-muted-foreground">
            Development Mode • Quick server detection enabled
          </div>
        )}
      </div>
    </div>
  );
};

// Simplified Error Screen
const ErrorScreen = ({ error, onRetry }: { error: string; onRetry: () => void }) => {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-red-50 via-pink-50 to-rose-50 dark:from-red-950 dark:via-pink-950 dark:to-rose-950">
      <div className="flex flex-col items-center gap-6 p-8 max-w-lg text-center">
        <div className="w-20 h-20 bg-red-100 dark:bg-red-900 rounded-2xl flex items-center justify-center shadow-lg">
          <AlertCircle className="w-10 h-10 text-red-600 dark:text-red-400" />
        </div>
        
        <div className="space-y-4">
          <h1 className="text-2xl font-semibold text-foreground">Unable to Start</h1>
          
          <p className="text-muted-foreground">
            {error || 'There was a problem starting the application. Please try again.'}
          </p>
        </div>

        <Button onClick={onRetry} className="px-6 py-3">
          Try Again
        </Button>
      </div>
    </div>
  );
};

// Offline Notice Component
const OfflineNotice = () => {
  const { connectionStatus } = useAuth();
  
  if (connectionStatus !== 'offline') return null;
  
  return (
    <div className="bg-warning/10 border-b border-warning/20 px-4 py-2">
      <div className="flex items-center justify-center gap-2 text-warning text-sm">
        <WifiOff className="h-4 w-4" />
        <span>
          <strong>Demo Mode:</strong> Server unavailable. Using sample data - changes will not be saved.
        </span>
      </div>
    </div>
  );
};

// Main App Component
const AppContent = () => {
  const { 
    user, 
    isLoading, 
    isAuthenticated, 
    error, 
    refreshUser, 
    clearError, 
    connectionStatus,
    initialized,
    logout
  } = useAuth();

  // Show loading screen during initialization
  if (!initialized || (isLoading && !initialized)) {
    return <LoadingScreen />;
  }

  // Show error screen only for critical startup errors
  if (error && !isAuthenticated && connectionStatus === 'connecting') {
    return <ErrorScreen error={error} onRetry={() => {
      clearError();
      refreshUser();
    }} />;
  }

  // Show login form if not authenticated
  if (!isAuthenticated || !user) {
    return (
      <>
        <div className="fixed top-4 right-4 z-50">
          <ConnectionStatus />
        </div>
        <OfflineNotice />
        <LoginForm />
        <DevelopmentModeToggle />
      </>
    );
  }

  // Wrap dashboard components with providers
  const DashboardWithProviders = ({ children }: { children: React.ReactNode }) => (
    <SidebarProvider>
      <DataProvider>
        <div className="min-h-screen bg-background">
          <TopHeader user={user} onLogout={logout} />
          <OfflineNotice />
          <div className="relative">
            {children}
          </div>
          <DevelopmentModeToggle />
        </div>
      </DataProvider>
    </SidebarProvider>
  );

  // Debug: Log logout function availability
  if (process.env.NODE_ENV === 'development') {
    console.log('🔐 Dashboard render - User:', user.role, 'Logout function:', typeof logout);
  }

  // Render appropriate dashboard based on user role
  switch (user.role) {
    case 'super_admin':
      return (
        <DashboardWithProviders>
          <SuperAdminDashboard user={user} onLogout={logout} />
        </DashboardWithProviders>
      );
    case 'diagnostic_center':
      return (
        <DashboardWithProviders>
          <DiagnosticCenterDashboard user={user} onLogout={logout} />
        </DashboardWithProviders>
      );
    case 'patient':
      return (
        <DashboardWithProviders>
          <PatientDashboard user={user} onLogout={logout} />
        </DashboardWithProviders>
      );
    default:
      return (
        <>
          <div className="fixed top-4 right-4 z-50">
            <ConnectionStatus />
          </div>
          <OfflineNotice />
          <LoginForm />
          <DevelopmentModeToggle />
        </>
      );
  }
};

// Root App Component
const App = () => {
  return (
    <div className="app-root">
      <AuthProvider>
        <AppContent />
      </AuthProvider>
    </div>
  );
};

export default App;

// Re-export types for backward compatibility
export type { User } from './contexts/AuthContext';
export type { 
  DiagnosticCenter, 
  Patient, 
  TestReport, 
  TestResult, 
  Bill, 
  BillTest 
} from './contexts/DataContext';

// Legacy interfaces for backward compatibility
export interface CenterProfile {
  id: string;
  centerId: string;
  logo?: string;
  tagline?: string;
  licenseNumber: string;
  registrationNumber: string;
  website?: string;
  description?: string;
  services: string[];
  operatingHours: string;
  emergencyContact: string;
  socialMedia?: {
    facebook?: string;
    twitter?: string;
    instagram?: string;
  };
  certifications?: string[];
  accreditations?: string[];
  updatedDate: string;
}

export interface ReportExport {
  id: string;
  centerId: string;
  reportType: 'patients' | 'bills' | 'reports' | 'comprehensive';
  period: 'daily' | 'weekly' | 'monthly' | 'yearly' | 'custom';
  startDate: string;
  endDate: string;
  generatedDate: string;
  downloadUrl?: string;
  status: 'generating' | 'ready' | 'expired';
}