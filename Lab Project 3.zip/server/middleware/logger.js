const { executeQuery } = require('../../database/connection');

const logger = (req, res, next) => {
  const startTime = Date.now();
  const originalSend = res.send;

  // Override res.send to capture response
  res.send = function(data) {
    const endTime = Date.now();
    const duration = endTime - startTime;

    // Log to console
    console.log(`${new Date().toISOString()} - ${req.method} ${req.originalUrl} - ${res.statusCode} - ${duration}ms`);

    // Log to database for important actions
    if (shouldLogToDatabase(req, res)) {
      logToDatabase(req, res, duration).catch(console.error);
    }

    originalSend.call(this, data);
  };

  next();
};

const shouldLogToDatabase = (req, res) => {
  // Log authentication events
  if (req.originalUrl.includes('/auth/')) return true;
  
  // Log data modifications
  if (['POST', 'PUT', 'DELETE'].includes(req.method)) return true;
  
  // Log admin actions
  if (req.originalUrl.startsWith('/api/admin/')) return true;
  
  // Log errors
  if (res.statusCode >= 400) return true;
  
  return false;
};

const logToDatabase = async (req, res, duration) => {
  try {
    const action = `${req.method} ${req.originalUrl}`;
    const entityType = getEntityType(req.originalUrl);
    const entityId = getEntityId(req.originalUrl);
    
    await executeQuery(
      `INSERT INTO audit_logs (
        user_id, action, entity_type, entity_id, details, ip_address, user_agent, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())`,
      [
        req.session?.user?.id || null,
        action,
        entityType,
        entityId,
        JSON.stringify({
          statusCode: res.statusCode,
          duration: duration,
          body: req.method !== 'GET' ? req.body : undefined
        }),
        req.ip,
        req.get('User-Agent')
      ]
    );
  } catch (error) {
    console.error('Database logging failed:', error);
  }
};

const getEntityType = (url) => {
  if (url.includes('/centers')) return 'diagnostic_center';
  if (url.includes('/patients')) return 'patient';
  if (url.includes('/reports')) return 'test_report';
  if (url.includes('/bills')) return 'bill';
  if (url.includes('/users')) return 'user';
  if (url.includes('/auth')) return 'authentication';
  return 'system';
};

const getEntityId = (url) => {
  const matches = url.match(/\/(\d+)(?:\?|$)/);
  return matches ? matches[1] : null;
};

module.exports = {
  logger
};