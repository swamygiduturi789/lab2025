const requireAuth = (req, res, next) => {
  if (!req.session || !req.session.user) {
    return res.status(401).json({
      success: false,
      error: 'Authentication required',
      message: 'Please login to access this resource'
    });
  }
  next();
};

const requireRole = (roles) => {
  return (req, res, next) => {
    if (!req.session || !req.session.user) {
      return res.status(401).json({
        success: false,
        error: 'Authentication required'
      });
    }

    const userRole = req.session.user.role;
    const allowedRoles = Array.isArray(roles) ? roles : [roles];

    if (!allowedRoles.includes(userRole)) {
      return res.status(403).json({
        success: false,
        error: 'Insufficient permissions',
        message: `This resource requires one of the following roles: ${allowedRoles.join(', ')}`
      });
    }

    next();
  };
};

const requireSuperAdmin = requireRole('super_admin');
const requireDiagnosticCenter = requireRole(['super_admin', 'diagnostic_center']);
const requirePatient = requireRole(['super_admin', 'diagnostic_center', 'patient']);

module.exports = {
  requireAuth,
  requireRole,
  requireSuperAdmin,
  requireDiagnosticCenter,
  requirePatient
};