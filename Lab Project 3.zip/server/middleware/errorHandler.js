const { executeQuery } = require('../../database/connection');

const errorHandler = (err, req, res, next) => {
  console.error('Error:', err);

  // Log error to database if possible
  if (req.session && req.session.user) {
    logError(err, req).catch(console.error);
  }

  // Default error response
  let statusCode = 500;
  let message = 'Internal server error';

  // Handle specific error types
  if (err.name === 'ValidationError') {
    statusCode = 400;
    message = 'Validation error';
  } else if (err.name === 'CastError') {
    statusCode = 400;
    message = 'Invalid ID format';
  } else if (err.code === 'ENOTFOUND') {
    statusCode = 503;
    message = 'Service unavailable';
  } else if (err.code === 'ECONNREFUSED') {
    statusCode = 503;
    message = 'Database connection refused';
  } else if (err.message) {
    message = err.message;
  }

  res.status(statusCode).json({
    success: false,
    error: message,
    ...(process.env.NODE_ENV === 'development' && { stack: err.stack })
  });
};

const logError = async (err, req) => {
  try {
    await executeQuery(
      `INSERT INTO audit_logs (
        user_id, action, entity_type, entity_id, details, ip_address, user_agent, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())`,
      [
        req.session.user?.id || null,
        'ERROR',
        'system',
        null,
        JSON.stringify({
          error: err.message,
          stack: err.stack,
          url: req.originalUrl,
          method: req.method,
          body: req.body
        }),
        req.ip,
        req.get('User-Agent')
      ]
    );
  } catch (logError) {
    console.error('Error logging failed:', logError);
  }
};

module.exports = {
  errorHandler,
  logError
};