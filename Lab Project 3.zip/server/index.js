const express = require('express');
const cors = require('cors');
const session = require('express-session');
const MySQLStore = require('express-mysql-session')(session);
const compression = require('compression');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const path = require('path');
require('dotenv').config();

// Import database connection
const { testConnection } = require('../database/connection');

// Import middleware
const { logger } = require('./middleware/logger');
const { errorHandler } = require('./middleware/errorHandler');

// Import routes
const authRoutes = require('./routes/auth');
const adminRoutes = require('./routes/admin');
const centersRoutes = require('./routes/centers');
const patientsRoutes = require('./routes/patients');
const reportsRoutes = require('./routes/reports');
const billsRoutes = require('./routes/bills');
const exportsRoutes = require('./routes/exports');

const app = express();
const PORT = process.env.PORT || 3001;
const NODE_ENV = process.env.NODE_ENV || 'development';

// Security middleware
app.use(helmet({
  contentSecurityPolicy: NODE_ENV === 'production' ? undefined : false,
  crossOriginEmbedderPolicy: false
}));

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: NODE_ENV === 'production' ? 100 : 1000, // Limit each IP to 100 requests per windowMs in production
  message: 'Too many requests from this IP, please try again later.'
});
app.use('/api/', limiter);

// CORS configuration
const corsOptions = {
  origin: function (origin, callback) {
    // Allow requests with no origin (like mobile apps or curl requests)
    if (!origin) return callback(null, true);
    
    const allowedOrigins = [
      'http://localhost:3000',
      'http://localhost:5173',
      'http://127.0.0.1:3000',
      'http://127.0.0.1:5173',
      process.env.FRONTEND_URL
    ].filter(Boolean);

    if (allowedOrigins.includes(origin) || NODE_ENV === 'development') {
      callback(null, true);
    } else {
      callback(new Error('Not allowed by CORS'));
    }
  },
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With'],
  optionsSuccessStatus: 200
};

app.use(cors(corsOptions));

// Basic middleware
app.use(compression());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Logging middleware
app.use(logger);

// Session configuration
let sessionStore;
const sessionConfig = {
  secret: process.env.SESSION_SECRET || 'composcale-secret-key-change-in-production',
  resave: false,
  saveUninitialized: false,
  cookie: {
    secure: NODE_ENV === 'production',
    httpOnly: true,
    maxAge: 24 * 60 * 60 * 1000, // 24 hours
    sameSite: NODE_ENV === 'production' ? 'strict' : 'lax'
  },
  name: 'composcale.sid'
};

// Try to use MySQL session store if available
if (process.env.DB_HOST) {
  try {
    sessionStore = new MySQLStore({
      host: process.env.DB_HOST,
      port: process.env.DB_PORT || 3306,
      user: process.env.DB_USER,
      password: process.env.DB_PASSWORD,
      database: process.env.DB_NAME,
      createDatabaseTable: true,
      schema: {
        tableName: 'sessions',
        columnNames: {
          session_id: 'session_id',
          expires: 'expires',
          data: 'data'
        }
      }
    });
    sessionConfig.store = sessionStore;
    console.log('✅ Using MySQL session store');
  } catch (error) {
    console.log('⚠️ MySQL session store failed, using memory store:', error.message);
  }
}

app.use(session(sessionConfig));

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({
    success: true,
    message: 'Composcale.com API is running',
    timestamp: new Date().toISOString(),
    environment: NODE_ENV,
    version: '1.0.0'
  });
});

// Database health check
app.get('/api/health/database', async (req, res) => {
  try {
    const isConnected = await testConnection();
    res.json({
      success: true,
      database: isConnected ? 'connected' : 'disconnected',
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Database connection failed',
      message: error.message
    });
  }
});

// API Routes
app.use('/api/auth', authRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/centers', centersRoutes);
app.use('/api/patients', patientsRoutes);
app.use('/api/reports', reportsRoutes);
app.use('/api/bills', billsRoutes);
app.use('/api/exports', exportsRoutes);

// Serve static files in production
if (NODE_ENV === 'production') {
  const staticPath = path.join(__dirname, '../dist');
  app.use(express.static(staticPath));
  
  // Handle React Router routes
  app.get('*', (req, res) => {
    res.sendFile(path.join(staticPath, 'index.html'));
  });
}

// 404 handler for API routes
app.use('/api/*', (req, res) => {
  res.status(404).json({
    success: false,
    error: 'API endpoint not found',
    message: `${req.method} ${req.originalUrl} not found`
  });
});

// Error handling middleware
app.use(errorHandler);

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM received. Shutting down gracefully...');
  server.close(() => {
    console.log('Server closed');
    if (sessionStore && sessionStore.close) {
      sessionStore.close();
    }
    process.exit(0);
  });
});

process.on('SIGINT', () => {
  console.log('SIGINT received. Shutting down gracefully...');
  server.close(() => {
    console.log('Server closed');
    if (sessionStore && sessionStore.close) {
      sessionStore.close();
    }
    process.exit(0);
  });
});

// Start server
const server = app.listen(PORT, () => {
  console.log('\n🚀 Composcale.com Server Started');
  console.log('==================================');
  console.log(`🌐 Server running on: http://localhost:${PORT}`);
  console.log(`📚 API Documentation: http://localhost:${PORT}/api/health`);
  console.log(`🔧 Environment: ${NODE_ENV}`);
  console.log(`⏰ Started at: ${new Date().toLocaleString()}`);
  
  // Test database connection on startup
  testConnection().then(isConnected => {
    if (isConnected) {
      console.log('✅ Database connection successful');
    } else {
      console.log('⚠️  Database connection failed - running in offline mode');
    }
  }).catch(error => {
    console.log('❌ Database connection error:', error.message);
  });
  
  console.log('\n📋 Available API endpoints:');
  console.log('- GET  /api/health - Health check');
  console.log('- POST /api/auth/login - User login');
  console.log('- GET  /api/auth/me - Current user');
  console.log('- POST /api/auth/logout - User logout');
  console.log('\n🎯 Ready to accept requests!\n');
});

module.exports = app;