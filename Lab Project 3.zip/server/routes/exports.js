const express = require('express');
const router = express.Router();
const { validateRole } = require('../middleware/auth');
const { v4: uuidv4 } = require('uuid');

// Get export history
router.get('/', validateRole(['diagnostic_center', 'super_admin']), async (req, res) => {
  try {
    const centerId = req.user.role === 'super_admin' ? req.query.centerId : req.user.centerId;
    
    if (!centerId && req.user.role !== 'super_admin') {
      return res.status(400).json({ error: 'Center ID is required' });
    }

    const { executeQuery } = require('../../database/connection');
    
    let query = 'SELECT * FROM report_exports';
    const params = [];
    
    if (centerId) {
      query += ' WHERE center_id = ?';
      params.push(centerId);
    }
    
    query += ' ORDER BY generated_date DESC LIMIT 50';
    
    const result = await executeQuery(query, params);
    
    if (!result.success) {
      return res.status(500).json({ error: result.error });
    }

    res.json({ success: true, data: result.data });
  } catch (error) {
    console.error('Error fetching exports:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Create new export
router.post('/', validateRole(['diagnostic_center', 'super_admin']), async (req, res) => {
  try {
    const { reportType, periodType, startDate, endDate } = req.body;
    const centerId = req.user.role === 'super_admin' ? req.body.centerId : req.user.centerId;
    
    if (!centerId) {
      return res.status(400).json({ error: 'Center ID is required' });
    }

    // Validate required fields
    const requiredFields = ['reportType', 'periodType', 'startDate', 'endDate'];
    for (const field of requiredFields) {
      if (!req.body[field]) {
        return res.status(400).json({ error: `${field} is required` });
      }
    }

    const exportId = uuidv4();
    const { executeQuery } = require('../../database/connection');
    
    const query = `
      INSERT INTO report_exports (
        id, center_id, report_type, period_type, start_date, end_date, status
      ) VALUES (?, ?, ?, ?, ?, ?, 'generating')
    `;
    
    const result = await executeQuery(query, [
      exportId, centerId, reportType, periodType, startDate, endDate
    ]);
    
    if (!result.success) {
      return res.status(500).json({ error: result.error });
    }

    // In a real application, this would trigger a background job
    // For now, we'll simulate the export process
    setTimeout(async () => {
      try {
        const data = await generateExportData(centerId, reportType, startDate, endDate);
        const downloadUrl = `/api/exports/${exportId}/download`;
        
        await executeQuery(
          'UPDATE report_exports SET status = ?, download_url = ?, expires_at = DATE_ADD(NOW(), INTERVAL 7 DAY) WHERE id = ?',
          ['ready', downloadUrl, exportId]
        );
      } catch (error) {
        console.error('Export generation failed:', error);
        await executeQuery(
          'UPDATE report_exports SET status = ? WHERE id = ?',
          ['expired', exportId]
        );
      }
    }, 2000); // 2 second delay to simulate processing

    res.status(201).json({ 
      success: true, 
      data: { 
        id: exportId, 
        status: 'generating',
        message: 'Export job started. You will be notified when ready.'
      }
    });
  } catch (error) {
    console.error('Error creating export:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get export status
router.get('/:id/status', validateRole(['diagnostic_center', 'super_admin']), async (req, res) => {
  try {
    const { id } = req.params;
    const { executeQuery } = require('../../database/connection');
    
    const query = 'SELECT * FROM report_exports WHERE id = ?';
    const result = await executeQuery(query, [id]);
    
    if (!result.success) {
      return res.status(500).json({ error: result.error });
    }

    if (result.data.length === 0) {
      return res.status(404).json({ error: 'Export not found' });
    }

    const exportData = result.data[0];
    
    // Check access permissions
    if (req.user.role === 'diagnostic_center' && exportData.center_id !== req.user.centerId) {
      return res.status(403).json({ error: 'Access denied' });
    }

    res.json({ success: true, data: exportData });
  } catch (error) {
    console.error('Error fetching export status:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Download export
router.get('/:id/download', validateRole(['diagnostic_center', 'super_admin']), async (req, res) => {
  try {
    const { id } = req.params;
    const { executeQuery } = require('../../database/connection');
    
    const query = 'SELECT * FROM report_exports WHERE id = ? AND status = "ready"';
    const result = await executeQuery(query, [id]);
    
    if (!result.success) {
      return res.status(500).json({ error: result.error });
    }

    if (result.data.length === 0) {
      return res.status(404).json({ error: 'Export not found or not ready' });
    }

    const exportData = result.data[0];
    
    // Check access permissions
    if (req.user.role === 'diagnostic_center' && exportData.center_id !== req.user.centerId) {
      return res.status(403).json({ error: 'Access denied' });
    }

    // Check if export is expired
    if (exportData.expires_at && new Date(exportData.expires_at) < new Date()) {
      return res.status(410).json({ error: 'Export has expired' });
    }

    // Generate the actual export data
    const data = await generateExportData(
      exportData.center_id, 
      exportData.report_type, 
      exportData.start_date, 
      exportData.end_date
    );

    // Set headers for file download
    const filename = `${exportData.report_type}_${exportData.start_date}_${exportData.end_date}.json`;
    res.setHeader('Content-Type', 'application/json');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    
    res.json({
      metadata: {
        exportId: id,
        reportType: exportData.report_type,
        period: `${exportData.start_date} to ${exportData.end_date}`,
        generatedAt: exportData.generated_date,
        recordCount: data.length
      },
      data: data
    });
  } catch (error) {
    console.error('Error downloading export:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Helper function to generate export data
async function generateExportData(centerId, reportType, startDate, endDate) {
  const { executeQuery } = require('../../database/connection');
  
  let query = '';
  let params = [centerId, startDate, endDate];
  
  switch (reportType) {
    case 'patients':
      query = `
        SELECT p.*, dc.name as center_name
        FROM patients p
        LEFT JOIN diagnostic_centers dc ON p.center_id = dc.id
        WHERE p.center_id = ? AND p.created_date BETWEEN ? AND ?
        ORDER BY p.created_date DESC
      `;
      break;
      
    case 'reports':
      query = `
        SELECT tr.*, p.full_name as patient_name, dc.name as center_name
        FROM test_reports tr
        LEFT JOIN patients p ON tr.patient_id = p.id
        LEFT JOIN diagnostic_centers dc ON tr.center_id = dc.id
        WHERE tr.center_id = ? AND tr.created_at BETWEEN ? AND ?
        ORDER BY tr.created_at DESC
      `;
      break;
      
    case 'bills':
      query = `
        SELECT b.*, p.full_name as patient_name, dc.name as center_name
        FROM bills b
        LEFT JOIN patients p ON b.patient_id = p.id
        LEFT JOIN diagnostic_centers dc ON b.center_id = dc.id
        WHERE b.center_id = ? AND b.created_date BETWEEN ? AND ?
        ORDER BY b.created_date DESC
      `;
      break;
      
    case 'comprehensive':
      // For comprehensive, we'll return a summary of all data
      const patientsResult = await executeQuery(`
        SELECT COUNT(*) as patient_count FROM patients 
        WHERE center_id = ? AND created_date BETWEEN ? AND ?
      `, params);
      
      const reportsResult = await executeQuery(`
        SELECT COUNT(*) as report_count, 
               SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_reports,
               SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending_reports
        FROM test_reports 
        WHERE center_id = ? AND created_at BETWEEN ? AND ?
      `, params);
      
      const billsResult = await executeQuery(`
        SELECT COUNT(*) as bill_count,
               SUM(CASE WHEN status = 'paid' THEN final_amount ELSE 0 END) as total_revenue,
               SUM(CASE WHEN status = 'pending' THEN final_amount ELSE 0 END) as pending_amount
        FROM bills 
        WHERE center_id = ? AND created_date BETWEEN ? AND ?
      `, params);
      
      return {
        summary: {
          period: `${startDate} to ${endDate}`,
          patients: patientsResult.success ? patientsResult.data[0] : {},
          reports: reportsResult.success ? reportsResult.data[0] : {},
          bills: billsResult.success ? billsResult.data[0] : {}
        }
      };
      
    default:
      throw new Error('Invalid report type');
  }
  
  const result = await executeQuery(query, params);
  
  if (!result.success) {
    throw new Error(result.error);
  }
  
  return result.data;
}

module.exports = router;