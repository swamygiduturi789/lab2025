const express = require('express');
const router = express.Router();
const { PatientModel } = require('../../database/models');
const { validateRole } = require('../middleware/auth');

// Get all patients for a diagnostic center
router.get('/', validateRole(['diagnostic_center', 'super_admin']), async (req, res) => {
  try {
    const { search, limit } = req.query;
    const centerId = req.user.role === 'super_admin' ? req.query.centerId : req.user.centerId;
    
    if (!centerId && req.user.role !== 'super_admin') {
      return res.status(400).json({ error: 'Center ID is required' });
    }

    const filters = { search, limit };
    const result = await PatientModel.getByCenterId(centerId, filters);
    
    if (!result.success) {
      return res.status(500).json({ error: result.error });
    }

    res.json({ success: true, data: result.data });
  } catch (error) {
    console.error('Error fetching patients:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get patient by ID
router.get('/:id', validateRole(['diagnostic_center', 'super_admin']), async (req, res) => {
  try {
    const { id } = req.params;
    const result = await PatientModel.findById(id);
    
    if (!result.success) {
      return res.status(500).json({ error: result.error });
    }

    if (result.data.length === 0) {
      return res.status(404).json({ error: 'Patient not found' });
    }

    const patient = result.data[0];
    
    // Check if user has access to this patient
    if (req.user.role === 'diagnostic_center' && patient.center_id !== req.user.centerId) {
      return res.status(403).json({ error: 'Access denied' });
    }

    res.json({ success: true, data: patient });
  } catch (error) {
    console.error('Error fetching patient:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Find patient by passcode
router.post('/find-by-passcode', async (req, res) => {
  try {
    const { passcode, centerId } = req.body;
    
    if (!passcode) {
      return res.status(400).json({ error: 'Passcode is required' });
    }

    const result = await PatientModel.findByPasscode(passcode, centerId);
    
    if (!result.success) {
      return res.status(500).json({ error: result.error });
    }

    if (result.data.length === 0) {
      return res.status(404).json({ error: 'Patient not found with provided passcode' });
    }

    const patient = result.data[0];
    
    // Remove sensitive information
    delete patient.passcode;
    
    res.json({ success: true, data: patient });
  } catch (error) {
    console.error('Error finding patient by passcode:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Create new patient
router.post('/', validateRole(['diagnostic_center', 'super_admin']), async (req, res) => {
  try {
    const patientData = req.body;
    
    // Set center ID from user context if not provided
    if (!patientData.centerId && req.user.role === 'diagnostic_center') {
      patientData.centerId = req.user.centerId;
    }

    // Generate passcode if not provided
    if (!patientData.passcode) {
      patientData.passcode = await PatientModel.generatePasscode();
    }

    // Validate required fields
    const requiredFields = ['fullName', 'phone', 'address', 'city', 'state', 'pincode', 'centerId'];
    for (const field of requiredFields) {
      if (!patientData[field]) {
        return res.status(400).json({ error: `${field} is required` });
      }
    }

    const result = await PatientModel.create(patientData);
    
    if (!result.success) {
      return res.status(500).json({ error: result.error });
    }

    res.status(201).json({ success: true, data: result.data });
  } catch (error) {
    console.error('Error creating patient:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Update patient
router.put('/:id', validateRole(['diagnostic_center', 'super_admin']), async (req, res) => {
  try {
    const { id } = req.params;
    const updateData = req.body;

    // First, check if patient exists and user has access
    const existingResult = await PatientModel.findById(id);
    if (!existingResult.success || existingResult.data.length === 0) {
      return res.status(404).json({ error: 'Patient not found' });
    }

    const existingPatient = existingResult.data[0];
    if (req.user.role === 'diagnostic_center' && existingPatient.center_id !== req.user.centerId) {
      return res.status(403).json({ error: 'Access denied' });
    }

    // Remove fields that shouldn't be updated directly
    delete updateData.id;
    delete updateData.centerId;
    delete updateData.passcode;
    delete updateData.createdDate;

    const result = await PatientModel.update(id, updateData);
    
    if (!result.success) {
      return res.status(500).json({ error: result.error });
    }

    res.json({ success: true, message: 'Patient updated successfully' });
  } catch (error) {
    console.error('Error updating patient:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Generate new passcode for patient
router.post('/:id/generate-passcode', validateRole(['diagnostic_center', 'super_admin']), async (req, res) => {
  try {
    const { id } = req.params;

    // Check if patient exists and user has access
    const existingResult = await PatientModel.findById(id);
    if (!existingResult.success || existingResult.data.length === 0) {
      return res.status(404).json({ error: 'Patient not found' });
    }

    const existingPatient = existingResult.data[0];
    if (req.user.role === 'diagnostic_center' && existingPatient.center_id !== req.user.centerId) {
      return res.status(403).json({ error: 'Access denied' });
    }

    const newPasscode = await PatientModel.generatePasscode();
    const result = await PatientModel.update(id, { passcode: newPasscode });
    
    if (!result.success) {
      return res.status(500).json({ error: result.error });
    }

    res.json({ success: true, data: { passcode: newPasscode } });
  } catch (error) {
    console.error('Error generating new passcode:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get patient statistics
router.get('/stats/overview', validateRole(['diagnostic_center', 'super_admin']), async (req, res) => {
  try {
    const centerId = req.user.role === 'super_admin' ? req.query.centerId : req.user.centerId;
    
    if (!centerId && req.user.role !== 'super_admin') {
      return res.status(400).json({ error: 'Center ID is required' });
    }

    // Get patient statistics
    const result = await PatientModel.getByCenterId(centerId);
    
    if (!result.success) {
      return res.status(500).json({ error: result.error });
    }

    const patients = result.data;
    const stats = {
      total: patients.length,
      recentRegistrations: patients.filter(p => {
        const createdDate = new Date(p.created_date);
        const thirtyDaysAgo = new Date();
        thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
        return createdDate >= thirtyDaysAgo;
      }).length,
      byGender: {
        male: patients.filter(p => p.gender === 'male').length,
        female: patients.filter(p => p.gender === 'female').length,
        other: patients.filter(p => p.gender === 'other').length,
        notSpecified: patients.filter(p => !p.gender).length
      },
      byBloodGroup: {}
    };

    // Count blood groups
    patients.forEach(patient => {
      if (patient.blood_group) {
        stats.byBloodGroup[patient.blood_group] = (stats.byBloodGroup[patient.blood_group] || 0) + 1;
      }
    });

    res.json({ success: true, data: stats });
  } catch (error) {
    console.error('Error fetching patient statistics:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

module.exports = router;