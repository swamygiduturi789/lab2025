const express = require('express');
const router = express.Router();
const { BillModel, PatientModel } = require('../../database/models');
const { validateRole } = require('../middleware/auth');

// Get all bills for a diagnostic center
router.get('/', validateRole(['diagnostic_center', 'super_admin']), async (req, res) => {
  try {
    const { status, startDate, endDate, limit } = req.query;
    const centerId = req.user.role === 'super_admin' ? req.query.centerId : req.user.centerId;
    
    if (!centerId && req.user.role !== 'super_admin') {
      return res.status(400).json({ error: 'Center ID is required' });
    }

    const filters = { status, startDate, endDate, limit };
    const result = await BillModel.getByCenterId(centerId, filters);
    
    if (!result.success) {
      return res.status(500).json({ error: result.error });
    }

    res.json({ success: true, data: result.data });
  } catch (error) {
    console.error('Error fetching bills:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get bill by ID with tests
router.get('/:id', validateRole(['diagnostic_center', 'super_admin', 'patient']), async (req, res) => {
  try {
    const { id } = req.params;
    const result = await BillModel.findById(id);
    
    if (!result.success) {
      return res.status(500).json({ error: result.error });
    }

    if (result.data.length === 0) {
      return res.status(404).json({ error: 'Bill not found' });
    }

    const bill = result.data[0];
    
    // Check access permissions
    if (req.user.role === 'diagnostic_center' && bill.center_id !== req.user.centerId) {
      return res.status(403).json({ error: 'Access denied' });
    }
    
    if (req.user.role === 'patient' && bill.patient_id !== req.user.patientId) {
      return res.status(403).json({ error: 'Access denied' });
    }

    res.json({ success: true, data: bill });
  } catch (error) {
    console.error('Error fetching bill:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get bills by patient ID
router.get('/patient/:patientId', validateRole(['diagnostic_center', 'super_admin', 'patient']), async (req, res) => {
  try {
    const { patientId } = req.params;
    
    // Check access permissions
    if (req.user.role === 'patient' && patientId !== req.user.patientId) {
      return res.status(403).json({ error: 'Access denied' });
    }

    const result = await BillModel.getByPatientId(patientId);
    
    if (!result.success) {
      return res.status(500).json({ error: result.error });
    }

    // For diagnostic centers, ensure they only see bills from their center
    let bills = result.data;
    if (req.user.role === 'diagnostic_center') {
      bills = bills.filter(bill => bill.center_id === req.user.centerId);
    }

    res.json({ success: true, data: bills });
  } catch (error) {
    console.error('Error fetching patient bills:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Create new bill
router.post('/', validateRole(['diagnostic_center', 'super_admin']), async (req, res) => {
  try {
    const billData = req.body;
    
    // Set center ID from user context if not provided
    if (!billData.centerId && req.user.role === 'diagnostic_center') {
      billData.centerId = req.user.centerId;
    }

    // Generate invoice number if not provided
    if (!billData.invoiceNumber) {
      billData.invoiceNumber = await BillModel.generateInvoiceNumber(billData.centerId);
    }

    // Validate required fields
    const requiredFields = ['patientId', 'centerId', 'amount', 'finalAmount'];
    for (const field of requiredFields) {
      if (!billData[field]) {
        return res.status(400).json({ error: `${field} is required` });
      }
    }

    // Verify patient exists and belongs to the center
    const patientResult = await PatientModel.findById(billData.patientId);
    if (!patientResult.success || patientResult.data.length === 0) {
      return res.status(404).json({ error: 'Patient not found' });
    }

    const patient = patientResult.data[0];
    if (req.user.role === 'diagnostic_center' && patient.center_id !== req.user.centerId) {
      return res.status(403).json({ error: 'Patient does not belong to your center' });
    }

    // Set default status if not provided
    if (!billData.status) {
      billData.status = 'pending';
    }

    const result = await BillModel.create(billData);
    
    if (!result.success) {
      return res.status(500).json({ error: result.error });
    }

    res.status(201).json({ success: true, data: result.data });
  } catch (error) {
    console.error('Error creating bill:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Update bill payment status
router.put('/:id/payment', validateRole(['diagnostic_center', 'super_admin']), async (req, res) => {
  try {
    const { id } = req.params;
    const { status, paymentData } = req.body;

    if (!status) {
      return res.status(400).json({ error: 'Payment status is required' });
    }

    // Check if bill exists and user has access
    const existingResult = await BillModel.findById(id);
    if (!existingResult.success || existingResult.data.length === 0) {
      return res.status(404).json({ error: 'Bill not found' });
    }

    const existingBill = existingResult.data[0];
    if (req.user.role === 'diagnostic_center' && existingBill.center_id !== req.user.centerId) {
      return res.status(403).json({ error: 'Access denied' });
    }

    // Add payment date if marking as paid
    const updateData = paymentData || {};
    if (status === 'paid' && !updateData.paymentDate) {
      updateData.paymentDate = new Date().toISOString().split('T')[0];
    }

    const result = await BillModel.updatePaymentStatus(id, status, updateData);
    
    if (!result.success) {
      return res.status(500).json({ error: result.error });
    }

    res.json({ success: true, message: 'Payment status updated successfully' });
  } catch (error) {
    console.error('Error updating payment status:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Update bill tests
router.put('/:id/tests', validateRole(['diagnostic_center', 'super_admin']), async (req, res) => {
  try {
    const { id } = req.params;
    const { tests } = req.body;

    if (!tests || !Array.isArray(tests)) {
      return res.status(400).json({ error: 'Tests array is required' });
    }

    // Check if bill exists and user has access
    const existingResult = await BillModel.findById(id);
    if (!existingResult.success || existingResult.data.length === 0) {
      return res.status(404).json({ error: 'Bill not found' });
    }

    const existingBill = existingResult.data[0];
    if (req.user.role === 'diagnostic_center' && existingBill.center_id !== req.user.centerId) {
      return res.status(403).json({ error: 'Access denied' });
    }

    // Delete existing tests and add new ones
    const { executeTransaction } = require('../../database/connection');
    
    const queries = [
      {
        query: 'DELETE FROM bill_tests WHERE bill_id = ?',
        params: [id]
      }
    ];

    // Add new tests
    tests.forEach(test => {
      queries.push({
        query: 'INSERT INTO bill_tests (bill_id, test_name, test_price) VALUES (?, ?, ?)',
        params: [id, test.name, test.price || 0]
      });
    });

    // Also update the bill amounts if provided
    if (req.body.amount && req.body.finalAmount) {
      queries.push({
        query: 'UPDATE bills SET amount = ?, final_amount = ?, tax = ?, total_tax = ? WHERE id = ?',
        params: [req.body.amount, req.body.finalAmount, req.body.tax || 0, req.body.totalTax || 0, id]
      });
    }

    const transactionResult = await executeTransaction(queries);
    
    if (!transactionResult.success) {
      return res.status(500).json({ error: transactionResult.error });
    }

    res.json({ success: true, message: 'Bill tests updated successfully' });
  } catch (error) {
    console.error('Error updating bill tests:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get bill statistics
router.get('/stats/overview', validateRole(['diagnostic_center', 'super_admin']), async (req, res) => {
  try {
    const centerId = req.user.role === 'super_admin' ? req.query.centerId : req.user.centerId;
    
    if (!centerId && req.user.role !== 'super_admin') {
      return res.status(400).json({ error: 'Center ID is required' });
    }

    const result = await BillModel.getByCenterId(centerId);
    
    if (!result.success) {
      return res.status(500).json({ error: result.error });
    }

    const bills = result.data;
    const now = new Date();
    const thisMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    const lastMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1);

    const stats = {
      total: bills.length,
      paid: bills.filter(b => b.status === 'paid').length,
      pending: bills.filter(b => b.status === 'pending').length,
      partiallyPaid: bills.filter(b => b.status === 'partially_paid').length,
      cancelled: bills.filter(b => b.status === 'cancelled').length,
      totalRevenue: bills.filter(b => b.status === 'paid').reduce((sum, b) => sum + parseFloat(b.final_amount), 0),
      pendingAmount: bills.filter(b => b.status === 'pending').reduce((sum, b) => sum + parseFloat(b.final_amount), 0),
      thisMonth: {
        count: bills.filter(b => new Date(b.created_date) >= thisMonth).length,
        revenue: bills.filter(b => new Date(b.created_date) >= thisMonth && b.status === 'paid')
          .reduce((sum, b) => sum + parseFloat(b.final_amount), 0)
      },
      lastMonth: {
        count: bills.filter(b => {
          const createdDate = new Date(b.created_date);
          return createdDate >= lastMonth && createdDate < thisMonth;
        }).length,
        revenue: bills.filter(b => {
          const createdDate = new Date(b.created_date);
          return createdDate >= lastMonth && createdDate < thisMonth && b.status === 'paid';
        }).reduce((sum, b) => sum + parseFloat(b.final_amount), 0)
      },
      byPaymentMode: {}
    };

    // Count by payment mode
    bills.forEach(bill => {
      if (bill.payment_mode) {
        stats.byPaymentMode[bill.payment_mode] = (stats.byPaymentMode[bill.payment_mode] || 0) + 1;
      }
    });

    res.json({ success: true, data: stats });
  } catch (error) {
    console.error('Error fetching bill statistics:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Generate invoice number
router.get('/generate-invoice-number', validateRole(['diagnostic_center', 'super_admin']), async (req, res) => {
  try {
    const centerId = req.user.role === 'super_admin' ? req.query.centerId : req.user.centerId;
    
    if (!centerId) {
      return res.status(400).json({ error: 'Center ID is required' });
    }

    const invoiceNumber = await BillModel.generateInvoiceNumber(centerId);
    
    res.json({ success: true, data: { invoiceNumber } });
  } catch (error) {
    console.error('Error generating invoice number:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

module.exports = router;