const express = require('express');
const router = express.Router();
const { TestReportModel, PatientModel } = require('../../database/models');
const { validateRole } = require('../middleware/auth');

// Get all reports for a diagnostic center
router.get('/', validateRole(['diagnostic_center', 'super_admin']), async (req, res) => {
  try {
    const { search, status, startDate, endDate, limit } = req.query;
    const centerId = req.user.role === 'super_admin' ? req.query.centerId : req.user.centerId;
    
    if (!centerId && req.user.role !== 'super_admin') {
      return res.status(400).json({ error: 'Center ID is required' });
    }

    const filters = { search, status, startDate, endDate, limit };
    const result = await TestReportModel.getByCenterId(centerId, filters);
    
    if (!result.success) {
      return res.status(500).json({ error: result.error });
    }

    res.json({ success: true, data: result.data });
  } catch (error) {
    console.error('Error fetching reports:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get report by ID with results
router.get('/:id', validateRole(['diagnostic_center', 'super_admin', 'patient']), async (req, res) => {
  try {
    const { id } = req.params;
    const result = await TestReportModel.findById(id);
    
    if (!result.success) {
      return res.status(500).json({ error: result.error });
    }

    if (result.data.length === 0) {
      return res.status(404).json({ error: 'Report not found' });
    }

    const report = result.data[0];
    
    // Check access permissions
    if (req.user.role === 'diagnostic_center' && report.center_id !== req.user.centerId) {
      return res.status(403).json({ error: 'Access denied' });
    }
    
    if (req.user.role === 'patient' && report.patient_id !== req.user.patientId) {
      return res.status(403).json({ error: 'Access denied' });
    }

    res.json({ success: true, data: report });
  } catch (error) {
    console.error('Error fetching report:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get reports by patient ID
router.get('/patient/:patientId', validateRole(['diagnostic_center', 'super_admin', 'patient']), async (req, res) => {
  try {
    const { patientId } = req.params;
    
    // Check access permissions
    if (req.user.role === 'patient' && patientId !== req.user.patientId) {
      return res.status(403).json({ error: 'Access denied' });
    }

    const result = await TestReportModel.getByPatientId(patientId);
    
    if (!result.success) {
      return res.status(500).json({ error: result.error });
    }

    // For diagnostic centers, ensure they only see reports from their center
    let reports = result.data;
    if (req.user.role === 'diagnostic_center') {
      reports = reports.filter(report => report.center_id === req.user.centerId);
    }

    res.json({ success: true, data: reports });
  } catch (error) {
    console.error('Error fetching patient reports:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Create new test report
router.post('/', validateRole(['diagnostic_center', 'super_admin']), async (req, res) => {
  try {
    const reportData = req.body;
    
    // Set center ID from user context if not provided
    if (!reportData.centerId && req.user.role === 'diagnostic_center') {
      reportData.centerId = req.user.centerId;
    }

    // Generate passcode ID if not provided
    if (!reportData.passcodeId) {
      const timestamp = Date.now().toString(36);
      const random = Math.random().toString(36).substr(2, 5);
      reportData.passcodeId = `PC${timestamp}${random}`.toUpperCase();
    }

    // Validate required fields
    const requiredFields = ['patientId', 'centerId', 'testType', 'testName', 'referredBy', 'sampleDate'];
    for (const field of requiredFields) {
      if (!reportData[field]) {
        return res.status(400).json({ error: `${field} is required` });
      }
    }

    // Verify patient exists and belongs to the center
    const patientResult = await PatientModel.findById(reportData.patientId);
    if (!patientResult.success || patientResult.data.length === 0) {
      return res.status(404).json({ error: 'Patient not found' });
    }

    const patient = patientResult.data[0];
    if (req.user.role === 'diagnostic_center' && patient.center_id !== req.user.centerId) {
      return res.status(403).json({ error: 'Patient does not belong to your center' });
    }

    const result = await TestReportModel.create(reportData);
    
    if (!result.success) {
      return res.status(500).json({ error: result.error });
    }

    res.status(201).json({ success: true, data: result.data });
  } catch (error) {
    console.error('Error creating report:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Update report status and details
router.put('/:id/status', validateRole(['diagnostic_center', 'super_admin']), async (req, res) => {
  try {
    const { id } = req.params;
    const { status, reportData } = req.body;

    if (!status) {
      return res.status(400).json({ error: 'Status is required' });
    }

    // Check if report exists and user has access
    const existingResult = await TestReportModel.findById(id);
    if (!existingResult.success || existingResult.data.length === 0) {
      return res.status(404).json({ error: 'Report not found' });
    }

    const existingReport = existingResult.data[0];
    if (req.user.role === 'diagnostic_center' && existingReport.center_id !== req.user.centerId) {
      return res.status(403).json({ error: 'Access denied' });
    }

    // Add report date if marking as completed
    const updateData = reportData || {};
    if (status === 'completed' && !updateData.reportDate) {
      updateData.reportDate = new Date().toISOString().split('T')[0];
    }

    const result = await TestReportModel.updateStatus(id, status, updateData);
    
    if (!result.success) {
      return res.status(500).json({ error: result.error });
    }

    res.json({ success: true, message: 'Report status updated successfully' });
  } catch (error) {
    console.error('Error updating report status:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Add or update test results for a report
router.put('/:id/results', validateRole(['diagnostic_center', 'super_admin']), async (req, res) => {
  try {
    const { id } = req.params;
    const { results } = req.body;

    if (!results || !Array.isArray(results)) {
      return res.status(400).json({ error: 'Results array is required' });
    }

    // Check if report exists and user has access
    const existingResult = await TestReportModel.findById(id);
    if (!existingResult.success || existingResult.data.length === 0) {
      return res.status(404).json({ error: 'Report not found' });
    }

    const existingReport = existingResult.data[0];
    if (req.user.role === 'diagnostic_center' && existingReport.center_id !== req.user.centerId) {
      return res.status(403).json({ error: 'Access denied' });
    }

    // Delete existing results and add new ones
    const { executeTransaction } = require('../../database/connection');
    
    const queries = [
      {
        query: 'DELETE FROM test_results WHERE report_id = ?',
        params: [id]
      }
    ];

    // Add new results
    results.forEach(result => {
      queries.push({
        query: `
          INSERT INTO test_results (
            report_id, parameter_name, value, unit, reference_range, status, flag
          ) VALUES (?, ?, ?, ?, ?, ?, ?)
        `,
        params: [
          id, result.parameter, result.value, result.unit,
          result.reference, result.status || 'normal', result.flag
        ]
      });
    });

    const transactionResult = await executeTransaction(queries);
    
    if (!transactionResult.success) {
      return res.status(500).json({ error: transactionResult.error });
    }

    res.json({ success: true, message: 'Test results updated successfully' });
  } catch (error) {
    console.error('Error updating test results:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get report statistics
router.get('/stats/overview', validateRole(['diagnostic_center', 'super_admin']), async (req, res) => {
  try {
    const centerId = req.user.role === 'super_admin' ? req.query.centerId : req.user.centerId;
    
    if (!centerId && req.user.role !== 'super_admin') {
      return res.status(400).json({ error: 'Center ID is required' });
    }

    const result = await TestReportModel.getByCenterId(centerId);
    
    if (!result.success) {
      return res.status(500).json({ error: result.error });
    }

    const reports = result.data;
    const now = new Date();
    const thisMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    const lastMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1);

    const stats = {
      total: reports.length,
      completed: reports.filter(r => r.status === 'completed').length,
      pending: reports.filter(r => r.status === 'pending').length,
      thisMonth: reports.filter(r => new Date(r.created_at) >= thisMonth).length,
      lastMonth: reports.filter(r => {
        const createdDate = new Date(r.created_at);
        return createdDate >= lastMonth && createdDate < thisMonth;
      }).length,
      byTestType: {},
      byPriority: {
        normal: reports.filter(r => r.priority === 'normal' || !r.priority).length,
        urgent: reports.filter(r => r.priority === 'urgent').length,
        stat: reports.filter(r => r.priority === 'stat').length
      }
    };

    // Count by test type
    reports.forEach(report => {
      stats.byTestType[report.test_type] = (stats.byTestType[report.test_type] || 0) + 1;
    });

    res.json({ success: true, data: stats });
  } catch (error) {
    console.error('Error fetching report statistics:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Search reports by passcode
router.post('/search-by-passcode', async (req, res) => {
  try {
    const { passcode } = req.body;
    
    if (!passcode) {
      return res.status(400).json({ error: 'Passcode is required' });
    }

    const { executeQuery } = require('../../database/connection');
    
    const query = `
      SELECT tr.*, p.full_name as patient_name, dc.name as center_name,
             GROUP_CONCAT(CONCAT(trs.parameter_name, ':', trs.value, ':', trs.unit) SEPARATOR '|') as results
      FROM test_reports tr
      LEFT JOIN patients p ON tr.patient_id = p.id
      LEFT JOIN diagnostic_centers dc ON tr.center_id = dc.id
      LEFT JOIN test_results trs ON tr.id = trs.report_id
      WHERE tr.passcode_id = ? OR p.passcode = ?
      GROUP BY tr.id
      ORDER BY tr.created_at DESC
    `;
    
    const result = await executeQuery(query, [passcode, passcode]);
    
    if (!result.success) {
      return res.status(500).json({ error: result.error });
    }

    if (result.data.length === 0) {
      return res.status(404).json({ error: 'No reports found with provided passcode' });
    }

    // Parse results
    const reports = result.data.map(report => ({
      ...report,
      results: report.results ? report.results.split('|').map(r => {
        const [parameter, value, unit] = r.split(':');
        return { parameter, value, unit };
      }) : []
    }));

    res.json({ success: true, data: reports });
  } catch (error) {
    console.error('Error searching reports by passcode:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

module.exports = router;