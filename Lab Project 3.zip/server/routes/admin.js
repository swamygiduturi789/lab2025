const express = require('express');
const router = express.Router();
const { UserModel, DiagnosticCenterModel, PatientModel, TestReportModel, BillModel } = require('../../database/models');
const { validateRole } = require('../middleware/auth');
const { getDatabaseStats } = require('../../database/connection');

// Super admin only routes
router.use(validateRole(['super_admin']));

// Get dashboard statistics
router.get('/stats/dashboard', async (req, res) => {
  try {
    const dbStats = await getDatabaseStats();
    
    if (!dbStats.success) {
      return res.status(500).json({ error: dbStats.error });
    }

    // Get additional statistics
    const centersResult = await DiagnosticCenterModel.getAll();
    const activeStatResult = await DiagnosticCenterModel.getStats();
    
    const stats = {
      ...dbStats.data,
      centers: {
        total: centersResult.success ? centersResult.data.length : 0,
        active: centersResult.success ? centersResult.data.filter(c => c.is_active).length : 0,
        inactive: centersResult.success ? centersResult.data.filter(c => !c.is_active).length : 0,
        ...activeStatResult.data
      }
    };

    res.json({ success: true, data: stats });
  } catch (error) {
    console.error('Error fetching admin dashboard stats:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get all users
router.get('/users', async (req, res) => {
  try {
    const { role, limit } = req.query;
    const result = await UserModel.getAll(role);
    
    if (!result.success) {
      return res.status(500).json({ error: result.error });
    }

    let users = result.data;
    if (limit) {
      users = users.slice(0, parseInt(limit));
    }

    res.json({ success: true, data: users });
  } catch (error) {
    console.error('Error fetching users:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Create new user
router.post('/users', async (req, res) => {
  try {
    const userData = req.body;
    
    // Validate required fields
    const requiredFields = ['username', 'password', 'role', 'name'];
    for (const field of requiredFields) {
      if (!userData[field]) {
        return res.status(400).json({ error: `${field} is required` });
      }
    }

    // Check if username already exists
    const existingUser = await UserModel.findByUsername(userData.username);
    if (existingUser.success && existingUser.data.length > 0) {
      return res.status(409).json({ error: 'Username already exists' });
    }

    const result = await UserModel.create(userData);
    
    if (!result.success) {
      return res.status(500).json({ error: result.error });
    }

    res.status(201).json({ success: true, data: result.data });
  } catch (error) {
    console.error('Error creating user:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get all diagnostic centers
router.get('/centers', async (req, res) => {
  try {
    const filters = req.query;
    const result = await DiagnosticCenterModel.getAll(filters);
    
    if (!result.success) {
      return res.status(500).json({ error: result.error });
    }

    res.json({ success: true, data: result.data });
  } catch (error) {
    console.error('Error fetching centers:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Create new diagnostic center
router.post('/centers', async (req, res) => {
  try {
    const centerData = req.body;
    
    // Validate required fields
    const requiredFields = ['name', 'address', 'city', 'state', 'pincode', 'ownerName', 'ownerPhone', 'ownerEmail', 'username', 'password'];
    for (const field of requiredFields) {
      if (!centerData[field]) {
        return res.status(400).json({ error: `${field} is required` });
      }
    }

    // Check if username already exists
    const existingUser = await UserModel.findByUsername(centerData.username);
    if (existingUser.success && existingUser.data.length > 0) {
      return res.status(409).json({ error: 'Username already exists' });
    }

    const result = await DiagnosticCenterModel.create(centerData);
    
    if (!result.success) {
      return res.status(500).json({ error: result.error });
    }

    res.status(201).json({ success: true, data: result.data });
  } catch (error) {
    console.error('Error creating diagnostic center:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Update diagnostic center
router.put('/centers/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const updateData = req.body;

    // Remove fields that shouldn't be updated directly
    delete updateData.id;
    delete updateData.username;
    delete updateData.password;
    delete updateData.createdDate;

    const result = await DiagnosticCenterModel.update(id, updateData);
    
    if (!result.success) {
      return res.status(500).json({ error: result.error });
    }

    res.json({ success: true, message: 'Diagnostic center updated successfully' });
  } catch (error) {
    console.error('Error updating diagnostic center:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get center details
router.get('/centers/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const result = await DiagnosticCenterModel.findById(id);
    
    if (!result.success) {
      return res.status(500).json({ error: result.error });
    }

    if (result.data.length === 0) {
      return res.status(404).json({ error: 'Diagnostic center not found' });
    }

    res.json({ success: true, data: result.data[0] });
  } catch (error) {
    console.error('Error fetching diagnostic center:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get center statistics
router.get('/centers/:id/stats', async (req, res) => {
  try {
    const { id } = req.params;
    const result = await DiagnosticCenterModel.getStats(id);
    
    if (!result.success) {
      return res.status(500).json({ error: result.error });
    }

    res.json({ success: true, data: result.data[0] });
  } catch (error) {
    console.error('Error fetching center statistics:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// System settings management
router.get('/settings', async (req, res) => {
  try {
    const { executeQuery } = require('../../database/connection');
    const query = 'SELECT * FROM system_settings ORDER BY setting_key';
    const result = await executeQuery(query);
    
    if (!result.success) {
      return res.status(500).json({ error: result.error });
    }

    res.json({ success: true, data: result.data });
  } catch (error) {
    console.error('Error fetching system settings:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Update system setting
router.put('/settings/:key', async (req, res) => {
  try {
    const { key } = req.params;
    const { value, description } = req.body;

    if (value === undefined) {
      return res.status(400).json({ error: 'Setting value is required' });
    }

    const { executeQuery } = require('../../database/connection');
    const query = `
      UPDATE system_settings 
      SET setting_value = ?, description = COALESCE(?, description), updated_by = ?, updated_at = CURRENT_TIMESTAMP 
      WHERE setting_key = ?
    `;
    
    const result = await executeQuery(query, [value, description, req.user.id, key]);
    
    if (!result.success) {
      return res.status(500).json({ error: result.error });
    }

    res.json({ success: true, message: 'Setting updated successfully' });
  } catch (error) {
    console.error('Error updating system setting:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get audit logs
router.get('/audit-logs', async (req, res) => {
  try {
    const { limit = 100, offset = 0, action, table_name, user_id } = req.query;
    
    let query = `
      SELECT al.*, u.username, u.name as user_name
      FROM audit_logs al
      LEFT JOIN users u ON al.user_id = u.id
      WHERE 1=1
    `;
    
    const params = [];
    
    if (action) {
      query += ' AND al.action = ?';
      params.push(action);
    }
    
    if (table_name) {
      query += ' AND al.table_name = ?';
      params.push(table_name);
    }
    
    if (user_id) {
      query += ' AND al.user_id = ?';
      params.push(user_id);
    }
    
    query += ' ORDER BY al.created_at DESC LIMIT ? OFFSET ?';
    params.push(parseInt(limit), parseInt(offset));

    const { executeQuery } = require('../../database/connection');
    const result = await executeQuery(query, params);
    
    if (!result.success) {
      return res.status(500).json({ error: result.error });
    }

    res.json({ success: true, data: result.data });
  } catch (error) {
    console.error('Error fetching audit logs:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Database backup (trigger backup job)
router.post('/backup', async (req, res) => {
  try {
    // This would typically trigger a background job
    // For now, we'll just return success
    res.json({ 
      success: true, 
      message: 'Backup job initiated',
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('Error initiating backup:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// System health check
router.get('/health', async (req, res) => {
  try {
    const { testConnection } = require('../../database/connection');
    const isDbConnected = await testConnection();
    
    const health = {
      status: isDbConnected ? 'healthy' : 'unhealthy',
      timestamp: new Date().toISOString(),
      database: isDbConnected ? 'connected' : 'disconnected',
      version: process.env.APP_VERSION || '1.0.0',
      environment: process.env.NODE_ENV || 'development',
      uptime: process.uptime(),
      memory: process.memoryUsage()
    };

    const statusCode = isDbConnected ? 200 : 503;
    res.status(statusCode).json({ success: true, data: health });
  } catch (error) {
    console.error('Error checking system health:', error);
    res.status(503).json({ 
      success: false, 
      error: 'Health check failed',
      timestamp: new Date().toISOString()
    });
  }
});

module.exports = router;