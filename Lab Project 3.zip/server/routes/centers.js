const express = require('express');
const router = express.Router();
const { DiagnosticCenterModel } = require('../../database/models');
const { validateRole } = require('../middleware/auth');

// Get all centers (super admin only)
router.get('/', validateRole(['super_admin']), async (req, res) => {
  try {
    const filters = req.query;
    const result = await DiagnosticCenterModel.getAll(filters);
    
    if (!result.success) {
      return res.status(500).json({ error: result.error });
    }

    res.json({ success: true, data: result.data });
  } catch (error) {
    console.error('Error fetching centers:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get center by ID
router.get('/:id', validateRole(['super_admin', 'diagnostic_center']), async (req, res) => {
  try {
    const { id } = req.params;
    
    // Check if user has access to this center
    if (req.user.role === 'diagnostic_center' && id !== req.user.centerId) {
      return res.status(403).json({ error: 'Access denied' });
    }

    const result = await DiagnosticCenterModel.findById(id);
    
    if (!result.success) {
      return res.status(500).json({ error: result.error });
    }

    if (result.data.length === 0) {
      return res.status(404).json({ error: 'Center not found' });
    }

    res.json({ success: true, data: result.data[0] });
  } catch (error) {
    console.error('Error fetching center:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

module.exports = router;