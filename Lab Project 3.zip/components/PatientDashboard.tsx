import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { 
  LayoutDashboard, FileText, IndianRupee, Settings, LogOut, 
  Download, Calendar, User, Activity, Heart, Stethoscope, 
  ChevronLeft, Moon, Sun, Sparkles, Bell, Clock
} from 'lucide-react';
import { User as UserType, TestReport, Bill } from '../App';
import { useSidebar } from '../contexts/SidebarContext';

interface PatientDashboardProps {
  user: UserType;
  onLogout: () => void;
}

type DashboardView = 'dashboard' | 'reports' | 'bills' | 'settings';

// Mock data for patient
const mockReports: TestReport[] = [
  {
    id: '1',
    patientId: '3',
    centerId: '1',
    testType: 'Blood Test',
    testName: 'Complete Blood Count (CBC)',
    referredBy: 'Dr. Smith',
    sampleDate: '2024-06-15',
    reportDate: '2024-06-16',
    passcodeId: 'PC001',
    status: 'completed',
    results: [
      { parameter: 'Hemoglobin', value: '13.5', unit: 'g/dL', reference: '12.0-15.5' },
      { parameter: 'RBC Count', value: '4.2', unit: 'million/µL', reference: '3.8-5.2' },
    ]
  },
  {
    id: '2',
    patientId: '3',
    centerId: '1',
    testType: 'Urine Test',
    testName: 'Urine Routine & Microscopy',
    referredBy: 'Dr. Johnson',
    sampleDate: '2024-06-10',
    reportDate: '2024-06-11',
    passcodeId: 'PC002',
    status: 'completed',
    results: []
  }
];

const mockBills: Bill[] = [
  {
    id: '1',
    patientId: '3',
    centerId: '1',
    invoiceNumber: 'INV-2024-001',
    amount: 1500,
    discount: 150,
    finalAmount: 1350,
    status: 'paid',
    paymentDate: '2024-06-16',
    createdDate: '2024-06-15',
    tests: ['Complete Blood Count (CBC)']
  },
  {
    id: '2',
    patientId: '3',
    centerId: '1',
    invoiceNumber: 'INV-2024-002',
    amount: 800,
    discount: 0,
    finalAmount: 800,
    status: 'pending',
    createdDate: '2024-06-10',
    tests: ['Urine Routine & Microscopy']
  }
];

export function PatientDashboard({ user, onLogout }: PatientDashboardProps) {
  const [currentView, setCurrentView] = useState<DashboardView>('dashboard');
  const [isDarkMode, setIsDarkMode] = useState(false);
  const { isCollapsed, toggleSidebar, isMobile } = useSidebar();

  // Debug: Verify logout function is available
  React.useEffect(() => {
    if (process.env.NODE_ENV === 'development') {
      console.log('🔐 PatientDashboard - onLogout function:', typeof onLogout);
    }
  }, [onLogout]);

  const toggleDarkMode = () => {
    setIsDarkMode(!isDarkMode);
    document.documentElement.classList.toggle('dark');
  };

  const sidebarItems = [
    {
      id: 'dashboard',
      label: 'Dashboard',
      icon: LayoutDashboard,
      view: 'dashboard' as DashboardView,
    },
    {
      id: 'reports',
      label: 'My Reports',
      icon: FileText,
      view: 'reports' as DashboardView,
    },
    {
      id: 'bills',
      label: 'Bills & Payments',
      icon: IndianRupee,
      view: 'bills' as DashboardView,
    },
    {
      id: 'settings',
      label: 'Settings',
      icon: Settings,
      view: 'settings' as DashboardView,
    }
  ];

  const downloadReport = (report: TestReport) => {
    // Mock center and patient data
    const mockCenter = {
      id: '1',
      name: 'Apollo Diagnostics Mumbai',
      address: '123 MG Road, Fort',
      city: 'Mumbai',
      state: 'Maharashtra',
      pincode: '400001',
      ownerPhone: '+91-9876543210',
      ownerEmail: 'info@apollodiagnostics.com'
    };

    const mockPatient = {
      id: '3',
      fullName: user.name,
      phone: user.phone || '9876543210',
      address: '123 Patient Address',
      city: 'Mumbai',
      state: 'Maharashtra',
      pincode: '400001'
    };

    const mockCenterProfile = {
      logo: '/placeholder-logo.png',
      tagline: 'Your Health, Our Priority',
      licenseNumber: 'MH/MUM/2024/001',
      website: 'https://apollodiagnostics.com'
    };

    const logoSection = mockCenterProfile.logo ? `
      <div style="text-align: center; margin-bottom: 20px;">
        <img src="${mockCenterProfile.logo}" alt="${mockCenter.name} Logo" style="max-height: 80px; max-width: 200px; object-fit: contain;" />
      </div>
    ` : '';

    const htmlContent = `
      <!DOCTYPE html>
      <html>
        <head>
          <title>Medical Report - ${report.testName}</title>
          <meta charset="UTF-8">
          <style>
            @media print {
              @page { margin: 0.5in; size: A4; }
              body { color: #000 !important; background: white !important; font-size: 12px !important; padding: 0 !important; }
              .report-container { border: none !important; transform: scale(0.95); transform-origin: top left; }
              .header { padding: 15px !important; }
              .content { padding: 15px !important; }
              .results-table th, .results-table td { padding: 6px !important; font-size: 11px !important; }
              .footer { padding: 8px !important; font-size: 10px !important; }
            }
            body { font-family: Arial, sans-serif; margin: 0; padding: 20px; background: white; color: #333; line-height: 1.4; font-size: 13px; }
            .report-container { max-width: 800px; margin: 0 auto; background: white; border: 2px solid #2563eb; border-radius: 8px; overflow: hidden; }
            .header { background: linear-gradient(135deg, #2563eb, #1d4ed8); color: white; padding: 20px; text-align: center; }
            .center-name { font-size: 22px; font-weight: bold; margin-bottom: 6px; }
            .center-contact { font-size: 12px; margin-top: 10px; opacity: 0.9; line-height: 1.3; }
            .report-title { font-size: 16px; font-weight: bold; margin: 12px 0 8px 0; text-transform: uppercase; letter-spacing: 1px; }
            .passcode-section { background: rgba(255,255,255,0.15); padding: 8px 16px; border-radius: 6px; margin-top: 10px; border: 1px solid rgba(255,255,255,0.2); }
            .content { padding: 20px; }
            .patient-info, .test-info { display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 20px; padding: 12px; background: #f8fafc; border-radius: 6px; border-left: 3px solid #2563eb; }
            .info-label { font-weight: bold; color: #2563eb; margin-bottom: 4px; font-size: 12px; }
            .results-table { width: 100%; border-collapse: collapse; margin-top: 15px; font-size: 12px; }
            .results-table th, .results-table td { padding: 8px; text-align: left; border-bottom: 1px solid #e2e8f0; }
            .results-table th { background: #f1f5f9; font-weight: bold; color: #374151; border-bottom: 2px solid #2563eb; }
            .footer { margin-top: 15px; padding-top: 15px; border-top: 1px solid #e2e8f0; text-align: center; color: #6b7280; font-size: 11px; }
          </style>
        </head>
        <body>
          <div class="report-container">
            <div class="header">
              ${logoSection}
              <div class="center-name">${mockCenter.name}</div>
              <div class="center-contact">
                <div><strong>📍 ${mockCenter.address}</strong></div>
                <div>${mockCenter.city}, ${mockCenter.state} - ${mockCenter.pincode}</div>
                <div>📞 ${mockCenter.ownerPhone} | ✉️ ${mockCenter.ownerEmail}</div>
                <div>License: ${mockCenterProfile.licenseNumber}</div>
              </div>
              <div class="report-title">Medical Test Report</div>
              <div class="passcode-section">
                <div style="font-size: 11px; opacity: 0.8; margin-bottom: 2px;">Patient Access Code</div>
                <div style="font-size: 18px; font-weight: bold; letter-spacing: 2px; font-family: monospace;">${user.passcode || 'XXXX'}</div>
              </div>
            </div>
            
            <div class="content">
              <div class="patient-info">
                <div>
                  <div class="info-label">Patient Name</div>
                  <div>${mockPatient.fullName}</div>
                </div>
                <div>
                  <div class="info-label">Patient ID</div>
                  <div>${mockPatient.id}</div>
                </div>
                <div>
                  <div class="info-label">Phone Number</div>
                  <div>${mockPatient.phone}</div>
                </div>
                <div>
                  <div class="info-label">Address</div>
                  <div>${mockPatient.address}, ${mockPatient.city}</div>
                </div>
              </div>

              <div class="test-info">
                <div>
                  <div class="info-label">Test Name</div>
                  <div>${report.testName}</div>
                </div>
                <div>
                  <div class="info-label">Test Type</div>
                  <div>${report.testType}</div>
                </div>
                <div>
                  <div class="info-label">Sample Date</div>
                  <div>${new Date(report.sampleDate).toLocaleDateString('en-IN')}</div>
                </div>
                <div>
                  <div class="info-label">Report Date</div>
                  <div>${report.reportDate ? new Date(report.reportDate).toLocaleDateString('en-IN') : 'Pending'}</div>
                </div>
                <div>
                  <div class="info-label">Referred By</div>
                  <div>${report.referredBy}</div>
                </div>
                <div>
                  <div class="info-label">Report ID</div>
                  <div>${report.passcodeId}</div>
                </div>
              </div>

              ${report.results && report.results.length > 0 ? `
              <div>
                <h3 style="color: #2563eb; margin-bottom: 15px;">Test Results</h3>
                <table class="results-table">
                  <thead>
                    <tr>
                      <th>Parameter</th>
                      <th>Result</th>
                      <th>Unit</th>
                      <th>Reference Range</th>
                      <th>Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    ${report.results.map(result => `
                      <tr>
                        <td><strong>${result.parameter}</strong></td>
                        <td>${result.value}</td>
                        <td>${result.unit}</td>
                        <td>${result.reference}</td>
                        <td><span style="color: #059669; font-weight: bold;">Normal</span></td>
                      </tr>
                    `).join('')}
                  </tbody>
                </table>
              </div>
              ` : `
              <div style="text-align: center; padding: 40px; background: #fef3c7; border-radius: 8px; border: 1px solid #f59e0b;">
                <h3 style="color: #92400e; margin-bottom: 10px;">Report In Progress</h3>
                <p style="color: #92400e;">Test results are being processed and will be available soon.</p>
              </div>
              `}

              <div class="footer">
                <p><strong>Patient Access Code: ${user.passcode || 'XXXX'}</strong> | Generated: ${new Date().toLocaleDateString('en-IN')} ${new Date().toLocaleTimeString('en-IN')}</p>
                <p>This report is computer generated and does not require physical signature.</p>
              </div>
            </div>
          </div>
          <script>
            window.addEventListener('load', function() {
              setTimeout(function() {
                window.print();
              }, 500);
            });
          </script>
        </body>
      </html>
    `;

    // Create a blob and download as HTML file, then open print dialog
    const blob = new Blob([htmlContent], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `report_${report.passcodeId}_${report.testName.replace(/\s+/g, '_')}.html`;
    link.style.display = 'none';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    
    // Also open print dialog for PDF save
    const printWindow = window.open('', '', 'height=600,width=800');
    if (printWindow) {
      printWindow.document.write(htmlContent);
      printWindow.document.close();
      printWindow.print();
    }
  };

  const downloadBill = (bill: Bill) => {
    // Mock center and patient data
    const mockCenter = {
      name: 'Apollo Diagnostics Mumbai',
      address: '123 MG Road, Fort',
      city: 'Mumbai',
      state: 'Maharashtra',
      pincode: '400001',
      phone: '+91-9876543210',
      email: 'info@apollodiagnostics.com',
      licenseNumber: 'MH/MUM/2024/001',
      gstNumber: '27AAAAA0000A1Z5',
      logo: '/placeholder-logo.png'
    };

    const mockPatient = {
      fullName: user.name,
      phone: user.phone || '9876543210',
      address: '123 Patient Address',
      city: 'Mumbai',
      state: 'Maharashtra',
      pincode: '400001'
    };

    const logoSection = mockCenter.logo ? `
      <div style="text-align: center; margin-bottom: 20px;">
        <img src="${mockCenter.logo}" alt="${mockCenter.name} Logo" style="max-height: 80px; max-width: 200px; object-fit: contain;" />
      </div>
    ` : '';

    const htmlContent = `
      <!DOCTYPE html>
      <html>
        <head>
          <title>Invoice - ${bill.invoiceNumber}</title>
          <meta charset="UTF-8">
          <style>
            @media print {
              @page { margin: 0.5in; size: A4; }
              body { color: #000 !important; background: white !important; font-size: 12px !important; padding: 0 !important; }
              .invoice-container { border: none !important; transform: scale(0.95); transform-origin: top left; }
              .header { padding: 15px !important; }
              .content { padding: 15px !important; }
              .table th, .table td { padding: 6px !important; font-size: 11px !important; }
              .total-section { padding: 12px !important; margin-top: 15px !important; }
              .footer { padding: 8px !important; font-size: 10px !important; }
            }
            body { font-family: Arial, sans-serif; margin: 0; padding: 20px; background: white; font-size: 13px; }
            .invoice-container { max-width: 800px; margin: 0 auto; background: white; border: 2px solid #2563eb; border-radius: 8px; overflow: hidden; }
            .header { background: linear-gradient(135deg, #2563eb, #1d4ed8); color: white; padding: 20px; text-align: center; }
            .center-name { font-size: 22px; font-weight: bold; margin-bottom: 6px; }
            .center-address { font-size: 12px; margin-top: 8px; line-height: 1.3; }
            .invoice-title { font-size: 18px; font-weight: bold; margin: 15px 0 8px 0; text-transform: uppercase; letter-spacing: 1px; }
            .content { padding: 20px; }
            .invoice-details { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px; }
            .section { background: #f8fafc; padding: 12px; border-radius: 6px; border-left: 3px solid #2563eb; }
            .section-title { font-weight: bold; color: #2563eb; margin-bottom: 8px; font-size: 14px; }
            .detail-row { margin-bottom: 6px; font-size: 12px; } .label { font-weight: bold; color: #374151; }
            .table { width: 100%; border-collapse: collapse; margin: 15px 0; font-size: 12px; }
            .table th, .table td { border: 1px solid #e2e8f0; padding: 8px; text-align: left; }
            .table th { background: #f1f5f9; font-weight: bold; color: #374151; }
            .total-section { background: #f8fafc; padding: 15px; border-radius: 6px; margin-top: 15px; }
            .total-row { display: flex; justify-content: space-between; margin-bottom: 6px; font-size: 13px; }
            .total-final { border-top: 2px solid #2563eb; padding-top: 8px; margin-top: 8px; font-size: 16px; font-weight: bold; color: #2563eb; }
            .footer { margin-top: 15px; padding-top: 15px; border-top: 1px solid #e2e8f0; text-align: center; color: #6b7280; font-size: 11px; }
          </style>
        </head>
        <body>
          <div class="invoice-container">
            <div class="header">
              ${logoSection}
              <div class="center-name">${mockCenter.name}</div>
              <div class="center-address">
                📍 ${mockCenter.address}, ${mockCenter.city}, ${mockCenter.state} - ${mockCenter.pincode}<br>
                📞 ${mockCenter.phone} | ✉️ ${mockCenter.email}<br>
                License: ${mockCenter.licenseNumber} | GST: ${mockCenter.gstNumber}
              </div>
              <div class="invoice-title">Tax Invoice</div>
            </div>
            <div class="content">
              <div class="invoice-details">
                <div class="section">
                  <div class="section-title">Bill To:</div>
                  <div class="detail-row"><span class="label">Patient Name:</span> ${mockPatient.fullName}</div>
                  <div class="detail-row"><span class="label">Phone:</span> ${mockPatient.phone}</div>
                  <div class="detail-row"><span class="label">Address:</span> ${mockPatient.address}, ${mockPatient.city}</div>
                </div>
                <div class="section">
                  <div class="section-title">Invoice Details:</div>
                  <div class="detail-row"><span class="label">Invoice Number:</span> ${bill.invoiceNumber}</div>
                  <div class="detail-row"><span class="label">Invoice Date:</span> ${new Date(bill.createdDate).toLocaleDateString('en-IN')}</div>
                  <div class="detail-row"><span class="label">Status:</span> ${bill.status.toUpperCase()}</div>
                </div>
              </div>
              <table class="table">
                <thead><tr><th>Test/Service</th><th>Qty</th><th>Amount (₹)</th></tr></thead>
                <tbody>
                  ${bill.tests.map(test => `<tr><td>${test}</td><td>1</td><td>₹${Math.floor(bill.amount / bill.tests.length)}</td></tr>`).join('')}
                </tbody>
              </table>
              <div class="total-section">
                <div class="total-row"><span>Subtotal:</span><span>₹${bill.amount}</span></div>
                ${bill.discount > 0 ? `<div class="total-row" style="color: #059669;"><span>Discount:</span><span>-₹${bill.discount}</span></div>` : ''}
                <div class="total-row total-final"><span>Total Amount:</span><span>₹${bill.finalAmount}</span></div>
              </div>
              <div class="footer">
                <p><strong>Thank you for choosing ${mockCenter.name}!</strong></p>
                <p>This is a computer generated invoice and does not require physical signature.</p>
                <p>Generated on: ${new Date().toLocaleDateString('en-IN')} at ${new Date().toLocaleTimeString('en-IN')}</p>
              </div>
            </div>
          </div>
          <script>window.addEventListener('load', function() { setTimeout(function() { window.print(); }, 500); });</script>
        </body>
      </html>
    `;

    // Download as HTML and open print dialog
    const blob = new Blob([htmlContent], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `invoice_${bill.invoiceNumber}.html`;
    link.style.display = 'none';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    
    const printWindow = window.open('', '', 'height=600,width=800');
    if (printWindow) {
      printWindow.document.write(htmlContent);
      printWindow.document.close();
      printWindow.print();
    }
  };

  const renderDashboard = () => (
    <div className="space-y-8">
      {/* Welcome Header */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-pink-600 via-purple-600 to-blue-600 p-8 text-white shadow-medical-lg">
        <div className="absolute inset-0 opacity-20" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.1'%3E%3Cpath d='M30 30c0-11.046-8.954-20-20-20s-20 8.954-20 20 8.954 20 20 20 20-8.954 20-20z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`
        }}></div>
        <div className="relative z-10">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl md:text-4xl font-bold mb-2 flex items-center gap-3">
                <Heart className="h-8 w-8 text-pink-300" />
                Welcome, {user.name}!
              </h1>
              <p className="text-purple-100 text-lg">Your Health Dashboard - Composcale.com</p>
            </div>
            <div className="hidden lg:block">
              <div className="text-right">
                <p className="text-purple-100 text-sm">Health Status</p>
                <div className="flex items-center gap-2 justify-end">
                  <Activity className="h-4 w-4 text-green-300" />
                  <span className="text-green-300 font-medium">Monitoring Active</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="stats-grid">
        <Card className="medical-card hover-lift border-0 shadow-medical">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground font-medium">Total Reports</p>
                <p className="text-3xl font-bold text-foreground">{mockReports.length}</p>
                <p className="text-xs text-green-600 font-medium">All available</p>
              </div>
              <div className="rounded-lg bg-gradient-to-br from-blue-500 to-blue-600 p-3 shadow-lg">
                <FileText className="h-6 w-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="medical-card hover-lift border-0 shadow-medical">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground font-medium">Completed Tests</p>
                <p className="text-3xl font-bold text-foreground">{mockReports.filter(r => r.status === 'completed').length}</p>
                <p className="text-xs text-green-600 font-medium">Results ready</p>
              </div>
              <div className="rounded-lg bg-gradient-to-br from-green-500 to-green-600 p-3 shadow-lg">
                <Activity className="h-6 w-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="medical-card hover-lift border-0 shadow-medical">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground font-medium">Total Bills</p>
                <p className="text-3xl font-bold text-foreground">{mockBills.length}</p>
                <p className="text-xs text-blue-600 font-medium">{mockBills.filter(b => b.status === 'pending').length} pending</p>
              </div>
              <div className="rounded-lg bg-gradient-to-br from-purple-500 to-purple-600 p-3 shadow-lg">
                <IndianRupee className="h-6 w-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="medical-card hover-lift border-0 shadow-medical">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground font-medium">Last Visit</p>
                <p className="text-3xl font-bold text-foreground">Jun 16</p>
                <p className="text-xs text-muted-foreground">2024</p>
              </div>
              <div className="rounded-lg bg-gradient-to-br from-teal-500 to-teal-600 p-3 shadow-lg">
                <Calendar className="h-6 w-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Reports */}
      <Card className="medical-card hover-lift border-0 shadow-medical">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5 text-blue-600" />
            Recent Test Reports
          </CardTitle>
          <CardDescription>Your latest medical test results</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {mockReports.slice(0, 3).map((report) => (
              <div key={report.id} className="flex items-center justify-between p-4 bg-muted/20 rounded-lg border border-border/50">
                <div className="flex-1">
                  <h4 className="font-semibold text-foreground">{report.testName}</h4>
                  <p className="text-sm text-muted-foreground">
                    Date: {new Date(report.sampleDate).toLocaleDateString('en-IN')}
                  </p>
                  <p className="text-sm text-muted-foreground">Referred by: {report.referredBy}</p>
                </div>
                <div className="flex items-center gap-3">
                  <Badge 
                    variant="outline" 
                    className={report.status === 'completed' 
                      ? 'bg-green-50 text-green-700 border-green-200 dark:bg-green-900 dark:text-green-100'
                      : 'bg-yellow-50 text-yellow-700 border-yellow-200 dark:bg-yellow-900 dark:text-yellow-100'
                    }
                  >
                    {report.status === 'completed' ? 'Ready' : 'Processing'}
                  </Badge>
                  {report.status === 'completed' && (
                    <Button
                      onClick={() => downloadReport(report)}
                      size="sm"
                      variant="outline"
                      className="rounded-xl border-border/50 hover:bg-blue-50 hover:border-blue-200 dark:hover:bg-blue-950/50 focus-enhanced"
                    >
                      <Download className="h-4 w-4 mr-2" />
                      Download
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </div>
          {mockReports.length > 3 && (
            <div className="text-center mt-4">
              <Button
                onClick={() => setCurrentView('reports')}
                variant="outline"
                className="rounded-xl"
              >
                View All Reports
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Recent Bills */}
      <Card className="medical-card hover-lift border-0 shadow-medical">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <IndianRupee className="h-5 w-5 text-green-600" />
            Recent Bills
          </CardTitle>
          <CardDescription>Your payment history and pending bills</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {mockBills.slice(0, 3).map((bill) => (
              <div key={bill.id} className="flex items-center justify-between p-4 bg-muted/20 rounded-lg border border-border/50">
                <div className="flex-1">
                  <h4 className="font-semibold text-foreground">{bill.invoiceNumber}</h4>
                  <p className="text-sm text-muted-foreground">
                    Date: {new Date(bill.createdDate).toLocaleDateString('en-IN')}
                  </p>
                  <p className="text-sm text-muted-foreground">Tests: {bill.tests.join(', ')}</p>
                </div>
                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <p className="font-semibold text-foreground">₹{bill.finalAmount.toLocaleString('en-IN')}</p>
                    <Badge 
                      variant="outline" 
                      className={bill.status === 'paid' 
                        ? 'bg-green-50 text-green-700 border-green-200 dark:bg-green-900 dark:text-green-100'
                        : 'bg-yellow-50 text-yellow-700 border-yellow-200 dark:bg-yellow-900 dark:text-yellow-100'
                      }
                    >
                      {bill.status === 'paid' ? 'Paid' : 'Pending'}
                    </Badge>
                  </div>
                </div>
              </div>
            ))}
          </div>
          {mockBills.length > 3 && (
            <div className="text-center mt-4">
              <Button
                onClick={() => setCurrentView('bills')}
                variant="outline"
                className="rounded-xl"
              >
                View All Bills
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );

  const renderReports = () => (
    <div className="space-y-8">
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 p-8 text-white shadow-medical-lg">
        <div className="absolute inset-0 opacity-20" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.1'%3E%3Cpath d='M30 10c11.046 0 20 8.954 20 20s-8.954 20-20 20-20-8.954-20-20 8.954-20 20-20z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`
        }}></div>
        <div className="relative z-10">
          <h1 className="text-3xl md:text-4xl font-bold mb-2 flex items-center gap-3">
            <FileText className="h-8 w-8 text-blue-300" />
            My Test Reports
          </h1>
          <p className="text-blue-100 text-lg">Download and view your medical test results</p>
        </div>
      </div>

      <div className="space-y-4">
        {mockReports.map((report) => (
          <Card key={report.id} className="medical-card hover-lift border-0 shadow-medical">
            <CardContent className="p-6">
              <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
                <div className="space-y-3">
                  <div className="flex flex-col sm:flex-row sm:items-center gap-3">
                    <h3 className="text-xl font-semibold text-foreground">{report.testName}</h3>
                    <Badge 
                      variant="outline" 
                      className={report.status === 'completed' 
                        ? 'bg-green-50 text-green-700 border-green-200 dark:bg-green-900 dark:text-green-100'
                        : 'bg-yellow-50 text-yellow-700 border-yellow-200 dark:bg-yellow-900 dark:text-yellow-100'
                      }
                    >
                      {report.status === 'completed' ? 'Completed' : 'Processing'}
                    </Badge>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-sm text-muted-foreground">
                    <div className="flex items-center gap-2">
                      <Calendar className="h-4 w-4 text-blue-600" />
                      <span className="font-medium text-foreground">Sample Date:</span> {new Date(report.sampleDate).toLocaleDateString('en-IN')}
                    </div>
                    <div className="flex items-center gap-2">
                      <User className="h-4 w-4 text-green-600" />
                      <span className="font-medium text-foreground">Referred By:</span> {report.referredBy}
                    </div>
                    <div className="flex items-center gap-2">
                      <Activity className="h-4 w-4 text-purple-600" />
                      <span className="font-medium text-foreground">Test Type:</span> {report.testType}
                    </div>
                  </div>
                  {report.status === 'completed' && report.results.length > 0 && (
                    <div className="mt-4 p-3 bg-green-50 dark:bg-green-950/50 rounded-lg border border-green-200 dark:border-green-800">
                      <p className="text-sm font-medium text-green-800 dark:text-green-200 mb-2">Test Results Summary:</p>
                      <div className="space-y-1">
                        {report.results.slice(0, 2).map((result, index) => (
                          <p key={index} className="text-sm text-green-700 dark:text-green-300">
                            {result.parameter}: {result.value} {result.unit} (Normal: {result.reference})
                          </p>
                        ))}
                        {report.results.length > 2 && (
                          <p className="text-sm text-green-600 dark:text-green-400">+{report.results.length - 2} more parameters...</p>
                        )}
                      </div>
                    </div>
                  )}
                </div>
                <div className="flex flex-col sm:flex-row gap-3">
                  {report.status === 'completed' && (
                    <Button
                      onClick={() => downloadReport(report)}
                      className="rounded-xl bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white border-0 focus-enhanced"
                    >
                      <Download className="h-4 w-4 mr-2" />
                      Download PDF
                    </Button>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );

  const renderBills = () => (
    <div className="space-y-8">
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-green-600 via-teal-600 to-blue-600 p-8 text-white shadow-medical-lg">
        <div className="absolute inset-0 opacity-20" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.1'%3E%3Cpath d='M30 8c12.15 0 22 9.85 22 22s-9.85 22-22 22S8 42.15 8 30 17.85 8 30 8z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`
        }}></div>
        <div className="relative z-10">
          <h1 className="text-3xl md:text-4xl font-bold mb-2 flex items-center gap-3">
            <IndianRupee className="h-8 w-8 text-green-300" />
            Bills & Payments
          </h1>
          <p className="text-blue-100 text-lg">View your payment history and manage pending bills</p>
        </div>
      </div>

      <div className="space-y-4">
        {mockBills.map((bill) => (
          <Card key={bill.id} className="medical-card hover-lift border-0 shadow-medical">
            <CardContent className="p-6">
              <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
                <div className="space-y-3">
                  <div className="flex flex-col sm:flex-row sm:items-center gap-3">
                    <h3 className="text-xl font-semibold text-foreground">{bill.invoiceNumber}</h3>
                    <Badge 
                      variant="outline" 
                      className={bill.status === 'paid' 
                        ? 'bg-green-50 text-green-700 border-green-200 dark:bg-green-900 dark:text-green-100'
                        : 'bg-yellow-50 text-yellow-700 border-yellow-200 dark:bg-yellow-900 dark:text-yellow-100'
                      }
                    >
                      {bill.status === 'paid' ? 'Paid' : 'Pending Payment'}
                    </Badge>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-sm text-muted-foreground">
                    <div className="flex items-center gap-2">
                      <Calendar className="h-4 w-4 text-blue-600" />
                      <span className="font-medium text-foreground">Bill Date:</span> {new Date(bill.createdDate).toLocaleDateString('en-IN')}
                    </div>
                    <div className="flex items-center gap-2">
                      <IndianRupee className="h-4 w-4 text-green-600" />
                      <span className="font-medium text-foreground">Amount:</span> ₹{bill.finalAmount.toLocaleString('en-IN')}
                    </div>
                    {bill.paymentDate && (
                      <div className="flex items-center gap-2">
                        <Clock className="h-4 w-4 text-purple-600" />
                        <span className="font-medium text-foreground">Paid On:</span> {new Date(bill.paymentDate).toLocaleDateString('en-IN')}
                      </div>
                    )}
                  </div>
                  <div className="text-sm text-muted-foreground">
                    <span className="font-medium text-foreground">Tests:</span> {bill.tests.join(', ')}
                  </div>
                  {bill.discount > 0 && (
                    <div className="text-sm text-green-600">
                      <span className="font-medium">Discount Applied:</span> ₹{bill.discount.toLocaleString('en-IN')}
                    </div>
                  )}
                </div>
                <div className="flex flex-col sm:flex-row gap-3">
                  <div className="text-right">
                    <p className="text-2xl font-bold text-foreground">₹{bill.finalAmount.toLocaleString('en-IN')}</p>
                    <p className="text-sm text-muted-foreground">Final Amount</p>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => downloadBill(bill)}
                    className="rounded-xl border-border/50 hover:bg-blue-50 hover:border-blue-200 dark:hover:bg-blue-950/50 focus-enhanced"
                  >
                    <Download className="h-4 w-4 mr-2" />
                    Download
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );

  const renderSettings = () => (
    <div className="space-y-8">
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-gray-600 via-blue-600 to-purple-600 p-8 text-white shadow-medical-lg">
        <div className="absolute inset-0 opacity-20" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.1'%3E%3Cpath d='M30 15c8.284 0 15 6.716 15 15s-6.716 15-15 15-15-6.716-15-15 6.716-15 15-15z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`
        }}></div>
        <div className="relative z-10">
          <h1 className="text-3xl md:text-4xl font-bold mb-2 flex items-center gap-3">
            <Settings className="h-8 w-8 text-gray-300" />
            Account Settings
          </h1>
          <p className="text-blue-100 text-lg">Manage your account preferences and information</p>
        </div>
      </div>

      <div className="dashboard-grid">
        <Card className="medical-card hover-lift border-0 shadow-medical">
          <CardHeader>
            <CardTitle>Appearance</CardTitle>
            <CardDescription>Customize your dashboard appearance</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                {isDarkMode ? <Moon className="h-5 w-5" /> : <Sun className="h-5 w-5" />}
                <div>
                  <p className="font-medium">Dark Mode</p>
                  <p className="text-sm text-muted-foreground">Toggle dark theme</p>
                </div>
              </div>
              <Button
                onClick={toggleDarkMode}
                variant="outline"
                size="sm"
                className="rounded-xl"
              >
                {isDarkMode ? 'Light' : 'Dark'}
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card className="medical-card hover-lift border-0 shadow-medical">
          <CardHeader>
            <CardTitle>Personal Information</CardTitle>
            <CardDescription>Your account details</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <p className="text-sm text-muted-foreground">Full Name</p>
              <p className="font-medium">{user.name}</p>
            </div>
            <div className="space-y-2">
              <p className="text-sm text-muted-foreground">Phone Number</p>
              <p className="font-medium">{user.phone || 'Not provided'}</p>
            </div>
            <div className="space-y-2">
              <p className="text-sm text-muted-foreground">Account Type</p>
              <Badge variant="outline" className="bg-pink-50 text-pink-700 border-pink-200">
                Patient
              </Badge>
            </div>
            <div className="space-y-2">
              <p className="text-sm text-muted-foreground">Patient ID</p>
              <p className="font-mono text-sm">{user.id}</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );

  const renderContent = () => {
    switch (currentView) {
      case 'dashboard':
        return renderDashboard();
      case 'reports':
        return renderReports();
      case 'bills':
        return renderBills();
      case 'settings':
        return renderSettings();
      default:
        return renderDashboard();
    }
  };

  return (
    <div className="layout-container">
      {/* Sidebar */}
      <div className={`sidebar-container ${isCollapsed ? 'collapsed' : ''}`}>
        {/* Sidebar Toggle Button */}
        <button
          onClick={toggleSidebar}
          className="sidebar-toggle"
          aria-label={isCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}
        >
          <ChevronLeft />
        </button>

        <div className="sidebar-content">
          {/* Sidebar Header */}
          <div className="sidebar-header">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-gradient-to-br from-pink-600 to-purple-600 rounded-lg flex items-center justify-center shadow-lg flex-shrink-0">
                <Heart className="h-4 w-4 text-white" />
              </div>
              {!isCollapsed && (
                <div className="min-w-0 flex-1">
                  <h2 className="font-bold text-sidebar-foreground truncate">MediLab India</h2>
                  <p className="text-xs text-sidebar-foreground/70 truncate">Patient Portal</p>
                </div>
              )}
            </div>
          </div>

          {/* Sidebar Navigation */}
          <div className="sidebar-body">
            <nav className="sidebar-nav">
              {sidebarItems.map((item) => {
                const Icon = item.icon;
                const isActive = currentView === item.view;
                
                return (
                  <button
                    key={item.id}
                    onClick={() => setCurrentView(item.view)}
                    className={`sidebar-nav-item group ${isActive ? 'active' : ''}`}
                  >
                    <Icon className="sidebar-nav-icon" />
                    <span className="sidebar-nav-text">{item.label}</span>
                    {isCollapsed && (
                      <div className="sidebar-tooltip">
                        {item.label}
                      </div>
                    )}
                  </button>
                );
              })}
              
              {/* Logout Button */}
              <button
                onClick={onLogout}
                className="sidebar-nav-item group mt-auto text-red-600 hover:bg-red-50 dark:hover:bg-red-950/50"
              >
                <LogOut className="sidebar-nav-icon" />
                <span className="sidebar-nav-text">Logout</span>
                {isCollapsed && (
                  <div className="sidebar-tooltip">
                    Logout
                  </div>
                )}
              </button>
            </nav>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="main-content-container">
        <div className="main-content-body">
          {renderContent()}
        </div>
      </div>
    </div>
  );
}