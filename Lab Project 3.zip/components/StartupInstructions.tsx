import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Alert, AlertDescription } from './ui/alert';
import { Badge } from './ui/badge';
import { 
  Server, 
  Play, 
  Terminal, 
  CheckCircle, 
  AlertCircle, 
  Wifi, 
  WifiOff,
  X,
  ExternalLink
} from 'lucide-react';

interface StartupInstructionsProps {
  onDismiss?: () => void;
  connectionStatus: 'online' | 'offline' | 'connecting';
}

export const StartupInstructions: React.FC<StartupInstructionsProps> = ({ 
  onDismiss, 
  connectionStatus 
}) => {
  const [isVisible, setIsVisible] = useState(true);

  if (!isVisible) return null;

  const handleDismiss = () => {
    setIsVisible(false);
    onDismiss?.();
  };

  return (
    <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Server className="w-5 h-5" />
              MediLab India Setup Guide
            </CardTitle>
            <CardDescription>
              Quick setup instructions for running the full-stack application
            </CardDescription>
          </div>
          <Button variant="ghost" size="sm" onClick={handleDismiss}>
            <X className="w-4 h-4" />
          </Button>
        </CardHeader>
        
        <CardContent className="space-y-6">
          {/* Current Status */}
          <Alert className={connectionStatus === 'online' ? 'border-success/20 bg-success/10' : 'border-warning/20 bg-warning/10'}>
            {connectionStatus === 'online' ? (
              <CheckCircle className="h-4 w-4 text-success" />
            ) : (
              <WifiOff className="h-4 w-4 text-warning" />
            )}
            <AlertDescription>
              <div className="flex items-center justify-between">
                <span>
                  Current Status: 
                  <Badge variant="secondary" className="ml-2">
                    {connectionStatus === 'online' ? (
                      <>
                        <Wifi className="w-3 h-3 mr-1" />
                        Connected
                      </>
                    ) : (
                      <>
                        <WifiOff className="w-3 h-3 mr-1" />
                        Demo Mode
                      </>
                    )}
                  </Badge>
                </span>
              </div>
            </AlertDescription>
          </Alert>

          {/* Setup Options */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Setup Options</h3>
            
            {/* Option 1: Frontend Only (Current) */}
            <Card className="border-l-4 border-l-warning">
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2">
                  <WifiOff className="w-4 h-4 text-warning" />
                  Option 1: Frontend Only (Demo Mode)
                </CardTitle>
                <CardDescription>
                  Running with sample data - no backend server required
                </CardDescription>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-sm">
                    <CheckCircle className="w-4 h-4 text-success" />
                    <span>✅ Already running</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <CheckCircle className="w-4 h-4 text-success" />
                    <span>✅ Demo accounts available</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <AlertCircle className="w-4 h-4 text-warning" />
                    <span>⚠️ Changes won't be saved</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Option 2: Full Stack */}
            <Card className="border-l-4 border-l-primary">
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2">
                  <Server className="w-4 h-4 text-primary" />
                  Option 2: Full Stack (Database + Server)
                </CardTitle>
                <CardDescription>
                  Complete setup with MySQL database and backend server
                </CardDescription>
              </CardHeader>
              <CardContent className="pt-0 space-y-4">
                <div className="space-y-3">
                  <div className="flex items-start gap-3">
                    <div className="w-6 h-6 rounded-full bg-primary/10 text-primary flex items-center justify-center text-sm font-semibold mt-0.5">
                      1
                    </div>
                    <div>
                      <div className="font-medium">Setup Database</div>
                      <div className="text-sm text-muted-foreground">Configure MySQL and run setup script</div>
                      <div className="mt-2 p-3 bg-muted rounded-md font-mono text-sm">
                        npm run setup:db
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-3">
                    <div className="w-6 h-6 rounded-full bg-primary/10 text-primary flex items-center justify-center text-sm font-semibold mt-0.5">
                      2
                    </div>
                    <div>
                      <div className="font-medium">Start Backend Server</div>
                      <div className="text-sm text-muted-foreground">Launch the API server on port 3001</div>
                      <div className="mt-2 p-3 bg-muted rounded-md font-mono text-sm">
                        npm run server:dev
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-3">
                    <div className="w-6 h-6 rounded-full bg-primary/10 text-primary flex items-center justify-center text-sm font-semibold mt-0.5">
                      3
                    </div>
                    <div>
                      <div className="font-medium">Restart Frontend</div>
                      <div className="text-sm text-muted-foreground">Refresh to connect to the backend</div>
                      <div className="mt-2">
                        <Button size="sm" onClick={() => window.location.reload()}>
                          <Play className="w-3 h-3 mr-1" />
                          Restart App
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Demo Accounts */}
          <div className="space-y-3">
            <h3 className="text-lg font-semibold">Demo Login Accounts</h3>
            <div className="grid gap-3">
              {[
                { role: 'Super Admin', username: 'superadmin', password: 'password', color: 'bg-red-500' },
                { role: 'Diagnostic Center', username: 'testcenter', password: 'password', color: 'bg-blue-500' },
                { role: 'Patient', username: 'patient', password: 'password', color: 'bg-green-500' }
              ].map((account, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-muted rounded-lg">
                  <div className="flex items-center gap-3">
                    <div className={`w-3 h-3 rounded-full ${account.color}`} />
                    <div>
                      <div className="font-medium">{account.role}</div>
                      <div className="text-sm text-muted-foreground">
                        {account.username} / {account.password}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Quick Actions */}
          <div className="flex flex-col sm:flex-row gap-3 pt-4 border-t">
            <Button onClick={handleDismiss} className="flex-1">
              Continue with Demo Mode
            </Button>
            <Button 
              variant="outline" 
              onClick={() => window.open('https://github.com/your-repo/medilab-india#setup', '_blank')}
              className="flex-1"
            >
              <ExternalLink className="w-4 h-4 mr-2" />
              Setup Guide
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default StartupInstructions;