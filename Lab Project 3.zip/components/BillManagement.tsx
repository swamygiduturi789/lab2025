import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Badge } from './ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Separator } from './ui/separator';
import { 
  FileText, Search, Plus, Eye, Download, IndianRupee, 
  Calendar, User, CheckCircle, Clock, AlertCircle, Percent
} from 'lucide-react';
import { Bill, Patient } from '../App';

const mockPatients: Patient[] = [
  {
    id: '1',
    fullName: 'Rajesh Kumar',
    email: 'rajesh@email.com',
    phone: '9876543210',
    address: '123 MG Road',
    city: 'Mumbai',
    state: 'Maharashtra',
    whatsappNumber: '9876543210',
    passcode: '1234',
    centerId: '1',
    createdDate: '2024-06-01'
  },
  {
    id: '2',
    fullName: 'Priya Sharma',
    email: 'priya@email.com',
    phone: '9876543211',
    address: '456 Park Street',
    city: 'Delhi',
    state: 'Delhi',
    whatsappNumber: '9876543211',
    passcode: '5678',
    centerId: '1',
    createdDate: '2024-06-02'
  }
];

const mockTests = [
  { id: '1', name: 'Complete Blood Count (CBC)', price: 500 },
  { id: '2', name: 'Lipid Profile', price: 800 },
  { id: '3', name: 'Urine Routine & Microscopy', price: 300 },
  { id: '4', name: 'Thyroid Function Test', price: 1200 },
  { id: '5', name: 'Chest X-Ray', price: 600 }
];

const mockBills: Bill[] = [
  {
    id: '1',
    patientId: '1',
    centerId: '1',
    invoiceNumber: 'INV-2024-001',
    amount: 1300,
    discount: 130,
    finalAmount: 1170,
    status: 'paid',
    paymentDate: '2024-06-15',
    createdDate: '2024-06-15',
    tests: ['Complete Blood Count (CBC)', 'Lipid Profile']
  },
  {
    id: '2',
    patientId: '2',
    centerId: '1',
    invoiceNumber: 'INV-2024-002',
    amount: 900,
    discount: 0,
    finalAmount: 900,
    status: 'pending',
    createdDate: '2024-06-16',
    tests: ['Urine Routine & Microscopy', 'Chest X-Ray']
  }
];

export function BillManagement() {
  const [bills, setBills] = useState<Bill[]>(mockBills);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [selectedPatient, setSelectedPatient] = useState<string>('');
  const [selectedTests, setSelectedTests] = useState<string[]>([]);
  const [discountPercent, setDiscountPercent] = useState<number>(0);

  const filteredBills = bills.filter(bill => {
    const patient = mockPatients.find(p => p.id === bill.patientId);
    const matchesSearch = bill.invoiceNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         patient?.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         bill.tests.some(test => test.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesStatus = statusFilter === 'all' || bill.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const calculateTotal = () => {
    const subtotal = selectedTests.reduce((total, testId) => {
      const test = mockTests.find(t => t.id === testId);
      return total + (test?.price || 0);
    }, 0);
    const discount = (subtotal * discountPercent) / 100;
    return { subtotal, discount, total: subtotal - discount };
  };

  const handleCreateBill = () => {
    const patient = mockPatients.find(p => p.id === selectedPatient);
    if (!patient || selectedTests.length === 0) return;

    const { subtotal, discount, total } = calculateTotal();
    const testNames = selectedTests.map(testId => {
      const test = mockTests.find(t => t.id === testId);
      return test?.name || '';
    }).filter(Boolean);

    const newBill: Bill = {
      id: (bills.length + 1).toString(),
      patientId: selectedPatient,
      centerId: '1',
      invoiceNumber: `INV-2024-${String(bills.length + 3).padStart(3, '0')}`,
      amount: subtotal,
      discount: discount,
      finalAmount: total,
      status: 'pending',
      createdDate: new Date().toISOString().split('T')[0],
      tests: testNames
    };

    setBills([...bills, newBill]);
    setSelectedPatient('');
    setSelectedTests([]);
    setDiscountPercent(0);
    setIsCreateDialogOpen(false);
  };

  const viewBillPDF = (bill: Bill) => {
    const patient = mockPatients.find(p => p.id === bill.patientId);
    if (!patient) return;

    const viewWindow = window.open('', '_blank', 'width=900,height=700,scrollbars=yes,resizable=yes');
    
    if (!viewWindow) {
      alert('Please allow popups to view the bill.');
      return;
    }

    const htmlContent = `
      <!DOCTYPE html>
      <html>
        <head>
          <title>Invoice - ${bill.invoiceNumber}</title>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <style>
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body {
              font-family: 'Arial', sans-serif;
              margin: 0;
              padding: 20px;
              background: #f5f5f5;
              color: #333;
              line-height: 1.6;
            }
            .container {
              max-width: 800px;
              margin: 0 auto;
              background: white;
              border-radius: 10px;
              box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
              overflow: hidden;
            }
            .header {
              background: linear-gradient(135deg, #2563eb, #1d4ed8);
              color: white;
              padding: 30px;
              text-align: center;
            }
            .company-name {
              font-size: 28px;
              font-weight: bold;
              margin-bottom: 8px;
            }
            .invoice-title {
              font-size: 24px;
              font-weight: bold;
              margin-top: 20px;
              text-transform: uppercase;
              letter-spacing: 2px;
            }
            .content {
              padding: 40px;
            }
            .bill-info {
              display: grid;
              grid-template-columns: 1fr 1fr;
              gap: 30px;
              margin-bottom: 30px;
            }
            .info-section h3 {
              color: #2563eb;
              margin-bottom: 10px;
              font-size: 16px;
            }
            .tests-table {
              width: 100%;
              border-collapse: collapse;
              margin-bottom: 30px;
            }
            .tests-table th, .tests-table td {
              padding: 12px;
              text-align: left;
              border-bottom: 1px solid #e2e8f0;
            }
            .tests-table th {
              background: #f8fafc;
              font-weight: bold;
              color: #374151;
            }
            .total-section {
              text-align: right;
              margin-top: 30px;
            }
            .total-row {
              display: flex;
              justify-content: space-between;
              margin-bottom: 10px;
              padding: 8px 0;
            }
            .total-row.final {
              font-size: 18px;
              font-weight: bold;
              border-top: 2px solid #2563eb;
              padding-top: 15px;
              color: #2563eb;
            }
            .status-badge {
              display: inline-block;
              padding: 6px 12px;
              border-radius: 20px;
              font-size: 12px;
              font-weight: bold;
              text-transform: uppercase;
            }
            .status-paid {
              background: #dcfce7;
              color: #166534;
            }
            .status-pending {
              background: #fef3c7;
              color: #92400e;
            }
            .action-buttons {
              background: #f1f5f9;
              padding: 20px;
              text-align: center;
              border-bottom: 3px solid #2563eb;
            }
            .btn {
              display: inline-block;
              padding: 12px 24px;
              margin: 0 10px;
              background: #2563eb;
              color: white;
              text-decoration: none;
              border-radius: 6px;
              font-weight: bold;
              cursor: pointer;
              border: none;
              font-size: 14px;
              transition: all 0.3s;
            }
            .btn:hover {
              background: #1d4ed8;
              transform: translateY(-2px);
            }
            .btn-secondary {
              background: #6b7280;
            }
            .btn-secondary:hover {
              background: #4b5563;
            }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="action-buttons">
              <button class="btn" onclick="window.print()">🖨️ Print Bill</button>
              <button class="btn btn-secondary" onclick="window.close()">❌ Close</button>
            </div>
            
            <div class="header">
              <div class="company-name">MediLab India</div>
              <div>Diagnostic Center Management System</div>
              <div class="invoice-title">Tax Invoice</div>
            </div>
            
            <div class="content">
              <div class="bill-info">
                <div class="info-section">
                  <h3>Bill To:</h3>
                  <p><strong>${patient.fullName}</strong></p>
                  <p>${patient.phone}</p>
                  <p>${patient.email}</p>
                  <p>${patient.address}</p>
                  <p>${patient.city}, ${patient.state}</p>
                </div>
                <div class="info-section">
                  <h3>Invoice Details:</h3>
                  <p><strong>Invoice #:</strong> ${bill.invoiceNumber}</p>
                  <p><strong>Date:</strong> ${new Date(bill.createdDate).toLocaleDateString('en-IN')}</p>
                  <p><strong>Status:</strong> 
                    <span class="status-badge status-${bill.status}">${bill.status}</span>
                  </p>
                  ${bill.paymentDate ? `<p><strong>Payment Date:</strong> ${new Date(bill.paymentDate).toLocaleDateString('en-IN')}</p>` : ''}
                </div>
              </div>
              
              <table class="tests-table">
                <thead>
                  <tr>
                    <th>Test Name</th>
                    <th style="text-align: right;">Amount</th>
                  </tr>
                </thead>
                <tbody>
                  ${bill.tests.map(testName => {
                    const test = mockTests.find(t => t.name === testName);
                    return `
                      <tr>
                        <td>${testName}</td>
                        <td style="text-align: right;">₹${test?.price.toLocaleString('en-IN') || '0'}</td>
                      </tr>
                    `;
                  }).join('')}
                </tbody>
              </table>
              
              <div class="total-section">
                <div class="total-row">
                  <span>Subtotal:</span>
                  <span>₹${bill.amount.toLocaleString('en-IN')}</span>
                </div>
                ${bill.discount > 0 ? `
                  <div class="total-row">
                    <span>Discount:</span>
                    <span>-₹${bill.discount.toLocaleString('en-IN')}</span>
                  </div>
                ` : ''}
                <div class="total-row final">
                  <span>Total Amount:</span>
                  <span>₹${bill.finalAmount.toLocaleString('en-IN')}</span>
                </div>
              </div>
              
              <div style="margin-top: 40px; padding-top: 20px; border-top: 1px solid #e2e8f0; text-center; color: #6b7280; font-size: 12px;">
                <p>Thank you for choosing MediLab India!</p>
                <p>For queries, contact us at support@medilab.in | +91-1234567890</p>
              </div>
            </div>
          </div>
        </body>
      </html>
    `;

    viewWindow.document.write(htmlContent);
    viewWindow.document.close();
    viewWindow.focus();
  };

  const markAsPaid = (billId: string) => {
    setBills(bills.map(bill => 
      bill.id === billId 
        ? { ...bill, status: 'paid' as const, paymentDate: new Date().toISOString().split('T')[0] }
        : bill
    ));
  };

  const getTotalRevenue = () => {
    return bills.filter(b => b.status === 'paid').reduce((total, bill) => total + bill.finalAmount, 0);
  };

  const getPendingAmount = () => {
    return bills.filter(b => b.status === 'pending').reduce((total, bill) => total + bill.finalAmount, 0);
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 p-8 text-white shadow-medical-lg">
        <div className="absolute inset-0 opacity-20" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.1'%3E%3Cpath d='M30 12c9.941 0 18 8.059 18 18s-8.059 18-18 18-18-8.059-18-18 8.059-18 18-18z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`
        }}></div>
        <div className="relative z-10">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl md:text-4xl font-bold mb-2 flex items-center gap-3">
                <FileText className="h-8 w-8 text-blue-300" />
                Bill Management
              </h1>
              <p className="text-blue-100 text-lg">Create and manage patient bills and invoices</p>
            </div>
            <div className="hidden lg:block">
              <div className="text-right">
                <p className="text-blue-100 text-sm">Total Bills</p>
                <div className="flex items-center gap-2 justify-end">
                  <IndianRupee className="h-4 w-4 text-blue-300" />
                  <span className="text-blue-300 font-medium text-2xl">{bills.length}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="stats-grid">
        <Card className="medical-card hover-lift border-0 shadow-medical">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground font-medium">Total Revenue</p>
                <p className="text-3xl font-bold text-foreground">₹{getTotalRevenue().toLocaleString('en-IN')}</p>
              </div>
              <div className="rounded-lg bg-gradient-to-br from-green-500 to-green-600 p-3 shadow-lg">
                <CheckCircle className="h-6 w-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="medical-card hover-lift border-0 shadow-medical">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground font-medium">Pending Amount</p>
                <p className="text-3xl font-bold text-orange-600">₹{getPendingAmount().toLocaleString('en-IN')}</p>
              </div>
              <div className="rounded-lg bg-gradient-to-br from-orange-500 to-orange-600 p-3 shadow-lg">
                <Clock className="h-6 w-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="medical-card hover-lift border-0 shadow-medical">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground font-medium">Total Bills</p>
                <p className="text-3xl font-bold text-foreground">{bills.length}</p>
              </div>
              <div className="rounded-lg bg-gradient-to-br from-blue-500 to-blue-600 p-3 shadow-lg">
                <FileText className="h-6 w-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Search and Filters */}
      <div className="flex flex-col sm:flex-row gap-4 items-center justify-between">
        <div className="flex flex-1 gap-4 max-w-2xl">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search bills..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 rounded-xl border-border/50 focus-enhanced"
            />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-40 rounded-xl border-border/50 focus-enhanced">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="paid">Paid</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button className="rounded-xl bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white border-0 focus-enhanced">
              <Plus className="h-4 w-4 mr-2" />
              Create Bill
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Plus className="h-5 w-5 text-blue-600" />
                Create New Bill
              </DialogTitle>
              <DialogDescription>
                Select patient and tests to generate a new bill
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-6 py-4">
              <div className="space-y-2">
                <Label htmlFor="patient">Select Patient</Label>
                <Select value={selectedPatient} onValueChange={setSelectedPatient}>
                  <SelectTrigger className="rounded-lg focus-enhanced">
                    <SelectValue placeholder="Choose a patient" />
                  </SelectTrigger>
                  <SelectContent>
                    {mockPatients.map(patient => (
                      <SelectItem key={patient.id} value={patient.id}>
                        {patient.fullName} - {patient.phone}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label>Select Tests</Label>
                <div className="grid grid-cols-1 gap-2 max-h-48 overflow-y-auto border rounded-lg p-3">
                  {mockTests.map(test => (
                    <label key={test.id} className="flex items-center gap-3 p-2 hover:bg-accent/50 rounded cursor-pointer">
                      <input
                        type="checkbox"
                        checked={selectedTests.includes(test.id)}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setSelectedTests([...selectedTests, test.id]);
                          } else {
                            setSelectedTests(selectedTests.filter(id => id !== test.id));
                          }
                        }}
                        className="rounded"
                      />
                      <span className="flex-1">{test.name}</span>
                      <span className="font-medium">₹{test.price.toLocaleString('en-IN')}</span>
                    </label>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="discount">Discount (%)</Label>
                <div className="relative">
                  <Percent className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="discount"
                    type="number"
                    min="0"
                    max="100"
                    placeholder="Enter discount percentage"
                    value={discountPercent}
                    onChange={(e) => setDiscountPercent(Number(e.target.value))}
                    className="pl-10 rounded-lg focus-enhanced"
                  />
                </div>
              </div>

              {selectedTests.length > 0 && (
                <Card className="bg-muted/20">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm">Bill Summary</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Subtotal:</span>
                      <span>₹{calculateTotal().subtotal.toLocaleString('en-IN')}</span>
                    </div>
                    {discountPercent > 0 && (
                      <div className="flex justify-between text-sm text-orange-600">
                        <span>Discount ({discountPercent}%):</span>
                        <span>-₹{calculateTotal().discount.toLocaleString('en-IN')}</span>
                      </div>
                    )}
                    <Separator />
                    <div className="flex justify-between font-bold">
                      <span>Total:</span>
                      <span>₹{calculateTotal().total.toLocaleString('en-IN')}</span>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
            <div className="flex justify-end gap-3">
              <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                Cancel
              </Button>
              <Button 
                onClick={handleCreateBill} 
                disabled={!selectedPatient || selectedTests.length === 0}
                className="bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white border-0"
              >
                Create Bill
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Bills List */}
      <div className="space-y-4">
        {filteredBills.map((bill) => {
          const patient = mockPatients.find(p => p.id === bill.patientId);
          return (
            <Card key={bill.id} className="medical-card hover-lift border-0 shadow-medical">
              <CardContent className="p-6">
                <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
                  <div className="space-y-3">
                    <div className="flex flex-col sm:flex-row sm:items-center gap-3">
                      <h3 className="text-xl font-semibold text-foreground">{bill.invoiceNumber}</h3>
                      <div className="flex gap-2">
                        <Badge 
                          variant="outline" 
                          className={`${
                            bill.status === 'paid' 
                              ? 'bg-green-50 text-green-700 border-green-200 dark:bg-green-900 dark:text-green-100' 
                              : 'bg-orange-50 text-orange-700 border-orange-200 dark:bg-orange-900 dark:text-orange-100'
                          }`}
                        >
                          {bill.status === 'paid' ? (
                            <CheckCircle className="h-3 w-3 mr-1" />
                          ) : (
                            <Clock className="h-3 w-3 mr-1" />
                          )}
                          {bill.status === 'paid' ? 'Paid' : 'Pending'}
                        </Badge>
                        <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-900 dark:text-blue-100">
                          ₹{bill.finalAmount.toLocaleString('en-IN')}
                        </Badge>
                      </div>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm text-muted-foreground">
                      <div className="flex items-center gap-2">
                        <User className="h-4 w-4 text-blue-600" />
                        <span className="font-medium text-foreground">Patient:</span> {patient?.fullName}
                      </div>
                      <div className="flex items-center gap-2">
                        <Calendar className="h-4 w-4 text-orange-600" />
                        <span className="font-medium text-foreground">Date:</span> {new Date(bill.createdDate).toLocaleDateString('en-IN')}
                      </div>
                      <div className="flex items-center gap-2">
                        <IndianRupee className="h-4 w-4 text-green-600" />
                        <span className="font-medium text-foreground">Amount:</span> ₹{bill.amount.toLocaleString('en-IN')}
                      </div>
                      {bill.discount > 0 && (
                        <div className="flex items-center gap-2">
                          <Percent className="h-4 w-4 text-orange-600" />
                          <span className="font-medium text-foreground">Discount:</span> ₹{bill.discount.toLocaleString('en-IN')}
                        </div>
                      )}
                    </div>
                    <div className="space-y-1">
                      <p className="text-sm font-medium text-foreground">Tests:</p>
                      <div className="flex flex-wrap gap-1">
                        {bill.tests.map((test, index) => (
                          <Badge key={index} variant="secondary" className="text-xs">
                            {test}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </div>
                  <div className="flex flex-col sm:flex-row gap-3">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => viewBillPDF(bill)}
                      className="rounded-xl border-border/50 hover:bg-blue-50 hover:border-blue-200 dark:hover:bg-blue-950/50 focus-enhanced"
                    >
                      <Eye className="h-4 w-4 mr-2" />
                      View
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => viewBillPDF(bill)}
                      className="rounded-xl border-border/50 hover:bg-green-50 hover:border-green-200 dark:hover:bg-green-950/50 focus-enhanced"
                    >
                      <Download className="h-4 w-4 mr-2" />
                      Print
                    </Button>
                    {bill.status === 'pending' && (
                      <Button
                        size="sm"
                        onClick={() => markAsPaid(bill.id)}
                        className="rounded-xl bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white border-0 focus-enhanced"
                      >
                        <CheckCircle className="h-4 w-4 mr-2" />
                        Mark Paid
                      </Button>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {filteredBills.length === 0 && (
        <div className="text-center py-12">
          <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg">
            <FileText className="h-8 w-8 text-white" />
          </div>
          <p className="text-muted-foreground text-lg">No bills found matching your criteria.</p>
        </div>
      )}
    </div>
  );
}