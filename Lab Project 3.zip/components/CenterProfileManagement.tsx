import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Badge } from './ui/badge';
import { Alert, AlertDescription } from './ui/alert';
import { Separator } from './ui/separator';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { 
  Building2, Upload, Edit, Save, Camera, Globe, Phone, Mail, MapPin, 
  Clock, Award, FileText, CheckCircle, AlertCircle, Plus, X, Settings,
  Printer, Download
,
  Printer, Download
} from 'lucide-react';
import { DiagnosticCenter, CenterProfile } from '../App';

interface CenterProfileManagementProps {
  center: DiagnosticCenter;
  onProfileUpdate?: (profile: Partial<CenterProfile>) => void;
}

const mockProfile: CenterProfile = {
  id: '1',
  centerId: '1',
  logo: '/placeholder-logo.png',
  tagline: 'Your Health, Our Priority',
  licenseNumber: 'MH/MUM/2024/001',
  registrationNumber: 'REG2024001',
  website: 'https://apollodiagnostics.com',
  description: 'Apollo Diagnostics Mumbai is a state-of-the-art diagnostic center providing comprehensive healthcare solutions with cutting-edge technology and experienced professionals.',
  services: ['Blood Tests', 'Urine Analysis', 'X-Ray', 'Ultrasound', 'ECG', 'CT Scan', 'MRI'],
  operatingHours: 'Monday to Sunday: 6:00 AM - 10:00 PM',
  emergencyContact: '+91-9876543210',
  socialMedia: {
    facebook: 'https://facebook.com/apollodiagnostics',
    twitter: 'https://twitter.com/apollodiag',
    instagram: 'https://instagram.com/apollodiagnostics'
  },
  certifications: ['ISO 9001:2015', 'NABL Accredited', 'CAP Certified'],
  accreditations: ['NABH', 'JCI', 'NABL'],
  updatedDate: '2024-06-15'
};

export function CenterProfileManagement({ center, onProfileUpdate }: CenterProfileManagementProps) {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [profile, setProfile] = useState<CenterProfile>(mockProfile);
  const [isEditing, setIsEditing] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [newService, setNewService] = useState('');
  const [newCertification, setNewCertification] = useState('');

  // Center address and contact information that will be used on PDFs
  const [centerInfo, setCenterInfo] = useState({
    address: center.address || '',
    city: center.city || '',
    state: center.state || '',
    pincode: center.pincode || '',
    phone: center.ownerPhone || '',
    email: center.ownerEmail || '',
    ownerName: center.ownerName || ''
  });

  const handleSave = async () => {
    setIsLoading(true);
    setMessage(null);

    try {
      // Mock API call
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      setMessage({ type: 'success', text: 'Profile updated successfully! Address and contact information will appear on all PDF bills, invoices, and lab reports.' });
      setIsEditing(false);
      onProfileUpdate?.(profile);
      
      setTimeout(() => {
        setMessage(null);
      }, 5000);
      
    } catch (error) {
      setMessage({ type: 'error', text: 'Failed to update profile. Please try again.' });
    } finally {
      setIsLoading(false);
    }
  };

  const handleLogoUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      // In real implementation, upload to server and get URL
      const mockUrl = URL.createObjectURL(file);
      setProfile({ ...profile, logo: mockUrl });
    }
  };

  const addService = () => {
    if (newService.trim() && !profile.services.includes(newService.trim())) {
      setProfile({
        ...profile,
        services: [...profile.services, newService.trim()]
      });
      setNewService('');
    }
  };

  const removeService = (serviceToRemove: string) => {
    setProfile({
      ...profile,
      services: profile.services.filter(service => service !== serviceToRemove)
    });
  };

  const addCertification = () => {
    if (newCertification.trim() && !profile.certifications?.includes(newCertification.trim())) {
      setProfile({
        ...profile,
        certifications: [...(profile.certifications || []), newCertification.trim()]
      });
      setNewCertification('');
    }
  };

  const removeCertification = (certToRemove: string) => {
    setProfile({
      ...profile,
      certifications: profile.certifications?.filter(cert => cert !== certToRemove) || []
    });
  };

  return (
    <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" className="rounded-xl border-border/50 hover:bg-blue-50 hover:border-blue-200 dark:hover:bg-blue-950/50 focus-enhanced">
          <Settings className="h-4 w-4 mr-2" />
          Manage Profile
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-5xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Building2 className="h-5 w-5 text-blue-600" />
            Center Profile Management
          </DialogTitle>
          <DialogDescription>
            Manage your diagnostic center's profile information, address, and contact details. This information will appear on all PDF bills, invoices, and lab reports.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {message && (
            <Alert className={message.type === 'success' ? 'border-green-200 bg-green-50 dark:bg-green-950/50' : 'border-red-200 bg-red-50 dark:bg-red-950/50'}>
              {message.type === 'success' ? (
                <CheckCircle className="h-4 w-4 text-green-600" />
              ) : (
                <AlertCircle className="h-4 w-4 text-red-600" />
              )}
              <AlertDescription className={message.type === 'success' ? 'text-green-800 dark:text-green-200' : 'text-red-800 dark:text-red-200'}>
                {message.text}
              </AlertDescription>
            </Alert>
          )}

          {/* Logo and Basic Info */}
          <Card className="medical-card border-0 shadow-medical">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>Basic Information</span>
                <Button
                  variant={isEditing ? "default" : "outline"}
                  size="sm"
                  onClick={() => setIsEditing(!isEditing)}
                  disabled={isLoading}
                >
                  {isEditing ? (
                    <>
                      <Save className="h-4 w-4 mr-2" />
                      Save Changes
                    </>
                  ) : (
                    <>
                      <Edit className="h-4 w-4 mr-2" />
                      Edit Profile
                    </>
                  )}
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex flex-col sm:flex-row gap-6">
                {/* Logo Upload */}
                <div className="flex flex-col items-center space-y-4">
                  <div className="w-32 h-32 rounded-lg border-2 border-dashed border-border/50 flex items-center justify-center bg-muted/20 overflow-hidden">
                    {profile.logo ? (
                      <img src={profile.logo} alt="Center Logo" className="w-full h-full object-cover rounded-lg" />
                    ) : (
                      <div className="text-center">
                        <Camera className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
                        <p className="text-sm text-muted-foreground">No Logo</p>
                      </div>
                    )}
                  </div>
                  {isEditing && (
                    <div>
                      <input
                        type="file"
                        id="logo-upload"
                        accept="image/*"
                        onChange={handleLogoUpload}
                        className="hidden"
                      />
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => document.getElementById('logo-upload')?.click()}
                        className="rounded-lg"
                      >
                        <Upload className="h-4 w-4 mr-2" />
                        Upload Logo
                      </Button>
                    </div>
                  )}
                </div>

                {/* Basic Info Form */}
                <div className="flex-1 space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="centerName">Center Name</Label>
                      <Input
                        id="centerName"
                        value={center.name}
                        disabled
                        className="rounded-lg bg-muted/30"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="tagline">Tagline</Label>
                      <Input
                        id="tagline"
                        value={profile.tagline}
                        onChange={(e) => setProfile({ ...profile, tagline: e.target.value })}
                        disabled={!isEditing}
                        className="rounded-lg"
                        placeholder="Your center's tagline"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="licenseNumber">License Number</Label>
                      <Input
                        id="licenseNumber"
                        value={profile.licenseNumber}
                        onChange={(e) => setProfile({ ...profile, licenseNumber: e.target.value })}
                        disabled={!isEditing}
                        className="rounded-lg"
                        placeholder="Medical license number"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="registrationNumber">Registration Number</Label>
                      <Input
                        id="registrationNumber"
                        value={profile.registrationNumber}
                        onChange={(e) => setProfile({ ...profile, registrationNumber: e.target.value })}
                        disabled={!isEditing}
                        className="rounded-lg"
                        placeholder="Government registration number"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="website">Website</Label>
                      <Input
                        id="website"
                        value={profile.website}
                        onChange={(e) => setProfile({ ...profile, website: e.target.value })}
                        disabled={!isEditing}
                        className="rounded-lg"
                        placeholder="https://your-website.com"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="emergencyContact">Emergency Contact</Label>
                      <Input
                        id="emergencyContact"
                        value={profile.emergencyContact}
                        onChange={(e) => setProfile({ ...profile, emergencyContact: e.target.value })}
                        disabled={!isEditing}
                        className="rounded-lg"
                        placeholder="+91-XXXXXXXXXX"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="description">Description</Label>
                    <Textarea
                      id="description"
                      value={profile.description}
                      onChange={(e) => setProfile({ ...profile, description: e.target.value })}
                      disabled={!isEditing}
                      className="rounded-lg min-h-[100px]"
                      placeholder="Brief description of your diagnostic center"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="operatingHours">Operating Hours</Label>
                    <Input
                      id="operatingHours"
                      value={profile.operatingHours}
                      onChange={(e) => setProfile({ ...profile, operatingHours: e.target.value })}
                      disabled={!isEditing}
                      className="rounded-lg"
                      placeholder="e.g., Monday to Sunday: 6:00 AM - 10:00 PM"
                    />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Address & Contact Information - Prominent Section for PDF Use */}
          <Card className="medical-card border-0 shadow-medical border-l-4 border-l-blue-500">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MapPin className="h-5 w-5 text-blue-600" />
                Address & Contact Information
                <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                  <Printer className="h-3 w-3 mr-1" />
                  Appears on PDFs
                </Badge>
              </CardTitle>
              <CardDescription>
                This information will be prominently displayed on all PDF bills, invoices, and lab reports
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="centerAddress" className="flex items-center gap-2">
                    <MapPin className="h-4 w-4 text-blue-600" />
                    Center Address
                  </Label>
                  <Textarea
                    id="centerAddress"
                    value={centerInfo.address}
                    onChange={(e) => setCenterInfo({ ...centerInfo, address: e.target.value })}
                    disabled={!isEditing}
                    className="rounded-lg"
                    placeholder="Complete street address of your diagnostic center"
                    rows={3}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="centerPhone" className="flex items-center gap-2">
                    <Phone className="h-4 w-4 text-green-600" />
                    Center Phone Number
                  </Label>
                  <Input
                    id="centerPhone"
                    value={centerInfo.phone}
                    onChange={(e) => setCenterInfo({ ...centerInfo, phone: e.target.value })}
                    disabled={!isEditing}
                    className="rounded-lg"
                    placeholder="+91-XXXXXXXXXX"
                  />
                  <p className="text-xs text-muted-foreground">Primary contact number for patients</p>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="centerCity">City</Label>
                  <Input
                    id="centerCity"
                    value={centerInfo.city}
                    onChange={(e) => setCenterInfo({ ...centerInfo, city: e.target.value })}
                    disabled={!isEditing}
                    className="rounded-lg"
                    placeholder="City name"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="centerState">State</Label>
                  <Input
                    id="centerState"
                    value={centerInfo.state}
                    onChange={(e) => setCenterInfo({ ...centerInfo, state: e.target.value })}
                    disabled={!isEditing}
                    className="rounded-lg"
                    placeholder="State name"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="centerPincode">PIN Code</Label>
                  <Input
                    id="centerPincode"
                    value={centerInfo.pincode}
                    onChange={(e) => setCenterInfo({ ...centerInfo, pincode: e.target.value })}
                    disabled={!isEditing}
                    className="rounded-lg"
                    placeholder="6-digit PIN code"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="centerEmail" className="flex items-center gap-2">
                    <Mail className="h-4 w-4 text-orange-600" />
                    Email Address
                  </Label>
                  <Input
                    id="centerEmail"
                    value={centerInfo.email}
                    onChange={(e) => setCenterInfo({ ...centerInfo, email: e.target.value })}
                    disabled={!isEditing}
                    className="rounded-lg"
                    placeholder="contact@yourcenter.com"
                  />
                </div>
              </div>

              {/* Preview of how it will appear on PDFs */}
              {!isEditing && (
                <div className="mt-6 p-4 bg-muted/20 rounded-lg border border-border/50">
                  <h4 className="font-medium mb-3 flex items-center gap-2">
                    <FileText className="h-4 w-4 text-blue-600" />
                    PDF Preview
                  </h4>
                  <div className="text-sm space-y-1">
                    <p className="font-medium">{center.name}</p>
                    {centerInfo.address && <p>{centerInfo.address}</p>}
                    <p>{centerInfo.city && `${centerInfo.city}, `}{centerInfo.state && `${centerInfo.state} `}{centerInfo.pincode}</p>
                    {centerInfo.phone && <p>📞 {centerInfo.phone}</p>}
                    {centerInfo.email && <p>✉️ {centerInfo.email}</p>}
                    {profile.website && <p>🌐 {profile.website}</p>}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Services */}
          <Card className="medical-card border-0 shadow-medical">
            <CardHeader>
              <CardTitle>Services Offered</CardTitle>
              <CardDescription>List of medical services provided by your center</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex flex-wrap gap-2">
                  {profile.services.map((service, index) => (
                    <Badge key={index} variant="outline" className="bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-900 dark:text-blue-100">
                      {service}
                      {isEditing && (
                        <button
                          onClick={() => removeService(service)}
                          className="ml-2 text-blue-600 hover:text-blue-800"
                        >
                          <X className="h-3 w-3" />
                        </button>
                      )}
                    </Badge>
                  ))}
                </div>
                {isEditing && (
                  <div className="flex gap-2">
                    <Input
                      value={newService}
                      onChange={(e) => setNewService(e.target.value)}
                      placeholder="Add new service"
                      className="rounded-lg"
                      onKeyPress={(e) => e.key === 'Enter' && addService()}
                    />
                    <Button onClick={addService} size="sm" className="rounded-lg">
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Certifications & Accreditations */}
          <Card className="medical-card border-0 shadow-medical">
            <CardHeader>
              <CardTitle>Certifications & Accreditations</CardTitle>
              <CardDescription>Professional certifications and quality accreditations</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex flex-wrap gap-2">
                  {profile.certifications?.map((cert, index) => (
                    <Badge key={index} variant="outline" className="bg-green-50 text-green-700 border-green-200 dark:bg-green-900 dark:text-green-100">
                      <Award className="h-3 w-3 mr-1" />
                      {cert}
                      {isEditing && (
                        <button
                          onClick={() => removeCertification(cert)}
                          className="ml-2 text-green-600 hover:text-green-800"
                        >
                          <X className="h-3 w-3" />
                        </button>
                      )}
                    </Badge>
                  ))}
                </div>
                {isEditing && (
                  <div className="flex gap-2">
                    <Input
                      value={newCertification}
                      onChange={(e) => setNewCertification(e.target.value)}
                      placeholder="Add certification"
                      className="rounded-lg"
                      onKeyPress={(e) => e.key === 'Enter' && addCertification()}
                    />
                    <Button onClick={addCertification} size="sm" className="rounded-lg">
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Social Media */}
          <Card className="medical-card border-0 shadow-medical">
            <CardHeader>
              <CardTitle>Social Media & Additional Contact</CardTitle>
              <CardDescription>Social media links and additional contact information</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="facebook">Facebook</Label>
                  <Input
                    id="facebook"
                    value={profile.socialMedia?.facebook || ''}
                    onChange={(e) => setProfile({
                      ...profile,
                      socialMedia: { ...profile.socialMedia, facebook: e.target.value }
                    })}
                    disabled={!isEditing}
                    className="rounded-lg"
                    placeholder="https://facebook.com/yourpage"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="twitter">Twitter</Label>
                  <Input
                    id="twitter"
                    value={profile.socialMedia?.twitter || ''}
                    onChange={(e) => setProfile({
                      ...profile,
                      socialMedia: { ...profile.socialMedia, twitter: e.target.value }
                    })}
                    disabled={!isEditing}
                    className="rounded-lg"
                    placeholder="https://twitter.com/yourhandle"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="instagram">Instagram</Label>
                  <Input
                    id="instagram"
                    value={profile.socialMedia?.instagram || ''}
                    onChange={(e) => setProfile({
                      ...profile,
                      socialMedia: { ...profile.socialMedia, instagram: e.target.value }
                    })}
                    disabled={!isEditing}
                    className="rounded-lg"
                    placeholder="https://instagram.com/yourpage"
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="flex justify-end gap-3 pt-4 border-t">
          <Button variant="outline" onClick={() => setIsDialogOpen(false)} disabled={isLoading}>
            Close
          </Button>
          {isEditing && (
            <Button 
              onClick={handleSave}
              disabled={isLoading}
              className="bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white border-0"
            >
              {isLoading ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin mr-2" />
                  Saving...
                </>
              ) : (
                <>
                  <Save className="h-4 w-4 mr-2" />
                  Save Profile
                </>
              )}
            </Button>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}