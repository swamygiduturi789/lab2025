import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Badge } from './ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { 
  TestTube, Search, Plus, Edit, Trash2, IndianRupee, 
  Calendar, Activity, FileText, Beaker, Microscope, Heart
} from 'lucide-react';

interface Test {
  id: string;
  name: string;
  category: string;
  price: number;
  description: string;
  sampleType: string;
  duration: string;
  preparationInstructions: string;
  normalRange?: string;
  isActive: boolean;
  createdDate: string;
}

interface TestManagementProps {
  centerId: string;
}

const mockTests: Test[] = [
  {
    id: '1',
    name: 'Complete Blood Count (CBC)',
    category: 'Hematology',
    price: 500,
    description: 'Comprehensive blood test to check overall health',
    sampleType: 'Blood',
    duration: '2-4 hours',
    preparationInstructions: 'No special preparation required',
    normalRange: 'Varies by parameter',
    isActive: true,
    createdDate: '2024-01-01'
  },
  {
    id: '2',
    name: 'Lipid Profile',
    category: 'Biochemistry',
    price: 800,
    description: 'Measures cholesterol and triglyceride levels',
    sampleType: 'Blood',
    duration: '4-6 hours',
    preparationInstructions: '12-hour fasting required',
    normalRange: 'Total Cholesterol: <200 mg/dL',
    isActive: true,
    createdDate: '2024-01-01'
  },
  {
    id: '3',
    name: 'Urine Routine & Microscopy',
    category: 'Clinical Pathology',
    price: 300,
    description: 'Comprehensive urine analysis',
    sampleType: 'Urine',
    duration: '1-2 hours',
    preparationInstructions: 'Clean catch mid-stream sample',
    normalRange: 'Specific gravity: 1.003-1.030',
    isActive: true,
    createdDate: '2024-01-01'
  },
  {
    id: '4',
    name: 'Thyroid Function Test (TFT)',
    category: 'Endocrinology',
    price: 1200,
    description: 'Tests thyroid hormones T3, T4, and TSH',
    sampleType: 'Blood',
    duration: '6-8 hours',
    preparationInstructions: 'No special preparation required',
    normalRange: 'TSH: 0.4-4.0 mIU/L',
    isActive: true,
    createdDate: '2024-01-01'
  },
  {
    id: '5',
    name: 'Chest X-Ray',
    category: 'Radiology',
    price: 600,
    description: 'X-ray imaging of chest and lungs',
    sampleType: 'Imaging',
    duration: '30 minutes',
    preparationInstructions: 'Remove jewelry and metal objects',
    isActive: true,
    createdDate: '2024-01-01'
  }
];

const testCategories = [
  'Hematology',
  'Biochemistry',
  'Clinical Pathology',
  'Endocrinology',
  'Radiology',
  'Microbiology',
  'Immunology',
  'Pathology'
];

const sampleTypes = [
  'Blood',
  'Urine',
  'Stool',
  'Saliva',
  'Imaging',
  'Biopsy',
  'Swab'
];

export function TestManagement({ centerId }: TestManagementProps) {
  const [tests, setTests] = useState<Test[]>(mockTests);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedTest, setSelectedTest] = useState<Test | null>(null);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [newTest, setNewTest] = useState<Partial<Test>>({});
  const [editTest, setEditTest] = useState<Partial<Test>>({});

  const filteredTests = tests.filter(test => {
    const matchesSearch = test.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         test.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         test.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || test.category === selectedCategory;
    return matchesSearch && matchesCategory && test.isActive;
  });

  const handleAddTest = () => {
    const test: Test = {
      id: (tests.length + 1).toString(),
      name: newTest.name || '',
      category: newTest.category || '',
      price: newTest.price || 0,
      description: newTest.description || '',
      sampleType: newTest.sampleType || '',
      duration: newTest.duration || '',
      preparationInstructions: newTest.preparationInstructions || '',
      normalRange: newTest.normalRange || '',
      isActive: true,
      createdDate: new Date().toISOString().split('T')[0]
    };

    setTests([...tests, test]);
    setNewTest({});
    setIsAddDialogOpen(false);
  };

  const handleEditTest = () => {
    if (selectedTest) {
      const updatedTests = tests.map(t =>
        t.id === selectedTest.id ? { ...selectedTest, ...editTest } : t
      );
      setTests(updatedTests);
      setEditTest({});
      setIsEditDialogOpen(false);
      setSelectedTest(null);
    }
  };

  const handleDeleteTest = (testId: string) => {
    if (confirm('Are you sure you want to delete this test?')) {
      setTests(tests.map(t => t.id === testId ? { ...t, isActive: false } : t));
    }
  };

  const toggleTestStatus = (testId: string) => {
    setTests(tests.map(t => t.id === testId ? { ...t, isActive: !t.isActive } : t));
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'Hematology': return <Heart className="h-4 w-4" />;
      case 'Biochemistry': return <Beaker className="h-4 w-4" />;
      case 'Clinical Pathology': return <Microscope className="h-4 w-4" />;
      case 'Radiology': return <Activity className="h-4 w-4" />;
      default: return <TestTube className="h-4 w-4" />;
    }
  };

  const getTotalRevenue = () => {
    return tests.reduce((total, test) => total + (test.isActive ? test.price : 0), 0);
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-purple-600 via-indigo-600 to-blue-600 p-8 text-white shadow-medical-lg">
        <div className="absolute inset-0 opacity-20" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.1'%3E%3Cpath d='M30 20c5.523 0 10 4.477 10 10s-4.477 10-10 10-10-4.477-10-10 4.477-10 10-10z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`
        }}></div>
        <div className="relative z-10">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl md:text-4xl font-bold mb-2 flex items-center gap-3">
                <TestTube className="h-8 w-8 text-purple-300" />
                Test Management
              </h1>
              <p className="text-blue-100 text-lg">Manage lab tests, pricing, and test parameters</p>
            </div>
            <div className="hidden lg:block">
              <div className="text-right">
                <p className="text-blue-100 text-sm">Active Tests</p>
                <div className="flex items-center gap-2 justify-end">
                  <Activity className="h-4 w-4 text-purple-300" />
                  <span className="text-purple-300 font-medium text-2xl">{tests.filter(t => t.isActive).length}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="stats-grid">
        <Card className="medical-card hover-lift border-0 shadow-medical">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground font-medium">Total Tests</p>
                <p className="text-3xl font-bold text-foreground">{tests.filter(t => t.isActive).length}</p>
              </div>
              <div className="rounded-lg bg-gradient-to-br from-purple-500 to-purple-600 p-3 shadow-lg">
                <TestTube className="h-6 w-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="medical-card hover-lift border-0 shadow-medical">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground font-medium">Categories</p>
                <p className="text-3xl font-bold text-foreground">{testCategories.length}</p>
              </div>
              <div className="rounded-lg bg-gradient-to-br from-blue-500 to-blue-600 p-3 shadow-lg">
                <FileText className="h-6 w-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="medical-card hover-lift border-0 shadow-medical">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground font-medium">Avg. Price</p>
                <p className="text-3xl font-bold text-foreground">₹{Math.round(getTotalRevenue() / tests.filter(t => t.isActive).length)}</p>
              </div>
              <div className="rounded-lg bg-gradient-to-br from-green-500 to-green-600 p-3 shadow-lg">
                <IndianRupee className="h-6 w-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Search and Filters */}
      <div className="flex flex-col sm:flex-row gap-4 items-center justify-between">
        <div className="flex flex-1 gap-4 max-w-2xl">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search tests..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 rounded-xl border-border/50 focus-enhanced"
            />
          </div>
          <Select value={selectedCategory} onValueChange={setSelectedCategory}>
            <SelectTrigger className="w-48 rounded-xl border-border/50 focus-enhanced">
              <SelectValue placeholder="Category" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Categories</SelectItem>
              {testCategories.map(category => (
                <SelectItem key={category} value={category}>{category}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button className="rounded-xl bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700 text-white border-0 focus-enhanced">
              <Plus className="h-4 w-4 mr-2" />
              Add Test
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Plus className="h-5 w-5 text-purple-600" />
                Add New Test
              </DialogTitle>
              <DialogDescription>
                Enter test information to add to your lab menu
              </DialogDescription>
            </DialogHeader>
            <div className="grid grid-cols-2 gap-4 py-4">
              <div className="space-y-2 col-span-2">
                <Label htmlFor="name">Test Name</Label>
                <Input
                  id="name"
                  placeholder="Enter test name"
                  value={newTest.name || ''}
                  onChange={(e) => setNewTest({...newTest, name: e.target.value})}
                  className="rounded-lg focus-enhanced"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="category">Category</Label>
                <Select value={newTest.category || ''} onValueChange={(value) => setNewTest({...newTest, category: value})}>
                  <SelectTrigger className="rounded-lg focus-enhanced">
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    {testCategories.map(category => (
                      <SelectItem key={category} value={category}>{category}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="price">Price (₹)</Label>
                <Input
                  id="price"
                  type="number"
                  placeholder="Enter price"
                  value={newTest.price || ''}
                  onChange={(e) => setNewTest({...newTest, price: parseInt(e.target.value)})}
                  className="rounded-lg focus-enhanced"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="sampleType">Sample Type</Label>
                <Select value={newTest.sampleType || ''} onValueChange={(value) => setNewTest({...newTest, sampleType: value})}>
                  <SelectTrigger className="rounded-lg focus-enhanced">
                    <SelectValue placeholder="Select sample type" />
                  </SelectTrigger>
                  <SelectContent>
                    {sampleTypes.map(type => (
                      <SelectItem key={type} value={type}>{type}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="duration">Duration</Label>
                <Input
                  id="duration"
                  placeholder="e.g., 2-4 hours"
                  value={newTest.duration || ''}
                  onChange={(e) => setNewTest({...newTest, duration: e.target.value})}
                  className="rounded-lg focus-enhanced"
                />
              </div>
              <div className="space-y-2 col-span-2">
                <Label htmlFor="description">Description</Label>
                <Input
                  id="description"
                  placeholder="Enter test description"
                  value={newTest.description || ''}
                  onChange={(e) => setNewTest({...newTest, description: e.target.value})}
                  className="rounded-lg focus-enhanced"
                />
              </div>
              <div className="space-y-2 col-span-2">
                <Label htmlFor="preparation">Preparation Instructions</Label>
                <Input
                  id="preparation"
                  placeholder="Enter preparation instructions"
                  value={newTest.preparationInstructions || ''}
                  onChange={(e) => setNewTest({...newTest, preparationInstructions: e.target.value})}
                  className="rounded-lg focus-enhanced"
                />
              </div>
              <div className="space-y-2 col-span-2">
                <Label htmlFor="normalRange">Normal Range (Optional)</Label>
                <Input
                  id="normalRange"
                  placeholder="Enter normal range"
                  value={newTest.normalRange || ''}
                  onChange={(e) => setNewTest({...newTest, normalRange: e.target.value})}
                  className="rounded-lg focus-enhanced"
                />
              </div>
            </div>
            <div className="flex justify-end gap-3">
              <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                Cancel
              </Button>
              <Button onClick={handleAddTest} className="bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700 text-white border-0">
                Add Test
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Tests List */}
      <div className="space-y-4">
        {filteredTests.map((test) => (
          <Card key={test.id} className="medical-card hover-lift border-0 shadow-medical">
            <CardContent className="p-6">
              <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-6">
                <div className="space-y-4 flex-1">
                  <div className="flex flex-col sm:flex-row sm:items-center gap-3">
                    <h3 className="text-xl font-semibold text-foreground">{test.name}</h3>
                    <div className="flex gap-2">
                      <Badge variant="outline" className="bg-purple-50 text-purple-700 border-purple-200 dark:bg-purple-900 dark:text-purple-100 flex items-center gap-1">
                        {getCategoryIcon(test.category)}
                        {test.category}
                      </Badge>
                      <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200 dark:bg-green-900 dark:text-green-100">
                        ₹{test.price.toLocaleString('en-IN')}
                      </Badge>
                    </div>
                  </div>
                  <p className="text-muted-foreground">{test.description}</p>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 text-sm">
                    <div className="flex items-center gap-2">
                      <TestTube className="h-4 w-4 text-blue-600" />
                      <span className="font-medium text-foreground">Sample:</span> {test.sampleType}
                    </div>
                    <div className="flex items-center gap-2">
                      <Calendar className="h-4 w-4 text-orange-600" />
                      <span className="font-medium text-foreground">Duration:</span> {test.duration}
                    </div>
                    {test.normalRange && (
                      <div className="flex items-center gap-2 col-span-1 md:col-span-2 lg:col-span-1">
                        <Activity className="h-4 w-4 text-green-600" />
                        <span className="font-medium text-foreground">Range:</span> {test.normalRange}
                      </div>
                    )}
                  </div>
                  {test.preparationInstructions && (
                    <div className="p-3 bg-amber-50 dark:bg-amber-950/50 rounded-lg border border-amber-200 dark:border-amber-800">
                      <p className="text-sm font-medium text-amber-800 dark:text-amber-200">Preparation:</p>
                      <p className="text-sm text-amber-700 dark:text-amber-300">{test.preparationInstructions}</p>
                    </div>
                  )}
                </div>
                <div className="flex flex-col sm:flex-row gap-3">
                  <Dialog open={isEditDialogOpen && selectedTest?.id === test.id} onOpenChange={(open) => {
                    setIsEditDialogOpen(open);
                    if (!open) {
                      setSelectedTest(null);
                      setEditTest({});
                    }
                  }}>
                    <DialogTrigger asChild>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          setSelectedTest(test);
                          setEditTest(test);
                        }}
                        className="rounded-xl border-border/50 hover:bg-yellow-50 hover:border-yellow-200 dark:hover:bg-yellow-950/50 focus-enhanced"
                      >
                        <Edit className="h-4 w-4 mr-2" />
                        Edit
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                      <DialogHeader>
                        <DialogTitle className="flex items-center gap-2">
                          <Edit className="h-5 w-5 text-yellow-600" />
                          Edit Test
                        </DialogTitle>
                      </DialogHeader>
                      <div className="grid grid-cols-2 gap-4 py-4">
                        <div className="space-y-2 col-span-2">
                          <Label htmlFor="editName">Test Name</Label>
                          <Input
                            id="editName"
                            value={editTest.name || ''}
                            onChange={(e) => setEditTest({...editTest, name: e.target.value})}
                            className="rounded-lg focus-enhanced"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="editCategory">Category</Label>
                          <Select value={editTest.category || ''} onValueChange={(value) => setEditTest({...editTest, category: value})}>
                            <SelectTrigger className="rounded-lg focus-enhanced">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              {testCategories.map(category => (
                                <SelectItem key={category} value={category}>{category}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="editPrice">Price (₹)</Label>
                          <Input
                            id="editPrice"
                            type="number"
                            value={editTest.price || ''}
                            onChange={(e) => setEditTest({...editTest, price: parseInt(e.target.value)})}
                            className="rounded-lg focus-enhanced"
                          />
                        </div>
                        <div className="space-y-2 col-span-2">
                          <Label htmlFor="editDescription">Description</Label>
                          <Input
                            id="editDescription"
                            value={editTest.description || ''}
                            onChange={(e) => setEditTest({...editTest, description: e.target.value})}
                            className="rounded-lg focus-enhanced"
                          />
                        </div>
                      </div>
                      <div className="flex justify-end gap-3">
                        <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
                          Cancel
                        </Button>
                        <Button onClick={handleEditTest} className="bg-gradient-to-r from-yellow-500 to-yellow-600 hover:from-yellow-600 hover:to-yellow-700 text-white border-0">
                          Save Changes
                        </Button>
                      </div>
                    </DialogContent>
                  </Dialog>

                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleDeleteTest(test.id)}
                    className="rounded-xl border-red-200 text-red-600 hover:bg-red-50 hover:border-red-300 dark:hover:bg-red-950/50 focus-enhanced"
                  >
                    <Trash2 className="h-4 w-4 mr-2" />
                    Delete
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredTests.length === 0 && (
        <div className="text-center py-12">
          <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-purple-600 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg">
            <TestTube className="h-8 w-8 text-white" />
          </div>
          <p className="text-muted-foreground text-lg">No tests found matching your criteria.</p>
        </div>
      )}
    </div>
  );
}