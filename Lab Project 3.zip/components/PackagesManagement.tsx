import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Crown, Star, Gift, Check, IndianRupee } from 'lucide-react';

interface Package {
  id: string;
  name: string;
  price: number;
  features: string[];
  isPopular?: boolean;
  color: string;
  icon: React.ReactNode;
}

const packages: Package[] = [
  {
    id: 'free',
    name: 'Free Plan',
    price: 0,
    features: [
      'Up to 50 patients',
      'Basic test management',
      'PDF reports',
      'Email support',
      'Basic analytics'
    ],
    color: 'green',
    icon: <Gift className="h-6 w-6" />
  },
  {
    id: 'standard',
    name: 'Standard Plan',
    price: 2999,
    features: [
      'Up to 500 patients',
      'Advanced test management',
      'Custom PDF templates',
      'SMS notifications',
      'Advanced analytics',
      'Phone support',
      'Data backup'
    ],
    isPopular: true,
    color: 'blue',
    icon: <Star className="h-6 w-6" />
  },
  {
    id: 'gold',
    name: 'Gold Plan',
    price: 4999,
    features: [
      'Unlimited patients',
      'Complete test suite',
      'Branded reports',
      'WhatsApp integration',
      'Real-time analytics',
      'Priority support',
      'API access',
      'Multi-location support',
      'Custom integrations'
    ],
    color: 'yellow',
    icon: <Crown className="h-6 w-6" />
  }
];

export function PackagesManagement() {
  const [selectedPackage, setSelectedPackage] = useState<string>('standard');

  const getPackageStats = () => {
    return {
      totalPackages: packages.length,
      activeSubscriptions: 156,
      monthlyRevenue: 587000,
      conversionRate: 15.3
    };
  };

  const stats = getPackageStats();

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-yellow-600 via-orange-600 to-red-600 p-8 text-white shadow-medical-lg">
        <div className="absolute inset-0 opacity-20" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.1'%3E%3Cpath d='M30 4c14.359 0 26 11.641 26 26S44.359 56 30 56 4 44.359 4 30 15.641 4 30 4z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`
        }}></div>
        <div className="relative z-10">
          <h1 className="text-3xl md:text-4xl font-bold mb-2 flex items-center gap-3">
            <Crown className="h-8 w-8 text-yellow-300" />
            Subscription Packages
          </h1>
          <p className="text-orange-100 text-lg">Manage subscription plans and pricing</p>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="stats-grid">
        <Card className="medical-card hover-lift border-0 shadow-medical">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground font-medium">Active Subscriptions</p>
                <p className="text-3xl font-bold text-foreground">{stats.activeSubscriptions}</p>
              </div>
              <div className="rounded-lg bg-gradient-to-br from-blue-500 to-blue-600 p-3 shadow-lg">
                <Star className="h-6 w-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="medical-card hover-lift border-0 shadow-medical">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground font-medium">Monthly Revenue</p>
                <p className="text-3xl font-bold text-foreground">₹{stats.monthlyRevenue.toLocaleString('en-IN')}</p>
              </div>
              <div className="rounded-lg bg-gradient-to-br from-green-500 to-green-600 p-3 shadow-lg">
                <IndianRupee className="h-6 w-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="medical-card hover-lift border-0 shadow-medical">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground font-medium">Conversion Rate</p>
                <p className="text-3xl font-bold text-foreground">{stats.conversionRate}%</p>
              </div>
              <div className="rounded-lg bg-gradient-to-br from-purple-500 to-purple-600 p-3 shadow-lg">
                <Crown className="h-6 w-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Package Cards */}
      <div className="dashboard-grid">
        {packages.map((pkg) => (
          <Card 
            key={pkg.id} 
            className={`medical-card hover-lift border-0 shadow-medical relative ${
              pkg.isPopular ? 'ring-2 ring-blue-500 ring-offset-2' : ''
            }`}
          >
            {pkg.isPopular && (
              <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                <Badge className="bg-gradient-to-r from-blue-500 to-blue-600 text-white px-4 py-1">
                  Most Popular
                </Badge>
              </div>
            )}
            <CardHeader className="text-center pb-4">
              <div className={`mx-auto w-16 h-16 rounded-2xl flex items-center justify-center shadow-lg mb-4 bg-gradient-to-br ${
                pkg.color === 'green' ? 'from-green-500 to-green-600' :
                pkg.color === 'blue' ? 'from-blue-500 to-blue-600' :
                'from-yellow-500 to-yellow-600'
              }`}>
                <div className="text-white">
                  {pkg.icon}
                </div>
              </div>
              <CardTitle className="text-2xl font-bold">{pkg.name}</CardTitle>
              <div className="text-4xl font-bold text-foreground">
                {pkg.price === 0 ? 'Free' : `₹${pkg.price.toLocaleString('en-IN')}`}
                {pkg.price > 0 && <span className="text-sm font-normal text-muted-foreground">/month</span>}
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-3">
                {pkg.features.map((feature, index) => (
                  <div key={index} className="flex items-center gap-2">
                    <div className={`w-5 h-5 rounded-full flex items-center justify-center bg-gradient-to-br ${
                      pkg.color === 'green' ? 'from-green-500 to-green-600' :
                      pkg.color === 'blue' ? 'from-blue-500 to-blue-600' :
                      'from-yellow-500 to-yellow-600'
                    }`}>
                      <Check className="h-3 w-3 text-white" />
                    </div>
                    <span className="text-sm text-muted-foreground">{feature}</span>
                  </div>
                ))}
              </div>
              <Button 
                className={`w-full rounded-xl focus-enhanced ${
                  pkg.color === 'green' ? 'bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700' :
                  pkg.color === 'blue' ? 'bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700' :
                  'bg-gradient-to-r from-yellow-500 to-yellow-600 hover:from-yellow-600 hover:to-yellow-700'
                } text-white border-0`}
              >
                {pkg.price === 0 ? 'Current Plan' : 'Upgrade Plan'}
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Package Comparison */}
      <Card className="medical-card border-0 shadow-medical">
        <CardHeader>
          <CardTitle className="text-xl font-semibold">Feature Comparison</CardTitle>
          <CardDescription>Compare features across all subscription plans</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b">
                  <th className="text-left py-3 pr-4">Features</th>
                  {packages.map(pkg => (
                    <th key={pkg.id} className="text-center py-3 px-4 font-medium">
                      {pkg.name}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                <tr className="border-b">
                  <td className="py-3 pr-4">Patient Limit</td>
                  <td className="text-center py-3 px-4">50</td>
                  <td className="text-center py-3 px-4">500</td>
                  <td className="text-center py-3 px-4">Unlimited</td>
                </tr>
                <tr className="border-b">
                  <td className="py-3 pr-4">SMS Notifications</td>
                  <td className="text-center py-3 px-4">❌</td>
                  <td className="text-center py-3 px-4">✅</td>
                  <td className="text-center py-3 px-4">✅</td>
                </tr>
                <tr className="border-b">
                  <td className="py-3 pr-4">WhatsApp Integration</td>
                  <td className="text-center py-3 px-4">❌</td>
                  <td className="text-center py-3 px-4">❌</td>
                  <td className="text-center py-3 px-4">✅</td>
                </tr>
                <tr className="border-b">
                  <td className="py-3 pr-4">API Access</td>
                  <td className="text-center py-3 px-4">❌</td>
                  <td className="text-center py-3 px-4">❌</td>
                  <td className="text-center py-3 px-4">✅</td>
                </tr>
                <tr>
                  <td className="py-3 pr-4">Support Level</td>
                  <td className="text-center py-3 px-4">Email</td>
                  <td className="text-center py-3 px-4">Phone</td>
                  <td className="text-center py-3 px-4">Priority</td>
                </tr>
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}