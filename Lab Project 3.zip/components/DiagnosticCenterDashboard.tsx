import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, LineChart, Line
} from 'recharts';
import { 
  LayoutDashboard, Users, FileText, TestTube, Settings, LogOut, 
  IndianRupee, Calendar, TrendingUp, UserPlus, FileCheck, Bell,
  Activity, Heart, Stethoscope, ChevronLeft, Moon, Sun, Sparkles
} from 'lucide-react';
import { User } from '../App';
import { PatientManagement } from './PatientManagement';
import { TestManagement } from './TestManagement';
import { ReportGeneration } from './ReportGeneration';
import { EnhancedBillManagement } from './EnhancedBillManagement';
import { SupportCenter } from './SupportCenter';
import { PasswordChangeForm } from './PasswordChangeForm';
import { CenterProfileManagement } from './CenterProfileManagement';
import { NewFeaturesDemo } from './NewFeaturesDemo';
import { useSidebar } from '../contexts/SidebarContext';

interface DiagnosticCenterDashboardProps {
  user: User;
  onLogout: () => void;
}

type DashboardView = 'dashboard' | 'patients' | 'tests' | 'reports' | 'bills' | 'support' | 'settings';

// Mock data for analytics
const weeklyData = [
  { day: 'Mon', patients: 45, tests: 78, revenue: 15600 },
  { day: 'Tue', patients: 52, tests: 89, revenue: 18900 },
  { day: 'Wed', patients: 48, tests: 82, revenue: 17200 },
  { day: 'Thu', patients: 61, tests: 95, revenue: 21400 },
  { day: 'Fri', patients: 55, tests: 88, revenue: 19800 },
  { day: 'Sat', patients: 38, tests: 65, revenue: 14200 },
  { day: 'Sun', patients: 29, tests: 51, revenue: 11800 },
];

const testTypeData = [
  { name: 'Blood Tests', value: 245, color: '#3b82f6' },
  { name: 'Urine Tests', value: 156, color: '#10b981' },
  { name: 'X-Ray', value: 89, color: '#f59e0b' },
  { name: 'Ultrasound', value: 67, color: '#8b5cf6' },
  { name: 'Others', value: 43, color: '#ef4444' }
];

export function DiagnosticCenterDashboard({ user, onLogout }: DiagnosticCenterDashboardProps) {
  const [currentView, setCurrentView] = useState<DashboardView>('dashboard');
  const [isDarkMode, setIsDarkMode] = useState(false);
  const { isCollapsed, toggleSidebar, isMobile } = useSidebar();

  // Debug: Verify logout function is available
  React.useEffect(() => {
    if (process.env.NODE_ENV === 'development') {
      console.log('🔐 DiagnosticCenterDashboard - onLogout function:', typeof onLogout);
    }
  }, [onLogout]);

  const toggleDarkMode = () => {
    setIsDarkMode(!isDarkMode);
    document.documentElement.classList.toggle('dark');
  };

  const sidebarItems = [
    {
      id: 'dashboard',
      label: 'Dashboard',
      icon: LayoutDashboard,
      view: 'dashboard' as DashboardView,
    },
    {
      id: 'patients',
      label: 'Patient Management',
      icon: Users,
      view: 'patients' as DashboardView,
    },
    {
      id: 'tests',
      label: 'Test Management',
      icon: TestTube,
      view: 'tests' as DashboardView,
    },
    {
      id: 'reports',
      label: 'Report Generation',
      icon: FileText,
      view: 'reports' as DashboardView,
    },
    {
      id: 'bills',
      label: 'Bill Management',
      icon: IndianRupee,
      view: 'bills' as DashboardView,
    },
    {
      id: 'support',
      label: 'Support Center',
      icon: Bell,
      view: 'support' as DashboardView,
    },
    {
      id: 'settings',
      label: 'Settings',
      icon: Settings,
      view: 'settings' as DashboardView,
    }
  ];

  const renderDashboard = () => (
    <div className="space-y-8">
      {/* Welcome Header */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-teal-600 via-blue-600 to-indigo-600 p-8 text-white shadow-medical-lg">
        <div className="absolute inset-0 opacity-20" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.1'%3E%3Cpath d='M30 30c0-11.046-8.954-20-20-20s-20 8.954-20 20 8.954 20 20 20 20-8.954 20-20z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`
        }}></div>
        <div className="relative z-10">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl md:text-4xl font-bold mb-2 flex items-center gap-3">
                <Stethoscope className="h-8 w-8 text-teal-300" />
                Welcome, {user.name}!
              </h1>
              <p className="text-blue-100 text-lg">
                {user.centerName || 'Diagnostic Center'} - Dashboard
              </p>
            </div>
            <div className="hidden lg:block">
              <div className="text-right">
                <p className="text-blue-100 text-sm">Today's Status</p>
                <div className="flex items-center gap-2 justify-end">
                  <Heart className="h-4 w-4 text-green-300" />
                  <span className="text-green-300 font-medium">All Systems Active</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="stats-grid">
        <Card className="medical-card hover-lift border-0 shadow-medical">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground font-medium">Today's Patients</p>
                <p className="text-3xl font-bold text-foreground">61</p>
                <p className="text-xs text-green-600 font-medium">+8% from yesterday</p>
              </div>
              <div className="rounded-lg bg-gradient-to-br from-blue-500 to-blue-600 p-3 shadow-lg">
                <Users className="h-6 w-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="medical-card hover-lift border-0 shadow-medical">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground font-medium">Tests Completed</p>
                <p className="text-3xl font-bold text-foreground">95</p>
                <p className="text-xs text-green-600 font-medium">+12% efficiency</p>
              </div>
              <div className="rounded-lg bg-gradient-to-br from-green-500 to-green-600 p-3 shadow-lg">
                <TestTube className="h-6 w-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="medical-card hover-lift border-0 shadow-medical">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground font-medium">Today's Revenue</p>
                <p className="text-3xl font-bold text-foreground">₹21,400</p>
                <p className="text-xs text-green-600 font-medium">+15% from target</p>
              </div>
              <div className="rounded-lg bg-gradient-to-br from-purple-500 to-purple-600 p-3 shadow-lg">
                <IndianRupee className="h-6 w-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="medical-card hover-lift border-0 shadow-medical">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground font-medium">Pending Reports</p>
                <p className="text-3xl font-bold text-foreground">8</p>
                <p className="text-xs text-yellow-600 font-medium">2 urgent</p>
              </div>
              <div className="rounded-lg bg-gradient-to-br from-orange-500 to-orange-600 p-3 shadow-lg">
                <FileCheck className="h-6 w-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts Section */}
      <div className="dashboard-grid">
        <Card className="medical-card hover-lift border-0 shadow-medical lg:col-span-2">
          <CardHeader className="pb-4">
            <CardTitle className="text-xl font-semibold flex items-center gap-2">
              <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
              Weekly Performance
            </CardTitle>
            <CardDescription>Patient visits, tests, and revenue trends</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={weeklyData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                <XAxis dataKey="day" tick={{ fill: '#64748b', fontSize: 12 }} />
                <YAxis tick={{ fill: '#64748b', fontSize: 12 }} />
                <Tooltip 
                  formatter={(value, name) => [
                    name === 'revenue' ? `₹${value.toLocaleString('en-IN')}` : value,
                    name === 'revenue' ? 'Revenue' : name === 'patients' ? 'Patients' : 'Tests'
                  ]}
                  contentStyle={{
                    backgroundColor: '#ffffff',
                    border: '1px solid #e2e8f0',
                    borderRadius: '8px',
                    boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
                  }}
                />
                <Bar dataKey="patients" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                <Bar dataKey="tests" fill="#10b981" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="medical-card hover-lift border-0 shadow-medical">
          <CardHeader className="pb-4">
            <CardTitle className="text-xl font-semibold flex items-center gap-2">
              <div className="w-2 h-2 bg-green-500 rounded-full"></div>
              Test Distribution
            </CardTitle>
            <CardDescription>Types of tests performed this month</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <PieChart>
                <Pie
                  data={testTypeData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {testTypeData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{
                    backgroundColor: '#ffffff',
                    border: '1px solid #e2e8f0',
                    borderRadius: '8px',
                    boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card className="medical-card hover-lift border-0 shadow-medical">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Sparkles className="h-5 w-5 text-teal-600" />
            Quick Actions
          </CardTitle>
          <CardDescription>Frequently used functions for faster workflow</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Button
              onClick={() => setCurrentView('patients')}
              variant="outline"
              className="h-20 flex-col gap-2 rounded-xl border-border/50 hover:bg-blue-50 hover:border-blue-200 dark:hover:bg-blue-950/50 focus-enhanced"
            >
              <UserPlus className="h-6 w-6 text-blue-600" />
              <span className="text-sm">Add Patient</span>
            </Button>
            <Button
              onClick={() => setCurrentView('tests')}
              variant="outline"
              className="h-20 flex-col gap-2 rounded-xl border-border/50 hover:bg-green-50 hover:border-green-200 dark:hover:bg-green-950/50 focus-enhanced"
            >
              <TestTube className="h-6 w-6 text-green-600" />
              <span className="text-sm">Manage Tests</span>
            </Button>
            <Button
              onClick={() => setCurrentView('reports')}
              variant="outline"
              className="h-20 flex-col gap-2 rounded-xl border-border/50 hover:bg-purple-50 hover:border-purple-200 dark:hover:bg-purple-950/50 focus-enhanced"
            >
              <FileText className="h-6 w-6 text-purple-600" />
              <span className="text-sm">Generate Report</span>
            </Button>
            <Button
              onClick={() => setCurrentView('bills')}
              variant="outline"
              className="h-20 flex-col gap-2 rounded-xl border-border/50 hover:bg-orange-50 hover:border-orange-200 dark:hover:bg-orange-950/50 focus-enhanced"
            >
              <IndianRupee className="h-6 w-6 text-orange-600" />
              <span className="text-sm">Manage Bills</span>
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Recent Activity */}
      <Card className="medical-card hover-lift border-0 shadow-medical">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="h-5 w-5 text-blue-600" />
            Recent Activity
          </CardTitle>
          <CardDescription>Latest center activities and updates</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[
              { action: 'New patient registered', details: 'Priya Sharma - Complete Blood Count', time: '5 minutes ago', type: 'success' },
              { action: 'Test completed', details: 'Lipid Profile for Rajesh Kumar', time: '15 minutes ago', type: 'info' },
              { action: 'Report generated', details: 'Urine Analysis - ID: UR001', time: '1 hour ago', type: 'success' },
              { action: 'Payment received', details: '₹1,250 from patient ID: PT101', time: '2 hours ago', type: 'success' },
            ].map((activity, index) => (
              <div key={index} className="flex items-center gap-4 p-3 bg-muted/20 rounded-lg border border-border/50">
                <div className={`w-2 h-2 rounded-full ${
                  activity.type === 'success' ? 'bg-green-500' :
                  activity.type === 'info' ? 'bg-blue-500' :
                  activity.type === 'warning' ? 'bg-yellow-500' : 'bg-gray-500'
                }`}></div>
                <div className="flex-1">
                  <p className="font-medium text-foreground">{activity.action}</p>
                  <p className="text-sm text-muted-foreground">{activity.details}</p>
                </div>
                <span className="text-xs text-muted-foreground">{activity.time}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );

  const renderSettings = () => (
    <div className="space-y-8">
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-gray-600 via-blue-600 to-teal-600 p-8 text-white shadow-medical-lg">
        <div className="absolute inset-0 opacity-20" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.1'%3E%3Cpath d='M30 15c8.284 0 15 6.716 15 15s-6.716 15-15 15-15-6.716-15-15 6.716-15 15-15z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`
        }}></div>
        <div className="relative z-10">
          <h1 className="text-3xl md:text-4xl font-bold mb-2 flex items-center gap-3">
            <Settings className="h-8 w-8 text-gray-300" />
            Center Settings
          </h1>
          <p className="text-blue-100 text-lg">Configure your diagnostic center preferences</p>
        </div>
      </div>

      <div className="dashboard-grid">
        <Card className="medical-card hover-lift border-0 shadow-medical">
          <CardHeader>
            <CardTitle>Appearance</CardTitle>
            <CardDescription>Customize the interface</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                {isDarkMode ? <Moon className="h-5 w-5" /> : <Sun className="h-5 w-5" />}
                <div>
                  <p className="font-medium">Dark Mode</p>
                  <p className="text-sm text-muted-foreground">Toggle dark theme</p>
                </div>
              </div>
              <Button
                onClick={toggleDarkMode}
                variant="outline"
                size="sm"
                className="rounded-xl"
              >
                {isDarkMode ? 'Light' : 'Dark'}
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card className="medical-card hover-lift border-0 shadow-medical">
          <CardHeader>
            <CardTitle>Center Information</CardTitle>
            <CardDescription>Your center details and profile management</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <p className="text-sm text-muted-foreground">Center Name</p>
              <p className="font-medium">{user.centerName || 'Not specified'}</p>
            </div>
            <div className="space-y-2">
              <p className="text-sm text-muted-foreground">Admin Name</p>
              <p className="font-medium">{user.name}</p>
            </div>
            <div className="space-y-2">
              <p className="text-sm text-muted-foreground">Role</p>
              <Badge variant="outline" className="bg-teal-50 text-teal-700 border-teal-200">
                Diagnostic Center
              </Badge>
            </div>
            <div className="pt-4 space-y-3">
              <div className="flex flex-col sm:flex-row gap-3">
                <CenterProfileManagement 
                  center={{
                    id: user.id,
                    name: user.centerName || 'Diagnostic Center',
                    address: '123 Medical Street',
                    city: 'Mumbai',
                    state: 'Maharashtra',
                    pincode: '400001',
                    ownerName: user.name,
                    ownerPhone: user.phone || '',
                    ownerEmail: 'admin@center.com',
                    ownerAddress: '123 Owner Address',
                    ownerCity: 'Mumbai',
                    ownerState: 'Maharashtra',
                    subscriptionType: 'standard',
                    paymentType: 'online',
                    username: user.username,
                    password: '',
                    isActive: true,
                    createdDate: '2024-01-01'
                  }}
                  onProfileUpdate={(profile) => {
                    console.log('Profile updated:', profile);
                  }}
                />
                <PasswordChangeForm 
                  userRole="diagnostic_center" 
                  userId={user.id}
                  onPasswordChanged={() => {
                    console.log('Password changed successfully');
                  }}
                />
              </div>
              <div className="pt-2">
                <NewFeaturesDemo />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );

  const renderContent = () => {
    switch (currentView) {
      case 'dashboard':
        return renderDashboard();
      case 'patients':
        return <PatientManagement />;
      case 'tests':
        return <TestManagement centerId={user.id} />;
      case 'reports':
        return <ReportGeneration centerId={user.id} />;
      case 'bills':
        return <EnhancedBillManagement />;
      case 'support':
        return <SupportCenter userRole="diagnostic_center" centerId={user.id} />;
      case 'settings':
        return renderSettings();
      default:
        return renderDashboard();
    }
  };

  return (
    <div className="layout-container">
      {/* Sidebar */}
      <div className={`sidebar-container ${isCollapsed ? 'collapsed' : ''}`}>
        {/* Sidebar Toggle Button */}
        <button
          onClick={toggleSidebar}
          className="sidebar-toggle"
          aria-label={isCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}
        >
          <ChevronLeft />
        </button>

        <div className="sidebar-content">
          {/* Sidebar Header */}
          <div className="sidebar-header">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-gradient-to-br from-teal-600 to-blue-600 rounded-lg flex items-center justify-center shadow-lg flex-shrink-0">
                <Stethoscope className="h-4 w-4 text-white" />
              </div>
              {!isCollapsed && (
                <div className="min-w-0 flex-1">
                  <h2 className="font-bold text-sidebar-foreground truncate">
                    {user.centerName || 'Diagnostic Center'}
                  </h2>
                  <p className="text-xs text-sidebar-foreground/70 truncate">Medical Dashboard</p>
                </div>
              )}
            </div>
          </div>

          {/* Sidebar Navigation */}
          <div className="sidebar-body">
            <nav className="sidebar-nav">
              {sidebarItems.map((item) => {
                const Icon = item.icon;
                const isActive = currentView === item.view;
                
                return (
                  <button
                    key={item.id}
                    onClick={() => setCurrentView(item.view)}
                    className={`sidebar-nav-item group ${isActive ? 'active' : ''}`}
                  >
                    <Icon className="sidebar-nav-icon" />
                    <span className="sidebar-nav-text">{item.label}</span>
                    {isCollapsed && (
                      <div className="sidebar-tooltip">
                        {item.label}
                      </div>
                    )}
                  </button>
                );
              })}
              
              {/* Logout Button */}
              <button
                onClick={onLogout}
                className="sidebar-nav-item group mt-auto text-red-600 hover:bg-red-50 dark:hover:bg-red-950/50"
              >
                <LogOut className="sidebar-nav-icon" />
                <span className="sidebar-nav-text">Logout</span>
                {isCollapsed && (
                  <div className="sidebar-tooltip">
                    Logout
                  </div>
                )}
              </button>
            </nav>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="main-content-container">
        <div className="main-content-body">
          {renderContent()}
        </div>
      </div>
    </div>
  );
}