// PDF Generation utilities for proper PDF download functionality
export class PDFGenerator {
  static generatePDF(htmlContent: string, filename: string): void {
    try {
      // Create a new window for PDF generation
      const printWindow = window.open('', '_blank', 'width=800,height=600');
      
      if (!printWindow) {
        alert('Please allow popups for this site to download the PDF. Then try again.');
        return;
      }

      // Write the HTML content
      printWindow.document.write(htmlContent);
      printWindow.document.close();
      
      // Wait for content to load, then trigger print
      printWindow.onload = () => {
        setTimeout(() => {
          printWindow.print();
          
          // Close the window after a delay to allow printing to complete
          setTimeout(() => {
            printWindow.close();
          }, 1000);
        }, 500);
      };
      
      printWindow.focus();
      
    } catch (error) {
      console.error('Error generating PDF:', error);
      alert('Failed to generate PDF. Please try again.');
    }
  }

  static async downloadAsPDF(htmlContent: string, filename: string): Promise<void> {
    try {
      // For actual PDF download, we'll use the browser's print-to-PDF functionality
      // Create a blob with the HTML content
      const blob = new Blob([htmlContent], { type: 'text/html' });
      const url = URL.createObjectURL(blob);
      
      // Create a temporary link and trigger download
      const link = document.createElement('a');
      link.href = url;
      link.download = `${filename}.html`;
      link.style.display = 'none';
      
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      // Clean up the URL
      URL.revokeObjectURL(url);
      
      // Also open print dialog for immediate PDF save
      this.generatePDF(htmlContent, filename);
      
    } catch (error) {
      console.error('Error downloading PDF:', error);
      alert('Failed to download PDF. Please try again.');
    }
  }

  static createPrintableHTML(content: string, title: string): string {
    return `
      <!DOCTYPE html>
      <html>
        <head>
          <title>${title}</title>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <style>
            @media print {
              @page {
                margin: 0.5in;
                size: A4;
              }
              
              body {
                font-family: Arial, sans-serif;
                color: #000 !important;
                background: white !important;
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
                margin: 0;
                padding: 0;
                font-size: 12px;
                line-height: 1.4;
              }
              
              .no-print {
                display: none !important;
              }
              
              .page-break {
                page-break-before: always;
              }
              
              /* Ensure content fits on one page */
              .report-container {
                max-height: 100vh;
                overflow: hidden;
                transform: scale(0.95);
                transform-origin: top left;
              }
              
              /* Compact spacing for print */
              .header {
                padding: 15px !important;
              }
              
              .content {
                padding: 15px !important;
              }
              
              table {
                font-size: 11px !important;
              }
              
              .signature-section {
                margin-top: 15px !important;
              }
              
              .signature-box {
                padding: 10px !important;
                height: 40px !important;
              }
              
              .footer {
                padding: 8px !important;
                font-size: 9px !important;
              }
            }
            
            body {
              font-family: Arial, sans-serif;
              margin: 0;
              padding: 20px;
              background: white;
              color: #333;
              line-height: 1.5;
            }
            
            /* Responsive scaling for different screen sizes */
            @media screen and (max-width: 800px) {
              .report-container {
                transform: scale(0.9);
                transform-origin: top left;
              }
            }
          </style>
        </head>
        <body>
          ${content}
          <script>
            window.addEventListener('load', function() {
              setTimeout(function() {
                window.print();
              }, 500);
            });
          </script>
        </body>
      </html>
    `;
  }
}