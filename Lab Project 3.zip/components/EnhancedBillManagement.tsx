import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Badge } from './ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Textarea } from './ui/textarea';
import { Separator } from './ui/separator';
import { 
  IndianRupee, Search, Plus, Eye, Edit, Trash2, Printer, Download, 
  Calendar, User, CreditCard, FileText, Receipt, CheckCircle, Clock, 
  AlertCircle, DollarSign, Percent, Calculator, Send
} from 'lucide-react';
import { Bill, Patient } from '../App';

// Mock data
const mockPatients: Patient[] = [
  {
    id: '1',
    fullName: 'Rajesh Kumar',
    email: 'rajesh.kumar@email.com',
    phone: '9876543210',
    address: '123 MG Road',
    city: 'Mumbai',
    state: 'Maharashtra',
    pincode: '400001',
    whatsappNumber: '9876543210',
    passcode: '1234',
    centerId: '1',
    createdDate: '2024-06-01'
  },
  {
    id: '2',
    fullName: 'Priya Sharma',
    email: 'priya.sharma@email.com',
    phone: '9876543211',
    address: '456 Park Street',
    city: 'Delhi',
    state: 'Delhi',
    pincode: '110001',
    whatsappNumber: '9876543211',
    passcode: '5678',
    centerId: '1',
    createdDate: '2024-06-02'
  }
];

const mockBills: Bill[] = [
  {
    id: '1',
    patientId: '1',
    centerId: '1',
    invoiceNumber: 'INV-2024-001',
    amount: 2500,
    discount: 250,
    finalAmount: 2250,
    status: 'paid',
    paymentDate: '2024-06-16',
    createdDate: '2024-06-15',
    tests: ['Complete Blood Count (CBC)', 'Lipid Profile'],
    paymentMode: 'upi',
    transactionId: 'TXN123456789',
    tax: 225,
    totalTax: 225,
    dueDate: '2024-06-20'
  },
  {
    id: '2',
    patientId: '2',
    centerId: '1',
    invoiceNumber: 'INV-2024-002',
    amount: 1800,
    discount: 0,
    finalAmount: 1980,
    status: 'pending',
    createdDate: '2024-06-14',
    tests: ['Urine Routine & Microscopy', 'ECG'],
    tax: 180,
    totalTax: 180,
    dueDate: '2024-06-19'
  }
];

const testPrices = [
  { name: 'Complete Blood Count (CBC)', price: 500 },
  { name: 'Lipid Profile', price: 800 },
  { name: 'Liver Function Test', price: 600 },
  { name: 'Kidney Function Test', price: 700 },
  { name: 'Thyroid Profile', price: 900 },
  { name: 'Urine Routine & Microscopy', price: 300 },
  { name: 'ECG', price: 200 },
  { name: 'X-Ray Chest', price: 400 },
  { name: 'Ultrasound Abdomen', price: 1200 },
  { name: 'Blood Sugar Fasting', price: 150 }
];

export function EnhancedBillManagement() {
  const [bills, setBills] = useState<Bill[]>(mockBills);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [selectedBill, setSelectedBill] = useState<Bill | null>(null);
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false);
  
  // New Bill Form State
  const [newBill, setNewBill] = useState({
    patientId: '',
    tests: [] as { name: string; price: number }[],
    discount: 0,
    discountType: 'amount' as 'amount' | 'percentage',
    taxRate: 10,
    paymentMode: 'cash' as Bill['paymentMode'],
    notes: '',
    dueDate: ''
  });

  const filteredBills = bills.filter(bill => {
    const patient = mockPatients.find(p => p.id === bill.patientId);
    const matchesSearch = bill.invoiceNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         patient?.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         patient?.phone.includes(searchTerm);
    const matchesStatus = statusFilter === 'all' || bill.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const calculateBillTotal = () => {
    const subtotal = newBill.tests.reduce((sum, test) => sum + test.price, 0);
    let discountAmount = 0;
    
    if (newBill.discountType === 'percentage') {
      discountAmount = (subtotal * newBill.discount) / 100;
    } else {
      discountAmount = newBill.discount;
    }
    
    const afterDiscount = subtotal - discountAmount;
    const taxAmount = (afterDiscount * newBill.taxRate) / 100;
    const total = afterDiscount + taxAmount;
    
    return {
      subtotal,
      discountAmount,
      taxAmount,
      total
    };
  };

  const addTest = (testName: string) => {
    const test = testPrices.find(t => t.name === testName);
    if (test && !newBill.tests.find(t => t.name === testName)) {
      setNewBill({
        ...newBill,
        tests: [...newBill.tests, test]
      });
    }
  };

  const removeTest = (testName: string) => {
    setNewBill({
      ...newBill,
      tests: newBill.tests.filter(t => t.name !== testName)
    });
  };

  const handleCreateBill = () => {
    const calculations = calculateBillTotal();
    const bill: Bill = {
      id: (bills.length + 1).toString(),
      patientId: newBill.patientId,
      centerId: '1',
      invoiceNumber: `INV-2024-${String(bills.length + 1).padStart(3, '0')}`,
      amount: calculations.subtotal,
      discount: calculations.discountAmount,
      finalAmount: calculations.total,
      status: 'pending',
      createdDate: new Date().toISOString().split('T')[0],
      tests: newBill.tests.map(t => t.name),
      paymentMode: newBill.paymentMode,
      tax: calculations.taxAmount,
      totalTax: calculations.taxAmount,
      dueDate: newBill.dueDate,
      paymentNotes: newBill.notes
    };

    setBills([...bills, bill]);
    setNewBill({
      patientId: '',
      tests: [],
      discount: 0,
      discountType: 'amount',
      taxRate: 10,
      paymentMode: 'cash',
      notes: '',
      dueDate: ''
    });
    setIsCreateDialogOpen(false);
  };

  const printBill = (bill: Bill) => {
    const patient = mockPatients.find(p => p.id === bill.patientId);
    
    // Center information - this should come from the center profile
    const centerInfo = {
      name: 'Apollo Diagnostics Mumbai',
      address: '123 MG Road, Fort',
      city: 'Mumbai',
      state: 'Maharashtra',
      pincode: '400001',
      phone: '+91-9876543210',
      email: 'info@apollodiagnostics.com',
      licenseNumber: 'MH/MUM/2024/001',
      gstNumber: '27AAAAA0000A1Z5'
    };
    
    const printContent = `
      <html>
        <head>
          <title>Invoice - ${bill.invoiceNumber}</title>
          <style>
            @media print {
              @page { margin: 0.5in; size: A4; }
              body { font-size: 12px !important; padding: 0 !important; }
              .invoice-container { border: none !important; box-shadow: none !important; transform: scale(0.95); }
              .header { padding: 15px !important; }
              .content { padding: 15px !important; }
              .table th, .table td { padding: 6px !important; font-size: 11px !important; }
              .total-section { padding: 12px !important; margin-top: 15px !important; }
              .footer { padding: 8px !important; font-size: 10px !important; }
            }
            body { font-family: Arial, sans-serif; margin: 0; padding: 20px; background: white; font-size: 13px; }
            .invoice-container { max-width: 800px; margin: 0 auto; background: white; border: 2px solid #2563eb; border-radius: 8px; overflow: hidden; }
            .header { background: linear-gradient(135deg, #2563eb, #1d4ed8); color: white; padding: 20px; text-align: center; }
            .center-name { font-size: 22px; font-weight: bold; margin-bottom: 6px; }
            .center-address { font-size: 12px; margin-top: 8px; line-height: 1.3; }
            .invoice-title { font-size: 18px; font-weight: bold; margin: 15px 0 8px 0; text-transform: uppercase; letter-spacing: 1px; }
            .content { padding: 20px; }
            .invoice-details { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px; }
            .section { background: #f8fafc; padding: 12px; border-radius: 6px; border-left: 3px solid #2563eb; }
            .section-title { font-weight: bold; color: #2563eb; margin-bottom: 8px; font-size: 14px; }
            .detail-row { margin-bottom: 6px; font-size: 12px; }
            .label { font-weight: bold; color: #374151; }
            .table { width: 100%; border-collapse: collapse; margin: 15px 0; font-size: 12px; }
            .table th, .table td { border: 1px solid #e2e8f0; padding: 8px; text-align: left; }
            .table th { background: #f1f5f9; font-weight: bold; color: #374151; }
            .table tbody tr:nth-child(even) { background: #f8fafc; }
            .total-section { background: #f8fafc; padding: 15px; border-radius: 6px; margin-top: 15px; }
            .total-row { display: flex; justify-content: space-between; margin-bottom: 6px; font-size: 13px; }
            .total-final { border-top: 2px solid #2563eb; padding-top: 8px; margin-top: 8px; font-size: 16px; font-weight: bold; color: #2563eb; }
            .footer { margin-top: 15px; padding-top: 15px; border-top: 1px solid #e2e8f0; text-align: center; color: #6b7280; font-size: 11px; }
          </style>
        </head>
        <body>
          <div class="invoice-container">
            <div class="header">
              <div class="center-name">${centerInfo.name}</div>
              <div class="center-address">
                📍 ${centerInfo.address}, ${centerInfo.city}, ${centerInfo.state} - ${centerInfo.pincode}<br>
                📞 ${centerInfo.phone} | ✉️ ${centerInfo.email}<br>
                License: ${centerInfo.licenseNumber} | GST: ${centerInfo.gstNumber}
              </div>
              <div class="invoice-title">Tax Invoice</div>
            </div>
            
            <div class="content">
              <div class="invoice-details">
                <div class="section">
                  <div class="section-title">Bill To:</div>
                  <div class="detail-row"><span class="label">Patient Name:</span> ${patient?.fullName}</div>
                  <div class="detail-row"><span class="label">Phone:</span> ${patient?.phone}</div>
                  <div class="detail-row"><span class="label">Address:</span> ${patient?.address}, ${patient?.city}</div>
                  <div class="detail-row"><span class="label">State:</span> ${patient?.state} - ${patient?.pincode}</div>
                </div>
                <div class="section">
                  <div class="section-title">Invoice Details:</div>
                  <div class="detail-row"><span class="label">Invoice Number:</span> ${bill.invoiceNumber}</div>
                  <div class="detail-row"><span class="label">Invoice Date:</span> ${new Date(bill.createdDate).toLocaleDateString('en-IN')}</div>
                  <div class="detail-row"><span class="label">Due Date:</span> ${bill.dueDate ? new Date(bill.dueDate).toLocaleDateString('en-IN') : 'Immediate'}</div>
                  <div class="detail-row"><span class="label">Payment Mode:</span> ${bill.paymentMode?.replace('_', ' ').toUpperCase() || 'Cash'}</div>
                  ${bill.transactionId ? `<div class="detail-row"><span class="label">Transaction ID:</span> ${bill.transactionId}</div>` : ''}
                </div>
              </div>
              
              <table class="table">
                <thead>
                  <tr>
                    <th style="width: 60%;">Test/Service Description</th>
                    <th style="width: 15%; text-align: center;">Qty</th>
                    <th style="width: 25%; text-align: right;">Amount (₹)</th>
                  </tr>
                </thead>
                <tbody>
                  ${bill.tests.map(test => `
                    <tr>
                      <td><strong>${test}</strong><br><small style="color: #6b7280;">Diagnostic Test</small></td>
                      <td style="text-align: center;">1</td>
                      <td style="text-align: right;">₹${testPrices.find(t => t.name === test)?.price || 0}</td>
                    </tr>
                  `).join('')}
                </tbody>
              </table>
              
              <div class="total-section">
                <div class="total-row">
                  <span>Subtotal:</span>
                  <span>₹${bill.amount}</span>
                </div>
                ${bill.discount > 0 ? `
                <div class="total-row" style="color: #059669;">
                  <span>Discount Applied:</span>
                  <span>-₹${bill.discount}</span>
                </div>
                ` : ''}
                <div class="total-row">
                  <span>Tax (GST):</span>
                  <span>₹${bill.tax || 0}</span>
                </div>
                <div class="total-row total-final">
                  <span>Total Amount:</span>
                  <span>₹${bill.finalAmount}</span>
                </div>
              </div>

              ${bill.paymentNotes ? `
              <div style="margin-top: 20px; padding: 15px; background: #f0f9ff; border-radius: 8px; border-left: 4px solid #0284c7;">
                <h4 style="color: #0284c7; margin-bottom: 8px;">Payment Notes</h4>
                <p style="margin: 0; color: #374151;">${bill.paymentNotes}</p>
              </div>
              ` : ''}
              
              <div class="footer">
                <p><strong>Thank you for choosing ${centerInfo.name}!</strong></p>
                <p>This is a computer generated invoice and does not require physical signature.</p>
                <p style="margin-top: 10px; font-size: 11px;">Generated on: ${new Date().toLocaleDateString('en-IN')} at ${new Date().toLocaleTimeString('en-IN')}</p>
              </div>
            </div>
          </div>
          <script>
            window.addEventListener('load', function() {
              setTimeout(function() {
                window.print();
              }, 500);
            });
          </script>
        </body>
      </html>
    `;
    
    const printWindow = window.open('', '', 'height=600,width=800');
    if (printWindow) {
      printWindow.document.write(printContent);
      printWindow.document.close();
      printWindow.print();
    }
  };

  const downloadBill = (bill: Bill) => {
    const patient = mockPatients.find(p => p.id === bill.patientId);
    
    // Center information - this should come from the center profile
    const centerInfo = {
      name: 'Apollo Diagnostics Mumbai',
      address: '123 MG Road, Fort',
      city: 'Mumbai',
      state: 'Maharashtra',
      pincode: '400001',
      phone: '+91-9876543210',
      email: 'info@apollodiagnostics.com',
      licenseNumber: 'MH/MUM/2024/001',
      gstNumber: '27AAAAA0000A1Z5',
      logo: '/placeholder-logo.png' // This should come from center profile
    };
    
    const logoSection = centerInfo.logo ? `
      <div style="text-align: center; margin-bottom: 20px;">
        <img src="${centerInfo.logo}" alt="${centerInfo.name} Logo" style="max-height: 80px; max-width: 200px; object-fit: contain;" />
      </div>
    ` : '';
    
    const htmlContent = `
      <!DOCTYPE html>
      <html>
        <head>
          <title>Invoice - ${bill.invoiceNumber}</title>
          <meta charset="UTF-8">
          <style>
            @media print {
              @page { margin: 0.5in; size: A4; }
              body { color: #000 !important; background: white !important; font-size: 12px !important; padding: 0 !important; }
              .invoice-container { border: none !important; transform: scale(0.95); transform-origin: top left; }
              .header { padding: 15px !important; }
              .content { padding: 15px !important; }
              .table th, .table td { padding: 6px !important; font-size: 11px !important; }
              .total-section { padding: 12px !important; margin-top: 15px !important; }
              .footer { padding: 8px !important; font-size: 10px !important; }
            }
            body { font-family: Arial, sans-serif; margin: 0; padding: 20px; background: white; font-size: 13px; }
            .invoice-container { max-width: 800px; margin: 0 auto; background: white; border: 2px solid #2563eb; border-radius: 8px; overflow: hidden; }
            .header { background: linear-gradient(135deg, #2563eb, #1d4ed8); color: white; padding: 20px; text-align: center; }
            .center-name { font-size: 22px; font-weight: bold; margin-bottom: 6px; }
            .center-address { font-size: 12px; margin-top: 8px; line-height: 1.3; }
            .invoice-title { font-size: 18px; font-weight: bold; margin: 15px 0 8px 0; text-transform: uppercase; letter-spacing: 1px; }
            .content { padding: 20px; }
            .invoice-details { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px; }
            .section { background: #f8fafc; padding: 12px; border-radius: 6px; border-left: 3px solid #2563eb; }
            .section-title { font-weight: bold; color: #2563eb; margin-bottom: 8px; font-size: 14px; }
            .detail-row { margin-bottom: 6px; font-size: 12px; }
            .label { font-weight: bold; color: #374151; }
            .table { width: 100%; border-collapse: collapse; margin: 15px 0; font-size: 12px; }
            .table th, .table td { border: 1px solid #e2e8f0; padding: 8px; text-align: left; }
            .table th { background: #f1f5f9; font-weight: bold; color: #374151; }
            .table tbody tr:nth-child(even) { background: #f8fafc; }
            .total-section { background: #f8fafc; padding: 15px; border-radius: 6px; margin-top: 15px; }
            .total-row { display: flex; justify-content: space-between; margin-bottom: 6px; font-size: 13px; }
            .total-final { border-top: 2px solid #2563eb; padding-top: 8px; margin-top: 8px; font-size: 16px; font-weight: bold; color: #2563eb; }
            .footer { margin-top: 15px; padding-top: 15px; border-top: 1px solid #e2e8f0; text-align: center; color: #6b7280; font-size: 11px; }
          </style>
        </head>
        <body>
          <div class="invoice-container">
            <div class="header">
              ${logoSection}
              <div class="center-name">${centerInfo.name}</div>
              <div class="center-address">
                📍 ${centerInfo.address}, ${centerInfo.city}, ${centerInfo.state} - ${centerInfo.pincode}<br>
                📞 ${centerInfo.phone} | ✉️ ${centerInfo.email}<br>
                License: ${centerInfo.licenseNumber} | GST: ${centerInfo.gstNumber}
              </div>
              <div class="invoice-title">Tax Invoice</div>
            </div>
            
            <div class="content">
              <div class="invoice-details">
                <div class="section">
                  <div class="section-title">Bill To:</div>
                  <div class="detail-row"><span class="label">Patient Name:</span> ${patient?.fullName}</div>
                  <div class="detail-row"><span class="label">Phone:</span> ${patient?.phone}</div>
                  <div class="detail-row"><span class="label">Address:</span> ${patient?.address}, ${patient?.city}</div>
                  <div class="detail-row"><span class="label">State:</span> ${patient?.state} - ${patient?.pincode}</div>
                </div>
                <div class="section">
                  <div class="section-title">Invoice Details:</div>
                  <div class="detail-row"><span class="label">Invoice Number:</span> ${bill.invoiceNumber}</div>
                  <div class="detail-row"><span class="label">Invoice Date:</span> ${new Date(bill.createdDate).toLocaleDateString('en-IN')}</div>
                  <div class="detail-row"><span class="label">Due Date:</span> ${bill.dueDate ? new Date(bill.dueDate).toLocaleDateString('en-IN') : 'Immediate'}</div>
                  <div class="detail-row"><span class="label">Payment Mode:</span> ${bill.paymentMode?.replace('_', ' ').toUpperCase() || 'Cash'}</div>
                  ${bill.transactionId ? `<div class="detail-row"><span class="label">Transaction ID:</span> ${bill.transactionId}</div>` : ''}
                </div>
              </div>
              
              <table class="table">
                <thead>
                  <tr>
                    <th style="width: 60%;">Test/Service Description</th>
                    <th style="width: 15%; text-align: center;">Qty</th>
                    <th style="width: 25%; text-align: right;">Amount (₹)</th>
                  </tr>
                </thead>
                <tbody>
                  ${bill.tests.map(test => `
                    <tr>
                      <td><strong>${test}</strong><br><small style="color: #6b7280;">Diagnostic Test</small></td>
                      <td style="text-align: center;">1</td>
                      <td style="text-align: right;">₹${testPrices.find(t => t.name === test)?.price || 0}</td>
                    </tr>
                  `).join('')}
                </tbody>
              </table>
              
              <div class="total-section">
                <div class="total-row">
                  <span>Subtotal:</span>
                  <span>₹${bill.amount}</span>
                </div>
                ${bill.discount > 0 ? `
                <div class="total-row" style="color: #059669;">
                  <span>Discount Applied:</span>
                  <span>-₹${bill.discount}</span>
                </div>
                ` : ''}
                <div class="total-row">
                  <span>Tax (GST):</span>
                  <span>₹${bill.tax || 0}</span>
                </div>
                <div class="total-row total-final">
                  <span>Total Amount:</span>
                  <span>₹${bill.finalAmount}</span>
                </div>
              </div>

              ${bill.paymentNotes ? `
              <div style="margin-top: 20px; padding: 15px; background: #f0f9ff; border-radius: 8px; border-left: 4px solid #0284c7;">
                <h4 style="color: #0284c7; margin-bottom: 8px;">Payment Notes</h4>
                <p style="margin: 0; color: #374151;">${bill.paymentNotes}</p>
              </div>
              ` : ''}
              
              <div class="footer">
                <p><strong>Thank you for choosing ${centerInfo.name}!</strong></p>
                <p>This is a computer generated invoice and does not require physical signature.</p>
                <p style="margin-top: 10px; font-size: 11px;">Generated on: ${new Date().toLocaleDateString('en-IN')} at ${new Date().toLocaleTimeString('en-IN')}</p>
              </div>
            </div>
          </div>
          <script>
            window.addEventListener('load', function() {
              setTimeout(function() {
                window.print();
              }, 500);
            });
          </script>
        </body>
      </html>
    `;
    
    // Create a blob and download as HTML file, then open print dialog
    const blob = new Blob([htmlContent], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `invoice_${bill.invoiceNumber}.html`;
    link.style.display = 'none';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    
    // Also open print dialog for PDF save
    const printWindow = window.open('', '', 'height=600,width=800');
    if (printWindow) {
      printWindow.document.write(htmlContent);
      printWindow.document.close();
      printWindow.print();
    }
  };

  const calculations = calculateBillTotal();

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-green-600 via-emerald-600 to-teal-600 p-8 text-white shadow-medical-lg">
        <div className="absolute inset-0 opacity-20" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.1'%3E%3Cpath d='M30 12c9.941 0 18 8.059 18 18s-8.059 18-18 18-18-8.059-18-18 8.059-18 18-18z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`
        }}></div>
        <div className="relative z-10">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl md:text-4xl font-bold mb-2 flex items-center gap-3">
                <IndianRupee className="h-8 w-8 text-green-300" />
                Bill Management
              </h1>
              <p className="text-blue-100 text-lg">Create, manage, and track patient billing and payments</p>
            </div>
            <div className="hidden lg:block">
              <div className="text-right">
                <p className="text-blue-100 text-sm">Total Bills</p>
                <div className="flex items-center gap-2 justify-end">
                  <Receipt className="h-4 w-4 text-green-300" />
                  <span className="text-green-300 font-medium text-2xl">{bills.length}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="flex flex-col sm:flex-row gap-4 items-center justify-between">
        <div className="flex flex-1 gap-4 max-w-2xl">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search bills..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 rounded-xl border-border/50 focus-enhanced"
            />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-40 rounded-xl border-border/50 focus-enhanced">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="paid">Paid</SelectItem>
              <SelectItem value="partially_paid">Partially Paid</SelectItem>
              <SelectItem value="cancelled">Cancelled</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Create New Bill Dialog */}
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button className="rounded-xl bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white border-0 focus-enhanced">
              <Plus className="h-4 w-4 mr-2" />
              Create Bill
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Plus className="h-5 w-5 text-green-600" />
                Create New Bill
              </DialogTitle>
              <DialogDescription>
                Generate a new bill for patient tests and services
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-6 py-4">
              {/* Patient Selection */}
              <div className="space-y-2">
                <Label htmlFor="patient">Select Patient</Label>
                <Select value={newBill.patientId} onValueChange={(value) => setNewBill({...newBill, patientId: value})}>
                  <SelectTrigger className="rounded-lg focus-enhanced">
                    <SelectValue placeholder="Choose a patient" />
                  </SelectTrigger>
                  <SelectContent>
                    {mockPatients.map(patient => (
                      <SelectItem key={patient.id} value={patient.id}>
                        {patient.fullName} - {patient.phone}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Test Selection */}
              <div className="space-y-4">
                <Label>Select Tests</Label>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                  {testPrices.map(test => (
                    <Button
                      key={test.name}
                      variant={newBill.tests.find(t => t.name === test.name) ? "default" : "outline"}
                      onClick={() => {
                        if (newBill.tests.find(t => t.name === test.name)) {
                          removeTest(test.name);
                        } else {
                          addTest(test.name);
                        }
                      }}
                      className="h-auto p-3 text-left rounded-lg"
                    >
                      <div className="w-full">
                        <p className="font-medium text-sm">{test.name}</p>
                        <p className="text-xs opacity-70">₹{test.price}</p>
                      </div>
                    </Button>
                  ))}
                </div>

                {/* Selected Tests */}
                {newBill.tests.length > 0 && (
                  <div className="space-y-2">
                    <Label>Selected Tests ({newBill.tests.length})</Label>
                    <div className="space-y-2 p-4 bg-muted/20 rounded-lg border border-border/50">
                      {newBill.tests.map(test => (
                        <div key={test.name} className="flex justify-between items-center">
                          <span className="text-sm">{test.name}</span>
                          <div className="flex items-center gap-2">
                            <span className="text-sm font-medium">₹{test.price}</span>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => removeTest(test.name)}
                              className="h-6 w-6 p-0 rounded-full"
                            >
                              ×
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Discount & Tax */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Discount</Label>
                  <div className="flex gap-2">
                    <Input
                      type="number"
                      value={newBill.discount}
                      onChange={(e) => setNewBill({...newBill, discount: Number(e.target.value)})}
                      className="rounded-lg"
                      placeholder="0"
                    />
                    <Select value={newBill.discountType} onValueChange={(value: 'amount' | 'percentage') => setNewBill({...newBill, discountType: value})}>
                      <SelectTrigger className="w-32 rounded-lg">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="amount">₹ Amount</SelectItem>
                        <SelectItem value="percentage">% Percent</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="taxRate">Tax Rate (%)</Label>
                  <Input
                    id="taxRate"
                    type="number"
                    value={newBill.taxRate}
                    onChange={(e) => setNewBill({...newBill, taxRate: Number(e.target.value)})}
                    className="rounded-lg"
                    placeholder="10"
                  />
                </div>
              </div>

              {/* Payment Details */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Payment Mode</Label>
                  <Select value={newBill.paymentMode} onValueChange={(value: Bill['paymentMode']) => setNewBill({...newBill, paymentMode: value})}>
                    <SelectTrigger className="rounded-lg">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="cash">Cash</SelectItem>
                      <SelectItem value="card">Credit/Debit Card</SelectItem>
                      <SelectItem value="upi">UPI</SelectItem>
                      <SelectItem value="net_banking">Net Banking</SelectItem>
                      <SelectItem value="cheque">Cheque</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="dueDate">Due Date</Label>
                  <Input
                    id="dueDate"
                    type="date"
                    value={newBill.dueDate}
                    onChange={(e) => setNewBill({...newBill, dueDate: e.target.value})}
                    className="rounded-lg"
                  />
                </div>
              </div>

              {/* Notes */}
              <div className="space-y-2">
                <Label htmlFor="notes">Notes (Optional)</Label>
                <Textarea
                  id="notes"
                  value={newBill.notes}
                  onChange={(e) => setNewBill({...newBill, notes: e.target.value})}
                  className="rounded-lg"
                  placeholder="Additional notes or instructions"
                />
              </div>

              {/* Bill Summary */}
              {newBill.tests.length > 0 && (
                <Card className="medical-card border-0 shadow-medical">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Calculator className="h-5 w-5 text-green-600" />
                      Bill Summary
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span>Subtotal:</span>
                        <span>₹{calculations.subtotal}</span>
                      </div>
                      <div className="flex justify-between text-green-600">
                        <span>Discount ({newBill.discountType === 'percentage' ? `${newBill.discount}%` : '₹' + newBill.discount}):</span>
                        <span>-₹{calculations.discountAmount}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Tax ({newBill.taxRate}%):</span>
                        <span>₹{calculations.taxAmount}</span>
                      </div>
                      <Separator />
                      <div className="flex justify-between text-lg font-bold">
                        <span>Total:</span>
                        <span>₹{calculations.total}</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>

            <div className="flex justify-end gap-3">
              <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                Cancel
              </Button>
              <Button
                onClick={handleCreateBill}
                disabled={!newBill.patientId || newBill.tests.length === 0}
                className="bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white border-0"
              >
                Create Bill
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Bills List */}
      <div className="space-y-4">
        {filteredBills.map((bill) => {
          const patient = mockPatients.find(p => p.id === bill.patientId);
          return (
            <Card key={bill.id} className="medical-card hover-lift border-0 shadow-medical">
              <CardContent className="p-6">
                <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
                  <div className="space-y-3">
                    <div className="flex flex-col sm:flex-row sm:items-center gap-3">
                      <h3 className="text-xl font-semibold text-foreground">{bill.invoiceNumber}</h3>
                      <div className="flex gap-2">
                        <Badge 
                          variant="outline" 
                          className={`${
                            bill.status === 'paid' 
                              ? 'bg-green-50 text-green-700 border-green-200 dark:bg-green-900 dark:text-green-100' 
                              : bill.status === 'pending'
                              ? 'bg-yellow-50 text-yellow-700 border-yellow-200 dark:bg-yellow-900 dark:text-yellow-100'
                              : bill.status === 'partially_paid'
                              ? 'bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-900 dark:text-blue-100'
                              : 'bg-red-50 text-red-700 border-red-200 dark:bg-red-900 dark:text-red-100'
                          }`}
                        >
                          {bill.status === 'paid' ? (
                            <CheckCircle className="h-3 w-3 mr-1" />
                          ) : bill.status === 'pending' ? (
                            <Clock className="h-3 w-3 mr-1" />
                          ) : bill.status === 'partially_paid' ? (
                            <DollarSign className="h-3 w-3 mr-1" />
                          ) : (
                            <AlertCircle className="h-3 w-3 mr-1" />
                          )}
                          {bill.status.replace('_', ' ').toUpperCase()}
                        </Badge>
                        {bill.paymentMode && (
                          <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-900 dark:text-blue-100">
                            <CreditCard className="h-3 w-3 mr-1" />
                            {bill.paymentMode.replace('_', ' ').toUpperCase()}
                          </Badge>
                        )}
                      </div>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3 text-sm text-muted-foreground">
                      <div className="flex items-center gap-2">
                        <User className="h-4 w-4 text-blue-600" />
                        <span className="font-medium text-foreground">Patient:</span> {patient?.fullName}
                      </div>
                      <div className="flex items-center gap-2">
                        <Calendar className="h-4 w-4 text-orange-600" />
                        <span className="font-medium text-foreground">Date:</span> {new Date(bill.createdDate).toLocaleDateString('en-IN')}
                      </div>
                      <div className="flex items-center gap-2">
                        <IndianRupee className="h-4 w-4 text-green-600" />
                        <span className="font-medium text-foreground">Amount:</span> ₹{bill.finalAmount}
                      </div>
                      <div className="flex items-center gap-2">
                        <FileText className="h-4 w-4 text-purple-600" />
                        <span className="font-medium text-foreground">Tests:</span> {bill.tests.length}
                      </div>
                    </div>
                  </div>
                  <div className="flex flex-col sm:flex-row gap-3">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => printBill(bill)}
                      className="rounded-xl border-border/50 hover:bg-blue-50 hover:border-blue-200 dark:hover:bg-blue-950/50 focus-enhanced"
                    >
                      <Printer className="h-4 w-4 mr-2" />
                      Print
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => downloadBill(bill)}
                      className="rounded-xl border-border/50 hover:bg-green-50 hover:border-green-200 dark:hover:bg-green-950/50 focus-enhanced"
                    >
                      <Download className="h-4 w-4 mr-2" />
                      Download
                    </Button>
                    <Dialog open={isViewDialogOpen && selectedBill?.id === bill.id} onOpenChange={(open) => {
                      setIsViewDialogOpen(open);
                      if (!open) setSelectedBill(null);
                    }}>
                      <DialogTrigger asChild>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setSelectedBill(bill)}
                          className="rounded-xl border-border/50 hover:bg-purple-50 hover:border-purple-200 dark:hover:bg-purple-950/50 focus-enhanced"
                        >
                          <Eye className="h-4 w-4 mr-2" />
                          View
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="max-w-2xl">
                        <DialogHeader>
                          <DialogTitle className="flex items-center gap-2">
                            <Receipt className="h-5 w-5 text-green-600" />
                            Bill Details
                          </DialogTitle>
                          <DialogDescription>
                            Complete bill information and payment details
                          </DialogDescription>
                        </DialogHeader>
                        {selectedBill && (
                          <div className="space-y-4">
                            <div className="grid grid-cols-2 gap-4">
                              <div>
                                <Label className="text-sm font-medium">Invoice Number</Label>
                                <p className="text-foreground">{selectedBill.invoiceNumber}</p>
                              </div>
                              <div>
                                <Label className="text-sm font-medium">Patient</Label>
                                <p className="text-foreground">{patient?.fullName}</p>
                              </div>
                              <div>
                                <Label className="text-sm font-medium">Date</Label>
                                <p className="text-foreground">{new Date(selectedBill.createdDate).toLocaleDateString('en-IN')}</p>
                              </div>
                              <div>
                                <Label className="text-sm font-medium">Status</Label>
                                <Badge variant="outline" className="mt-1">
                                  {selectedBill.status.replace('_', ' ').toUpperCase()}
                                </Badge>
                              </div>
                            </div>
                            <Separator />
                            <div>
                              <Label className="text-sm font-medium">Tests</Label>
                              <div className="mt-2 space-y-1">
                                {selectedBill.tests.map((test, index) => (
                                  <p key={index} className="text-sm text-foreground">• {test}</p>
                                ))}
                              </div>
                            </div>
                            <Separator />
                            <div className="space-y-2">
                              <div className="flex justify-between">
                                <span>Subtotal:</span>
                                <span>₹{selectedBill.amount}</span>
                              </div>
                              <div className="flex justify-between text-green-600">
                                <span>Discount:</span>
                                <span>-₹{selectedBill.discount}</span>
                              </div>
                              <div className="flex justify-between">
                                <span>Tax:</span>
                                <span>₹{selectedBill.tax}</span>
                              </div>
                              <Separator />
                              <div className="flex justify-between text-lg font-bold">
                                <span>Total:</span>
                                <span>₹{selectedBill.finalAmount}</span>
                              </div>
                            </div>
                          </div>
                        )}
                      </DialogContent>
                    </Dialog>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {filteredBills.length === 0 && (
        <div className="text-center py-12">
          <div className="w-16 h-16 bg-gradient-to-br from-green-500 to-green-600 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg">
            <IndianRupee className="h-8 w-8 text-white" />
          </div>
          <p className="text-muted-foreground text-lg">No bills found matching your criteria.</p>
        </div>
      )}
    </div>
  );
}