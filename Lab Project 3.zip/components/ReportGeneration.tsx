import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Badge } from './ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Alert, AlertDescription } from './ui/alert';
import { Separator } from './ui/separator';
import { 
  FileText, Plus, Save, Trash2, Eye, Download, Search, Calendar, 
  TestTube, User, CheckCircle, Clock, AlertCircle, Beaker, Activity,
  Microscope, Zap, FileCheck, X
} from 'lucide-react';
import { TestReport, Patient, TestResult } from '../App';
import { PDFReportGenerator } from './PDFReportGenerator';

interface ReportGenerationProps {
  centerId: string;
}

// Common lab test templates with typical parameters
const labTestTemplates = [
  {
    name: 'Complete Blood Count (CBC)',
    category: 'Hematology',
    parameters: [
      { name: 'Hemoglobin', unit: 'g/dL', reference: '12.0-15.5' },
      { name: 'RBC Count', unit: 'million/μL', reference: '4.2-5.4' },
      { name: 'WBC Count', unit: 'thousand/μL', reference: '4.0-11.0' },
      { name: 'Platelet Count', unit: 'thousand/μL', reference: '150-450' },
      { name: 'Hematocrit', unit: '%', reference: '36-46' },
      { name: 'MCV', unit: 'fL', reference: '82-98' },
      { name: 'MCH', unit: 'pg', reference: '27-31' },
      { name: 'MCHC', unit: 'g/dL', reference: '32-36' }
    ]
  },
  {
    name: 'Lipid Profile',
    category: 'Biochemistry',
    parameters: [
      { name: 'Total Cholesterol', unit: 'mg/dL', reference: '<200' },
      { name: 'HDL Cholesterol', unit: 'mg/dL', reference: '>40' },
      { name: 'LDL Cholesterol', unit: 'mg/dL', reference: '<100' },
      { name: 'Triglycerides', unit: 'mg/dL', reference: '<150' },
      { name: 'VLDL Cholesterol', unit: 'mg/dL', reference: '5-40' }
    ]
  },
  {
    name: 'Liver Function Test',
    category: 'Biochemistry',
    parameters: [
      { name: 'Total Bilirubin', unit: 'mg/dL', reference: '0.3-1.2' },
      { name: 'Direct Bilirubin', unit: 'mg/dL', reference: '0.0-0.3' },
      { name: 'SGPT/ALT', unit: 'U/L', reference: '7-56' },
      { name: 'SGOT/AST', unit: 'U/L', reference: '10-40' },
      { name: 'Alkaline Phosphatase', unit: 'U/L', reference: '44-147' },
      { name: 'Total Protein', unit: 'g/dL', reference: '6.0-8.3' },
      { name: 'Albumin', unit: 'g/dL', reference: '3.5-5.0' }
    ]
  },
  {
    name: 'Kidney Function Test',
    category: 'Biochemistry',
    parameters: [
      { name: 'Urea', unit: 'mg/dL', reference: '13-45' },
      { name: 'Creatinine', unit: 'mg/dL', reference: '0.6-1.4' },
      { name: 'Uric Acid', unit: 'mg/dL', reference: '3.4-7.0' },
      { name: 'BUN', unit: 'mg/dL', reference: '6-24' }
    ]
  },
  {
    name: 'Thyroid Profile',
    category: 'Hormones',
    parameters: [
      { name: 'TSH', unit: 'μIU/mL', reference: '0.27-4.20' },
      { name: 'T3', unit: 'ng/dL', reference: '80-200' },
      { name: 'T4', unit: 'μg/dL', reference: '5.1-14.1' },
      { name: 'Free T3', unit: 'pg/mL', reference: '2.0-4.4' },
      { name: 'Free T4', unit: 'ng/dL', reference: '0.93-1.70' }
    ]
  },
  {
    name: 'Blood Sugar Profile',
    category: 'Biochemistry',
    parameters: [
      { name: 'Fasting Blood Sugar', unit: 'mg/dL', reference: '70-100' },
      { name: 'Post Prandial (PP)', unit: 'mg/dL', reference: '<140' },
      { name: 'HbA1c', unit: '%', reference: '<5.7' }
    ]
  },
  {
    name: 'Urine Routine & Microscopy',
    category: 'Urine Analysis',
    parameters: [
      { name: 'Colour', unit: '', reference: 'Pale Yellow' },
      { name: 'Appearance', unit: '', reference: 'Clear' },
      { name: 'Specific Gravity', unit: '', reference: '1.003-1.030' },
      { name: 'pH', unit: '', reference: '5.0-8.0' },
      { name: 'Protein', unit: '', reference: 'Negative' },
      { name: 'Glucose', unit: '', reference: 'Negative' },
      { name: 'Ketones', unit: '', reference: 'Negative' },
      { name: 'Blood', unit: '', reference: 'Negative' },
      { name: 'Pus Cells', unit: '/hpf', reference: '0-5' },
      { name: 'RBCs', unit: '/hpf', reference: '0-2' },
      { name: 'Epithelial Cells', unit: '/hpf', reference: 'Few' }
    ]
  }
];

// Mock data
const mockPatients: Patient[] = [
  {
    id: '1',
    fullName: 'Rajesh Kumar',
    email: 'rajesh.kumar@email.com',
    phone: '9876543210',
    address: '123 MG Road',
    city: 'Mumbai',
    state: 'Maharashtra',
    pincode: '400001',
    whatsappNumber: '9876543210',
    passcode: '1234',
    centerId: '1',
    createdDate: '2024-06-01',
    dateOfBirth: '1985-03-15',
    gender: 'male'
  },
  {
    id: '2',
    fullName: 'Priya Sharma',
    email: 'priya.sharma@email.com',
    phone: '9876543211',
    address: '456 Park Street',
    city: 'Delhi',
    state: 'Delhi',
    pincode: '110001',
    whatsappNumber: '9876543211',
    passcode: '5678',
    centerId: '1',
    createdDate: '2024-06-02',
    dateOfBirth: '1990-07-22',
    gender: 'female'
  }
];

const mockReports: TestReport[] = [
  {
    id: '1',
    patientId: '1',
    centerId: '1',
    testType: 'Blood Test',
    testName: 'Complete Blood Count (CBC)',
    referredBy: 'Dr. Smith',
    sampleDate: '2024-06-15',
    reportDate: '2024-06-16',
    passcodeId: 'RPT001',
    status: 'completed',
    results: [
      { parameter: 'Hemoglobin', value: '14.2', unit: 'g/dL', reference: '12.0-15.5', status: 'normal' },
      { parameter: 'RBC Count', value: '4.8', unit: 'million/μL', reference: '4.2-5.4', status: 'normal' }
    ]
  }
];

export function ReportGeneration({ centerId }: ReportGenerationProps) {
  const [reports, setReports] = useState<TestReport[]>(mockReports);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [selectedTemplate, setSelectedTemplate] = useState<string>('');
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // New Report Form State
  const [newReport, setNewReport] = useState({
    patientId: '',
    testName: '',
    testType: '',
    referredBy: '',
    sampleDate: '',
    reportDate: '',
    notes: '',
    technician: '',
    verifiedBy: '',
    priority: 'normal' as 'normal' | 'urgent' | 'stat',
    results: [] as TestResult[]
  });

  const filteredReports = reports.filter(report => {
    const patient = mockPatients.find(p => p.id === report.patientId);
    const matchesSearch = report.testName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         report.passcodeId.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         patient?.fullName.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || report.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const handleTemplateSelect = (templateName: string) => {
    const template = labTestTemplates.find(t => t.name === templateName);
    if (template) {
      setNewReport({
        ...newReport,
        testName: template.name,
        testType: template.category,
        results: template.parameters.map(param => ({
          parameter: param.name,
          value: '',
          unit: param.unit,
          reference: param.reference,
          status: 'normal'
        }))
      });
      setSelectedTemplate(templateName);
    }
  };

  const updateResultValue = (parameterIndex: number, field: keyof TestResult, value: string) => {
    const updatedResults = [...newReport.results];
    updatedResults[parameterIndex] = {
      ...updatedResults[parameterIndex],
      [field]: value
    };
    setNewReport({ ...newReport, results: updatedResults });
  };

  const addCustomParameter = () => {
    setNewReport({
      ...newReport,
      results: [
        ...newReport.results,
        { parameter: '', value: '', unit: '', reference: '', status: 'normal' }
      ]
    });
  };

  const removeParameter = (index: number) => {
    const updatedResults = newReport.results.filter((_, i) => i !== index);
    setNewReport({ ...newReport, results: updatedResults });
  };

  const handleCreateReport = () => {
    const report: TestReport = {
      id: (reports.length + 1).toString(),
      patientId: newReport.patientId,
      centerId,
      testType: newReport.testType,
      testName: newReport.testName,
      referredBy: newReport.referredBy,
      sampleDate: newReport.sampleDate,
      reportDate: newReport.reportDate,
      passcodeId: `RPT${String(reports.length + 1).padStart(3, '0')}`,
      status: newReport.reportDate ? 'completed' : 'pending',
      results: newReport.results.filter(r => r.parameter && r.value),
      notes: newReport.notes,
      technician: newReport.technician,
      verifiedBy: newReport.verifiedBy,
      priority: newReport.priority
    };

    setReports([...reports, report]);
    setMessage({ type: 'success', text: 'Lab report created successfully!' });
    
    // Reset form
    setNewReport({
      patientId: '',
      testName: '',
      testType: '',
      referredBy: '',
      sampleDate: '',
      reportDate: '',
      notes: '',
      technician: '',
      verifiedBy: '',
      priority: 'normal',
      results: []
    });
    setSelectedTemplate('');
    setIsCreateDialogOpen(false);

    setTimeout(() => setMessage(null), 3000);
  };

  const mockCenter = {
    id: centerId,
    name: 'Apollo Diagnostics Mumbai',
    address: '123 MG Road, Fort',
    city: 'Mumbai',
    state: 'Maharashtra',
    pincode: '400001',
    ownerPhone: '+91-9876543210',
    ownerEmail: 'info@apollodiagnostics.com'
  };

  const mockCenterProfile = {
    logo: '/placeholder-logo.png',
    tagline: 'Your Health, Our Priority',
    licenseNumber: 'MH/MUM/2024/001',
    website: 'https://apollodiagnostics.com'
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-purple-600 via-indigo-600 to-blue-600 p-8 text-white shadow-medical-lg">
        <div className="absolute inset-0 opacity-20" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.1'%3E%3Cpath d='M30 10c11.046 0 20 8.954 20 20s-8.954 20-20 20-20-8.954-20-20 8.954-20 20-20z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`
        }}></div>
        <div className="relative z-10">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl md:text-4xl font-bold mb-2 flex items-center gap-3">
                <FileText className="h-8 w-8 text-purple-300" />
                Lab Report Generation
              </h1>
              <p className="text-blue-100 text-lg">Create and manage patient lab reports with ease</p>
            </div>
            <div className="hidden lg:block">
              <div className="text-right">
                <p className="text-blue-100 text-sm">Total Reports</p>
                <div className="flex items-center gap-2 justify-end">
                  <FileCheck className="h-4 w-4 text-purple-300" />
                  <span className="text-purple-300 font-medium text-2xl">{reports.length}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {message && (
        <Alert className={message.type === 'success' ? 'border-green-200 bg-green-50 dark:bg-green-950/50' : 'border-red-200 bg-red-50 dark:bg-red-950/50'}>
          {message.type === 'success' ? (
            <CheckCircle className="h-4 w-4 text-green-600" />
          ) : (
            <AlertCircle className="h-4 w-4 text-red-600" />
          )}
          <AlertDescription className={message.type === 'success' ? 'text-green-800 dark:text-green-200' : 'text-red-800 dark:text-red-200'}>
            {message.text}
          </AlertDescription>
        </Alert>
      )}

      {/* Search and Filters */}
      <div className="flex flex-col sm:flex-row gap-4 items-center justify-between">
        <div className="flex flex-1 gap-4 max-w-2xl">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search reports by test name, report ID, or patient name..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 rounded-xl border-border/50 focus-enhanced"
            />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-40 rounded-xl border-border/50 focus-enhanced">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="completed">Completed</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Create New Report Dialog */}
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button className="rounded-xl bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700 text-white border-0 focus-enhanced">
              <Plus className="h-4 w-4 mr-2" />
              Create New Report
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Plus className="h-5 w-5 text-purple-600" />
                Create New Lab Report
              </DialogTitle>
              <DialogDescription>
                Generate a new lab report using predefined templates or create custom tests
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-6 py-4">
              {/* Basic Information */}
              <Card className="medical-card border-0 shadow-medical">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <User className="h-5 w-5 text-blue-600" />
                    Basic Information
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="patient">Select Patient</Label>
                      <Select value={newReport.patientId} onValueChange={(value) => setNewReport({...newReport, patientId: value})}>
                        <SelectTrigger className="rounded-lg focus-enhanced">
                          <SelectValue placeholder="Choose a patient" />
                        </SelectTrigger>
                        <SelectContent>
                          {mockPatients.map(patient => (
                            <SelectItem key={patient.id} value={patient.id}>
                              {patient.fullName} - {patient.phone}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="referredBy">Referred By</Label>
                      <Input
                        id="referredBy"
                        value={newReport.referredBy}
                        onChange={(e) => setNewReport({...newReport, referredBy: e.target.value})}
                        className="rounded-lg"
                        placeholder="Dr. Name or Self"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="sampleDate">Sample Collection Date</Label>
                      <Input
                        id="sampleDate"
                        type="date"
                        value={newReport.sampleDate}
                        onChange={(e) => setNewReport({...newReport, sampleDate: e.target.value})}
                        className="rounded-lg"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="reportDate">Report Date (Optional)</Label>
                      <Input
                        id="reportDate"
                        type="date"
                        value={newReport.reportDate}
                        onChange={(e) => setNewReport({...newReport, reportDate: e.target.value})}
                        className="rounded-lg"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="technician">Lab Technician</Label>
                      <Input
                        id="technician"
                        value={newReport.technician}
                        onChange={(e) => setNewReport({...newReport, technician: e.target.value})}
                        className="rounded-lg"
                        placeholder="Technician name"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="verifiedBy">Verified By</Label>
                      <Input
                        id="verifiedBy"
                        value={newReport.verifiedBy}
                        onChange={(e) => setNewReport({...newReport, verifiedBy: e.target.value})}
                        className="rounded-lg"
                        placeholder="Doctor/Pathologist name"
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Test Selection */}
              <Card className="medical-card border-0 shadow-medical">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TestTube className="h-5 w-5 text-green-600" />
                    Select Lab Test
                  </CardTitle>
                  <CardDescription>Choose from common lab test templates or create custom tests</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
                    {labTestTemplates.map(template => (
                      <Button
                        key={template.name}
                        variant={selectedTemplate === template.name ? "default" : "outline"}
                        onClick={() => handleTemplateSelect(template.name)}
                        className="h-auto p-4 text-left rounded-xl"
                      >
                        <div className="w-full">
                          <div className="flex items-center gap-2 mb-1">
                            <Beaker className="h-4 w-4" />
                            <span className="font-medium text-sm">{template.name}</span>
                          </div>
                          <div className="text-xs opacity-70">{template.category}</div>
                          <div className="text-xs opacity-60 mt-1">{template.parameters.length} parameters</div>
                        </div>
                      </Button>
                    ))}
                  </div>

                  {/* Custom Test Option */}
                  <div className="pt-4 border-t">
                    <Button
                      variant="outline"
                      onClick={() => {
                        setSelectedTemplate('custom');
                        setNewReport({
                          ...newReport,
                          testName: '',
                          testType: '',
                          results: []
                        });
                      }}
                      className="w-full h-16 rounded-xl border-dashed border-2"
                    >
                      <div className="flex flex-col items-center gap-2">
                        <Plus className="h-5 w-5" />
                        <span>Create Custom Test</span>
                      </div>
                    </Button>
                  </div>

                  {/* Custom Test Fields */}
                  {selectedTemplate === 'custom' && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 bg-muted/20 rounded-lg border">
                      <div className="space-y-2">
                        <Label htmlFor="customTestName">Test Name</Label>
                        <Input
                          id="customTestName"
                          value={newReport.testName}
                          onChange={(e) => setNewReport({...newReport, testName: e.target.value})}
                          className="rounded-lg"
                          placeholder="Enter test name"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="customTestType">Test Category</Label>
                        <Input
                          id="customTestType"
                          value={newReport.testType}
                          onChange={(e) => setNewReport({...newReport, testType: e.target.value})}
                          className="rounded-lg"
                          placeholder="e.g., Biochemistry, Hematology"
                        />
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Test Parameters */}
              {(selectedTemplate && newReport.results.length > 0) && (
                <Card className="medical-card border-0 shadow-medical">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Activity className="h-5 w-5 text-orange-600" />
                      Enter Test Results
                    </CardTitle>
                    <CardDescription>Fill in the test values and reference ranges</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-3">
                      {newReport.results.map((result, index) => (
                        <div key={index} className="grid grid-cols-12 gap-3 items-end p-3 bg-muted/10 rounded-lg border">
                          <div className="col-span-12 md:col-span-3">
                            <Label className="text-sm">Parameter</Label>
                            <Input
                              value={result.parameter}
                              onChange={(e) => updateResultValue(index, 'parameter', e.target.value)}
                              className="rounded-lg text-sm"
                              placeholder="Parameter name"
                            />
                          </div>
                          <div className="col-span-6 md:col-span-2">
                            <Label className="text-sm">Result</Label>
                            <Input
                              value={result.value}
                              onChange={(e) => updateResultValue(index, 'value', e.target.value)}
                              className="rounded-lg text-sm"
                              placeholder="Value"
                            />
                          </div>
                          <div className="col-span-6 md:col-span-2">
                            <Label className="text-sm">Unit</Label>
                            <Input
                              value={result.unit}
                              onChange={(e) => updateResultValue(index, 'unit', e.target.value)}
                              className="rounded-lg text-sm"
                              placeholder="Unit"
                            />
                          </div>
                          <div className="col-span-8 md:col-span-3">
                            <Label className="text-sm">Reference Range</Label>
                            <Input
                              value={result.reference}
                              onChange={(e) => updateResultValue(index, 'reference', e.target.value)}
                              className="rounded-lg text-sm"
                              placeholder="Normal range"
                            />
                          </div>
                          <div className="col-span-3 md:col-span-1">
                            <Label className="text-sm">Status</Label>
                            <Select 
                              value={result.status || 'normal'} 
                              onValueChange={(value: 'normal' | 'abnormal' | 'critical') => updateResultValue(index, 'status', value)}
                            >
                              <SelectTrigger className="rounded-lg text-sm">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="normal">Normal</SelectItem>
                                <SelectItem value="abnormal">Abnormal</SelectItem>
                                <SelectItem value="critical">Critical</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <div className="col-span-1">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => removeParameter(index)}
                              className="h-8 w-8 p-0 rounded-lg"
                            >
                              <X className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>

                    <Button
                      variant="outline"
                      onClick={addCustomParameter}
                      className="w-full rounded-lg border-dashed"
                    >
                      <Plus className="h-4 w-4 mr-2" />
                      Add Custom Parameter
                    </Button>
                  </CardContent>
                </Card>
              )}

              {/* Notes */}
              <div className="space-y-2">
                <Label htmlFor="notes">Clinical Notes (Optional)</Label>
                <Textarea
                  id="notes"
                  value={newReport.notes}
                  onChange={(e) => setNewReport({...newReport, notes: e.target.value})}
                  className="rounded-lg min-h-[100px]"
                  placeholder="Additional clinical observations, recommendations, or comments..."
                />
              </div>
            </div>

            <div className="flex justify-end gap-3 pt-4 border-t">
              <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                Cancel
              </Button>
              <Button
                onClick={handleCreateReport}
                disabled={!newReport.patientId || !newReport.testName || newReport.results.length === 0}
                className="bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700 text-white border-0"
              >
                <Save className="h-4 w-4 mr-2" />
                Create Report
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Reports List */}
      <div className="space-y-4">
        {filteredReports.map((report) => {
          const patient = mockPatients.find(p => p.id === report.patientId);
          const pdfGenerator = PDFReportGenerator({ report, patient: patient!, center: mockCenter, centerProfile: mockCenterProfile });
          
          return (
            <Card key={report.id} className="medical-card hover-lift border-0 shadow-medical">
              <CardContent className="p-6">
                <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
                  <div className="space-y-3">
                    <div className="flex flex-col sm:flex-row sm:items-center gap-3">
                      <h3 className="text-xl font-semibold text-foreground">{report.testName}</h3>
                      <div className="flex gap-2">
                        <Badge 
                          variant="outline" 
                          className={`${
                            report.status === 'completed' 
                              ? 'bg-green-50 text-green-700 border-green-200 dark:bg-green-900 dark:text-green-100' 
                              : 'bg-yellow-50 text-yellow-700 border-yellow-200 dark:bg-yellow-900 dark:text-yellow-100'
                          }`}
                        >
                          {report.status === 'completed' ? (
                            <CheckCircle className="h-3 w-3 mr-1" />
                          ) : (
                            <Clock className="h-3 w-3 mr-1" />
                          )}
                          {report.status.toUpperCase()}
                        </Badge>
                        <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-900 dark:text-blue-100">
                          {report.passcodeId}
                        </Badge>
                      </div>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3 text-sm text-muted-foreground">
                      <div className="flex items-center gap-2">
                        <User className="h-4 w-4 text-blue-600" />
                        <span className="font-medium text-foreground">Patient:</span> {patient?.fullName}
                      </div>
                      <div className="flex items-center gap-2">
                        <Calendar className="h-4 w-4 text-orange-600" />
                        <span className="font-medium text-foreground">Sample Date:</span> {new Date(report.sampleDate).toLocaleDateString('en-IN')}
                      </div>
                      <div className="flex items-center gap-2">
                        <TestTube className="h-4 w-4 text-green-600" />
                        <span className="font-medium text-foreground">Type:</span> {report.testType}
                      </div>
                      <div className="flex items-center gap-2">
                        <Microscope className="h-4 w-4 text-purple-600" />
                        <span className="font-medium text-foreground">Referred By:</span> {report.referredBy}
                      </div>
                    </div>
                  </div>
                  <div className="flex flex-col sm:flex-row gap-3">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={pdfGenerator.viewReport}
                      className="rounded-xl border-border/50 hover:bg-blue-50 hover:border-blue-200 dark:hover:bg-blue-950/50 focus-enhanced"
                    >
                      <Eye className="h-4 w-4 mr-2" />
                      View
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={pdfGenerator.downloadPDF}
                      className="rounded-xl border-border/50 hover:bg-green-50 hover:border-green-200 dark:hover:bg-green-950/50 focus-enhanced"
                    >
                      <Download className="h-4 w-4 mr-2" />
                      Download PDF
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {filteredReports.length === 0 && (
        <div className="text-center py-12">
          <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-purple-600 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg">
            <FileText className="h-8 w-8 text-white" />
          </div>
          <p className="text-muted-foreground text-lg">No reports found matching your criteria.</p>
        </div>
      )}
    </div>
  );
}