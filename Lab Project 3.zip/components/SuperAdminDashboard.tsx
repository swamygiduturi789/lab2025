import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, LineChart, Line
} from 'recharts';
import { 
  LayoutDashboard, Building2, FileText, Package, 
  Settings, LogOut, Users, IndianRupee, TrendingUp, UserPlus, 
  Activity, Bell, Crown, Sparkles, ChevronLeft, Moon, Sun
} from 'lucide-react';
import { User } from '../App';
import { DiagnosticCentersList } from './DiagnosticCentersList';
import { BillsReportsList } from './BillsReportsList';
import { PackagesManagement } from './PackagesManagement';
import { SupportCenter } from './SupportCenter';
import { PasswordChangeForm } from './PasswordChangeForm';
import { NewFeaturesDemo } from './NewFeaturesDemo';
import { useSidebar } from '../contexts/SidebarContext';

interface SuperAdminDashboardProps {
  user: User;
  onLogout: () => void;
}

type DashboardView = 'dashboard' | 'centers' | 'bills' | 'packages' | 'support' | 'settings';

// Mock data for analytics
const monthlyData = [
  { month: 'Jan', revenue: 45000, centers: 12, patients: 850 },
  { month: 'Feb', revenue: 52000, centers: 15, patients: 1120 },
  { month: 'Mar', revenue: 48000, centers: 18, patients: 1350 },
  { month: 'Apr', revenue: 61000, centers: 22, patients: 1680 },
  { month: 'May', revenue: 55000, centers: 25, patients: 1920 },
  { month: 'Jun', revenue: 67000, centers: 28, patients: 2150 },
];

const subscriptionData = [
  { name: 'Gold', value: 8, color: '#f59e0b' },
  { name: 'Standard', value: 15, color: '#3b82f6' },
  { name: 'Free', value: 5, color: '#10b981' }
];

export function SuperAdminDashboard({ user, onLogout }: SuperAdminDashboardProps) {
  const [currentView, setCurrentView] = useState<DashboardView>('dashboard');
  const [isDarkMode, setIsDarkMode] = useState(false);
  const { isCollapsed, toggleSidebar, isMobile } = useSidebar();

  // Debug: Verify logout function is available
  React.useEffect(() => {
    if (process.env.NODE_ENV === 'development') {
      console.log('🔐 SuperAdminDashboard - onLogout function:', typeof onLogout);
    }
  }, [onLogout]);

  const toggleDarkMode = () => {
    setIsDarkMode(!isDarkMode);
    document.documentElement.classList.toggle('dark');
  };

  const sidebarItems = [
    {
      id: 'dashboard',
      label: 'Dashboard',
      icon: LayoutDashboard,
      view: 'dashboard' as DashboardView,
    },
    {
      id: 'centers',
      label: 'Diagnostic Centers',
      icon: Building2,
      view: 'centers' as DashboardView,
    },
    {
      id: 'bills',
      label: 'Bills & Reports',
      icon: FileText,
      view: 'bills' as DashboardView,
    },
    {
      id: 'packages',
      label: 'Packages',
      icon: Package,
      view: 'packages' as DashboardView,
    },
    {
      id: 'support',
      label: 'Support Center',
      icon: Bell,
      view: 'support' as DashboardView,
    },
    {
      id: 'settings',
      label: 'Settings',
      icon: Settings,
      view: 'settings' as DashboardView,
    }
  ];

  const renderDashboard = () => (
    <div className="space-y-8">
      {/* Welcome Header */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-blue-600 via-purple-600 to-teal-600 p-8 text-white shadow-medical-lg">
        <div className="absolute inset-0 opacity-20" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.1'%3E%3Cpath d='M30 30c0-11.046-8.954-20-20-20s-20 8.954-20 20 8.954 20 20 20 20-8.954 20-20z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`
        }}></div>
        <div className="relative z-10">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl md:text-4xl font-bold mb-2 flex items-center gap-3">
                <Crown className="h-8 w-8 text-yellow-300" />
                Welcome back, {user.name}!
              </h1>
              <p className="text-blue-100 text-lg">Super Admin Dashboard - Composcale.com</p>
            </div>
            <div className="hidden lg:block">
              <div className="text-right">
                <p className="text-blue-100 text-sm">System Status</p>
                <div className="flex items-center gap-2 justify-end">
                  <Sparkles className="h-4 w-4 text-green-300" />
                  <span className="text-green-300 font-medium">All Systems Online</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="stats-grid">
        <Card className="medical-card hover-lift border-0 shadow-medical">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground font-medium">Total Centers</p>
                <p className="text-3xl font-bold text-foreground">28</p>
                <p className="text-xs text-green-600 font-medium">+3 this month</p>
              </div>
              <div className="rounded-lg bg-gradient-to-br from-blue-500 to-blue-600 p-3 shadow-lg">
                <Building2 className="h-6 w-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="medical-card hover-lift border-0 shadow-medical">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground font-medium">Monthly Revenue</p>
                <p className="text-3xl font-bold text-foreground">₹67,000</p>
                <p className="text-xs text-green-600 font-medium">+12% vs last month</p>
              </div>
              <div className="rounded-lg bg-gradient-to-br from-green-500 to-green-600 p-3 shadow-lg">
                <IndianRupee className="h-6 w-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="medical-card hover-lift border-0 shadow-medical">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground font-medium">Total Patients</p>
                <p className="text-3xl font-bold text-foreground">2,150</p>
                <p className="text-xs text-green-600 font-medium">+230 this month</p>
              </div>
              <div className="rounded-lg bg-gradient-to-br from-purple-500 to-purple-600 p-3 shadow-lg">
                <Users className="h-6 w-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="medical-card hover-lift border-0 shadow-medical">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground font-medium">Growth Rate</p>
                <p className="text-3xl font-bold text-foreground">24%</p>
                <p className="text-xs text-green-600 font-medium">Year over year</p>
              </div>
              <div className="rounded-lg bg-gradient-to-br from-teal-500 to-teal-600 p-3 shadow-lg">
                <TrendingUp className="h-6 w-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts Section */}
      <div className="dashboard-grid">
        <Card className="medical-card hover-lift border-0 shadow-medical lg:col-span-2">
          <CardHeader className="pb-4">
            <CardTitle className="text-xl font-semibold flex items-center gap-2">
              <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
              Revenue & Growth Analytics
            </CardTitle>
            <CardDescription>Monthly revenue and center growth trends</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={monthlyData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                <XAxis dataKey="month" tick={{ fill: '#64748b', fontSize: 12 }} />
                <YAxis tick={{ fill: '#64748b', fontSize: 12 }} />
                <Tooltip 
                  formatter={(value, name) => [
                    name === 'revenue' ? `₹${value.toLocaleString('en-IN')}` : value,
                    name === 'revenue' ? 'Revenue' : name === 'centers' ? 'Centers' : 'Patients'
                  ]}
                  contentStyle={{
                    backgroundColor: '#ffffff',
                    border: '1px solid #e2e8f0',
                    borderRadius: '8px',
                    boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
                  }}
                />
                <Bar dataKey="revenue" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                <Bar dataKey="centers" fill="#10b981" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="medical-card hover-lift border-0 shadow-medical">
          <CardHeader className="pb-4">
            <CardTitle className="text-xl font-semibold flex items-center gap-2">
              <div className="w-2 h-2 bg-yellow-500 rounded-full"></div>
              Subscription Distribution
            </CardTitle>
            <CardDescription>Center subscription breakdown</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <PieChart>
                <Pie
                  data={subscriptionData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {subscriptionData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{
                    backgroundColor: '#ffffff',
                    border: '1px solid #e2e8f0',
                    borderRadius: '8px',
                    boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
            <div className="flex justify-center gap-4 mt-4">
              {subscriptionData.map((item) => (
                <div key={item.name} className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }}></div>
                  <span className="text-sm text-muted-foreground">{item.name}: {item.value}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Activity */}
      <Card className="medical-card hover-lift border-0 shadow-medical">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="h-5 w-5 text-blue-600" />
            Recent Activity
          </CardTitle>
          <CardDescription>Latest system activities and notifications</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[
              { action: 'New diagnostic center registered', details: 'Apollo Diagnostics Pune', time: '2 hours ago', type: 'success' },
              { action: 'Subscription upgraded', details: 'Care Labs Delhi upgraded to Gold plan', time: '4 hours ago', type: 'info' },
              { action: 'Payment received', details: '₹4,999 from Metro Labs Bangalore', time: '6 hours ago', type: 'success' },
              { action: 'Support ticket raised', details: 'Issue with PDF generation', time: '1 day ago', type: 'warning' },
            ].map((activity, index) => (
              <div key={index} className="flex items-center gap-4 p-3 bg-muted/20 rounded-lg border border-border/50">
                <div className={`w-2 h-2 rounded-full ${
                  activity.type === 'success' ? 'bg-green-500' :
                  activity.type === 'info' ? 'bg-blue-500' :
                  activity.type === 'warning' ? 'bg-yellow-500' : 'bg-gray-500'
                }`}></div>
                <div className="flex-1">
                  <p className="font-medium text-foreground">{activity.action}</p>
                  <p className="text-sm text-muted-foreground">{activity.details}</p>
                </div>
                <span className="text-xs text-muted-foreground">{activity.time}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );

  const renderSettings = () => (
    <div className="space-y-8">
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-gray-600 via-blue-600 to-purple-600 p-8 text-white shadow-medical-lg">
        <div className="absolute inset-0 opacity-20" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.1'%3E%3Cpath d='M30 15c8.284 0 15 6.716 15 15s-6.716 15-15 15-15-6.716-15-15 6.716-15 15-15z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`
        }}></div>
        <div className="relative z-10">
          <h1 className="text-3xl md:text-4xl font-bold mb-2 flex items-center gap-3">
            <Settings className="h-8 w-8 text-gray-300" />
            System Settings
          </h1>
          <p className="text-blue-100 text-lg">Configure system preferences and account settings</p>
        </div>
      </div>

      <div className="dashboard-grid">
        <Card className="medical-card hover-lift border-0 shadow-medical">
          <CardHeader>
            <CardTitle>Appearance</CardTitle>
            <CardDescription>Customize the look and feel</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                {isDarkMode ? <Moon className="h-5 w-5" /> : <Sun className="h-5 w-5" />}
                <div>
                  <p className="font-medium">Dark Mode</p>
                  <p className="text-sm text-muted-foreground">Toggle dark theme</p>
                </div>
              </div>
              <Button
                onClick={toggleDarkMode}
                variant="outline"
                size="sm"
                className="rounded-xl"
              >
                {isDarkMode ? 'Light' : 'Dark'}
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card className="medical-card hover-lift border-0 shadow-medical">
          <CardHeader>
            <CardTitle>Account Information</CardTitle>
            <CardDescription>Your account details and security settings</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <p className="text-sm text-muted-foreground">Name</p>
              <p className="font-medium">{user.name}</p>
            </div>
            <div className="space-y-2">
              <p className="text-sm text-muted-foreground">Role</p>
              <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                Super Admin
              </Badge>
            </div>
            <div className="space-y-2">
              <p className="text-sm text-muted-foreground">User ID</p>
              <p className="font-mono text-sm">{user.id}</p>
            </div>
            <div className="pt-4 space-y-3">
              <div className="flex flex-col sm:flex-row gap-3">
                <PasswordChangeForm 
                  userRole="super_admin" 
                  userId={user.id}
                  onPasswordChanged={() => {
                    // Handle password change success
                    console.log('Password changed successfully');
                  }}
                />
                <NewFeaturesDemo />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );

  const renderContent = () => {
    switch (currentView) {
      case 'dashboard':
        return renderDashboard();
      case 'centers':
        return <DiagnosticCentersList />;
      case 'bills':
        return <BillsReportsList />;
      case 'packages':
        return <PackagesManagement />;
      case 'support':
        return <SupportCenter userRole="super_admin" />;
      case 'settings':
        return renderSettings();
      default:
        return renderDashboard();
    }
  };

  return (
    <div className="layout-container">
      {/* Sidebar */}
      <div className={`sidebar-container ${isCollapsed ? 'collapsed' : ''}`}>
        {/* Sidebar Toggle Button */}
        <button
          onClick={toggleSidebar}
          className="sidebar-toggle"
          aria-label={isCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}
        >
          <ChevronLeft />
        </button>

        <div className="sidebar-content">
          {/* Sidebar Header */}
          <div className="sidebar-header">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-teal-600 rounded-lg flex items-center justify-center shadow-lg flex-shrink-0">
                <Crown className="h-4 w-4 text-white" />
              </div>
              {!isCollapsed && (
                <div className="min-w-0 flex-1">
                  <h2 className="font-bold text-sidebar-foreground truncate">Composcale.com</h2>
                  <p className="text-xs text-sidebar-foreground/70 truncate">Super Admin</p>
                </div>
              )}
            </div>
          </div>

          {/* Sidebar Navigation */}
          <div className="sidebar-body">
            <nav className="sidebar-nav">
              {sidebarItems.map((item) => {
                const Icon = item.icon;
                const isActive = currentView === item.view;
                
                return (
                  <button
                    key={item.id}
                    onClick={() => setCurrentView(item.view)}
                    className={`sidebar-nav-item group ${isActive ? 'active' : ''}`}
                  >
                    <Icon className="sidebar-nav-icon" />
                    <span className="sidebar-nav-text">{item.label}</span>
                    {isCollapsed && (
                      <div className="sidebar-tooltip">
                        {item.label}
                      </div>
                    )}
                  </button>
                );
              })}
              
              {/* Logout Button */}
              <button
                onClick={onLogout}
                className="sidebar-nav-item group mt-auto text-red-600 hover:bg-red-50 dark:hover:bg-red-950/50"
              >
                <LogOut className="sidebar-nav-icon" />
                <span className="sidebar-nav-text">Logout</span>
                {isCollapsed && (
                  <div className="sidebar-tooltip">
                    Logout
                  </div>
                )}
              </button>
            </nav>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="main-content-container">
        <div className="main-content-body">
          {renderContent()}
        </div>
      </div>
    </div>
  );
}