import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { 
  FileText, Search, Download, Eye, IndianRupee, 
  Calendar, Building2, TrendingUp, BarChart3, PieChart
} from 'lucide-react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart as RechartsPieChart, Pie, Cell, LineChart, Line
} from 'recharts';
import { Bill } from '../App';

const mockBills: Bill[] = [
  {
    id: '1',
    patientId: '1',
    centerId: '1',
    invoiceNumber: 'INV-2024-001',
    amount: 1500,
    discount: 150,
    finalAmount: 1350,
    status: 'paid',
    paymentDate: '2024-06-15',
    createdDate: '2024-06-15',
    tests: ['Complete Blood Count', 'Lipid Profile']
  },
  {
    id: '2',
    patientId: '2',
    centerId: '1',
    invoiceNumber: 'INV-2024-002',
    amount: 800,
    discount: 0,
    finalAmount: 800,
    status: 'paid',
    paymentDate: '2024-06-14',
    createdDate: '2024-06-14',
    tests: ['Urine Analysis']
  },
  {
    id: '3',
    patientId: '3',
    centerId: '2',
    invoiceNumber: 'INV-2024-003',
    amount: 2200,
    discount: 220,
    finalAmount: 1980,
    status: 'pending',
    createdDate: '2024-06-13',
    tests: ['Thyroid Function Test', 'Vitamin D']
  }
];

const mockCenters = [
  { id: '1', name: 'Apollo Diagnostics Mumbai' },
  { id: '2', name: 'Care Diagnostics Delhi' },
  { id: '3', name: 'Metropolis Labs Bangalore' }
];

const mockPatients = [
  { id: '1', name: 'Rajesh Kumar' },
  { id: '2', name: 'Priya Sharma' },
  { id: '3', name: 'Amit Patel' }
];

export function BillsReportsList() {
  const [bills] = useState<Bill[]>(mockBills);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [centerFilter, setCenterFilter] = useState<string>('all');

  const filteredBills = bills.filter(bill => {
    const center = mockCenters.find(c => c.id === bill.centerId);
    const patient = mockPatients.find(p => p.id === bill.patientId);
    
    const matchesSearch = bill.invoiceNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         center?.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         patient?.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || bill.status === statusFilter;
    const matchesCenter = centerFilter === 'all' || bill.centerId === centerFilter;
    
    return matchesSearch && matchesStatus && matchesCenter;
  });

  const getAnalytics = () => {
    const totalRevenue = filteredBills.reduce((sum, bill) => sum + bill.finalAmount, 0);
    const paidRevenue = filteredBills.filter(b => b.status === 'paid').reduce((sum, bill) => sum + bill.finalAmount, 0);
    const pendingRevenue = filteredBills.filter(b => b.status === 'pending').reduce((sum, bill) => sum + bill.finalAmount, 0);

    return {
      totalRevenue,
      paidRevenue,
      pendingRevenue,
      totalBills: filteredBills.length,
      paidBills: filteredBills.filter(b => b.status === 'paid').length,
      pendingBills: filteredBills.filter(b => b.status === 'pending').length
    };
  };

  const exportToCSV = () => {
    const headers = ['Invoice Number', 'Center', 'Patient', 'Amount', 'Status', 'Date'];
    const csvData = filteredBills.map(bill => {
      const center = mockCenters.find(c => c.id === bill.centerId);
      const patient = mockPatients.find(p => p.id === bill.patientId);
      return [
        bill.invoiceNumber,
        center?.name || '',
        patient?.name || '',
        bill.finalAmount,
        bill.status,
        bill.createdDate
      ];
    });

    const csvContent = [headers, ...csvData]
      .map(row => row.map(field => `"${field}"`).join(','))
      .join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `bills-report-${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
    window.URL.revokeObjectURL(url);
  };

  const analytics = getAnalytics();

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-green-600 via-blue-600 to-purple-600 p-8 text-white shadow-medical-lg">
        <div className="absolute inset-0 opacity-20" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.1'%3E%3Cpath d='M30 6c13.255 0 24 10.745 24 24S43.255 54 30 54 6 43.255 6 30 16.745 6 30 6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`
        }}></div>
        <div className="relative z-10">
          <h1 className="text-3xl md:text-4xl font-bold mb-2 flex items-center gap-3">
            <BarChart3 className="h-8 w-8 text-green-300" />
            Bills & Reports
          </h1>
          <p className="text-blue-100 text-lg">Comprehensive billing analytics and reports</p>
        </div>
      </div>

      {/* Analytics Cards */}
      <div className="stats-grid">
        <Card className="medical-card hover-lift border-0 shadow-medical">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground font-medium">Total Revenue</p>
                <p className="text-3xl font-bold text-foreground">₹{analytics.totalRevenue.toLocaleString('en-IN')}</p>
              </div>
              <div className="rounded-lg bg-gradient-to-br from-green-500 to-green-600 p-3 shadow-lg">
                <IndianRupee className="h-6 w-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="medical-card hover-lift border-0 shadow-medical">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground font-medium">Paid Revenue</p>
                <p className="text-3xl font-bold text-green-600">₹{analytics.paidRevenue.toLocaleString('en-IN')}</p>
              </div>
              <div className="rounded-lg bg-gradient-to-br from-blue-500 to-blue-600 p-3 shadow-lg">
                <TrendingUp className="h-6 w-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="medical-card hover-lift border-0 shadow-medical">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground font-medium">Total Bills</p>
                <p className="text-3xl font-bold text-foreground">{analytics.totalBills}</p>
              </div>
              <div className="rounded-lg bg-gradient-to-br from-purple-500 to-purple-600 p-3 shadow-lg">
                <FileText className="h-6 w-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Search and Filters */}
      <div className="flex flex-col sm:flex-row gap-4 items-center justify-between">
        <div className="flex flex-1 gap-4 max-w-3xl">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search bills..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 rounded-xl border-border/50 focus-enhanced"
            />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-32 rounded-xl border-border/50 focus-enhanced">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="paid">Paid</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <Button
          onClick={exportToCSV}
          className="rounded-xl bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white border-0 focus-enhanced"
        >
          <Download className="h-4 w-4 mr-2" />
          Export CSV
        </Button>
      </div>

      {/* Bills List */}
      <div className="space-y-4">
        {filteredBills.map((bill) => {
          const center = mockCenters.find(c => c.id === bill.centerId);
          const patient = mockPatients.find(p => p.id === bill.patientId);
          
          return (
            <Card key={bill.id} className="medical-card hover-lift border-0 shadow-medical">
              <CardContent className="p-6">
                <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
                  <div className="space-y-3">
                    <div className="flex flex-col sm:flex-row sm:items-center gap-3">
                      <h3 className="text-xl font-semibold text-foreground">{bill.invoiceNumber}</h3>
                      <Badge 
                        variant="outline" 
                        className={bill.status === 'paid' 
                          ? 'bg-green-50 text-green-700 border-green-200 dark:bg-green-900 dark:text-green-100'
                          : 'bg-orange-50 text-orange-700 border-orange-200 dark:bg-orange-900 dark:text-orange-100'
                        }
                      >
                        {bill.status}
                      </Badge>
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-sm text-muted-foreground">
                      <div>
                        <span className="font-medium text-foreground">Center:</span> {center?.name}
                      </div>
                      <div>
                        <span className="font-medium text-foreground">Patient:</span> {patient?.name}
                      </div>
                      <div>
                        <span className="font-medium text-foreground">Amount:</span> ₹{bill.finalAmount.toLocaleString('en-IN')}
                      </div>
                      <div>
                        <span className="font-medium text-foreground">Date:</span> {new Date(bill.createdDate).toLocaleDateString('en-IN')}
                      </div>
                    </div>
                    <div className="text-sm text-muted-foreground">
                      <span className="font-medium text-foreground">Tests:</span> {bill.tests.join(', ')}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {filteredBills.length === 0 && (
        <div className="text-center py-12">
          <div className="w-16 h-16 bg-gradient-to-br from-green-500 to-green-600 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg">
            <FileText className="h-8 w-8 text-white" />
          </div>
          <p className="text-muted-foreground text-lg">No bills found matching your criteria.</p>
        </div>
      )}
    </div>
  );
}