import React, { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { DiagnosticCenter } from '../App';

interface AddDiagnosticCenterFormProps {
  onSubmit: (centerData: Partial<DiagnosticCenter>) => void;
  onCancel: () => void;
}

export function AddDiagnosticCenterForm({ onSubmit, onCancel }: AddDiagnosticCenterFormProps) {
  const [formData, setFormData] = useState<Partial<DiagnosticCenter>>({
    subscriptionType: 'free',
    paymentType: 'online'
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  const indianStates = [
    'Andhra Pradesh', 'Arunachal Pradesh', 'Assam', 'Bihar', 'Chhattisgarh', 'Goa', 'Gujarat',
    'Haryana', 'Himachal Pradesh', 'Jharkhand', 'Karnataka', 'Kerala', 'Madhya Pradesh',
    'Maharashtra', 'Manipur', 'Meghalaya', 'Mizoram', 'Nagaland', 'Odisha', 'Punjab',
    'Rajasthan', 'Sikkim', 'Tamil Nadu', 'Telangana', 'Tripura', 'Uttar Pradesh',
    'Uttarakhand', 'West Bengal', 'Delhi'
  ];

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* Center Information */}
      <div className="space-y-4">
        <h3 className="text-lg font-semibold text-foreground">Center Information</h3>
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2 col-span-2">
            <Label htmlFor="name">Center Name</Label>
            <Input
              id="name"
              placeholder="Enter center name"
              value={formData.name || ''}
              onChange={(e) => setFormData({...formData, name: e.target.value})}
              className="rounded-lg focus-enhanced"
              required
            />
          </div>
          <div className="space-y-2 col-span-2">
            <Label htmlFor="address">Address</Label>
            <Input
              id="address"
              placeholder="Enter center address"
              value={formData.address || ''}
              onChange={(e) => setFormData({...formData, address: e.target.value})}
              className="rounded-lg focus-enhanced"
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="city">City</Label>
            <Input
              id="city"
              placeholder="Enter city"
              value={formData.city || ''}
              onChange={(e) => setFormData({...formData, city: e.target.value})}
              className="rounded-lg focus-enhanced"
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="state">State</Label>
            <Select value={formData.state || ''} onValueChange={(value) => setFormData({...formData, state: value})}>
              <SelectTrigger className="rounded-lg focus-enhanced">
                <SelectValue placeholder="Select state" />
              </SelectTrigger>
              <SelectContent>
                {indianStates.map(state => (
                  <SelectItem key={state} value={state}>{state}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>

      {/* Owner Information */}
      <div className="space-y-4">
        <h3 className="text-lg font-semibold text-foreground">Owner Information</h3>
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="ownerName">Owner Name</Label>
            <Input
              id="ownerName"
              placeholder="Enter owner name"
              value={formData.ownerName || ''}
              onChange={(e) => setFormData({...formData, ownerName: e.target.value})}
              className="rounded-lg focus-enhanced"
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="ownerPhone">Phone Number</Label>
            <Input
              id="ownerPhone"
              placeholder="Enter phone number"
              value={formData.ownerPhone || ''}
              onChange={(e) => setFormData({...formData, ownerPhone: e.target.value})}
              className="rounded-lg focus-enhanced"
              required
            />
          </div>
          <div className="space-y-2 col-span-2">
            <Label htmlFor="ownerEmail">Email</Label>
            <Input
              id="ownerEmail"
              type="email"
              placeholder="Enter email address"
              value={formData.ownerEmail || ''}
              onChange={(e) => setFormData({...formData, ownerEmail: e.target.value})}
              className="rounded-lg focus-enhanced"
              required
            />
          </div>
          <div className="space-y-2 col-span-2">
            <Label htmlFor="ownerAddress">Owner Address</Label>
            <Input
              id="ownerAddress"
              placeholder="Enter owner address"
              value={formData.ownerAddress || ''}
              onChange={(e) => setFormData({...formData, ownerAddress: e.target.value})}
              className="rounded-lg focus-enhanced"
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="ownerCity">Owner City</Label>
            <Input
              id="ownerCity"
              placeholder="Enter owner city"
              value={formData.ownerCity || ''}
              onChange={(e) => setFormData({...formData, ownerCity: e.target.value})}
              className="rounded-lg focus-enhanced"
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="ownerState">Owner State</Label>
            <Select value={formData.ownerState || ''} onValueChange={(value) => setFormData({...formData, ownerState: value})}>
              <SelectTrigger className="rounded-lg focus-enhanced">
                <SelectValue placeholder="Select state" />
              </SelectTrigger>
              <SelectContent>
                {indianStates.map(state => (
                  <SelectItem key={state} value={state}>{state}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>

      {/* Subscription & Login Details */}
      <div className="space-y-4">
        <h3 className="text-lg font-semibold text-foreground">Subscription & Login</h3>
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="subscriptionType">Subscription Plan</Label>
            <Select value={formData.subscriptionType || 'free'} onValueChange={(value) => setFormData({...formData, subscriptionType: value as any})}>
              <SelectTrigger className="rounded-lg focus-enhanced">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="free">Free Plan</SelectItem>
                <SelectItem value="standard">Standard Plan</SelectItem>
                <SelectItem value="gold">Gold Plan</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="paymentType">Payment Type</Label>
            <Select value={formData.paymentType || 'online'} onValueChange={(value) => setFormData({...formData, paymentType: value as any})}>
              <SelectTrigger className="rounded-lg focus-enhanced">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="online">Online Payment</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="username">Username</Label>
            <Input
              id="username"
              placeholder="Enter username for login"
              value={formData.username || ''}
              onChange={(e) => setFormData({...formData, username: e.target.value})}
              className="rounded-lg focus-enhanced"
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="password">Password</Label>
            <Input
              id="password"
              type="password"
              placeholder="Enter password"
              value={formData.password || ''}
              onChange={(e) => setFormData({...formData, password: e.target.value})}
              className="rounded-lg focus-enhanced"
              required
            />
          </div>
        </div>
      </div>

      <div className="flex justify-end gap-3 pt-6 border-t">
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
        <Button type="submit" className="bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white border-0">
          Add Center
        </Button>
      </div>
    </form>
  );
}