import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Alert, AlertDescription } from './ui/alert';
import { useAuth } from '../contexts/AuthContext';
import { Loader2, Eye, EyeOff, Shield, Stethoscope, Users, AlertCircle } from 'lucide-react';

export const LoginForm = () => {
  const [credentials, setCredentials] = useState({
    username: '',
    password: '',
  });
  const [showPassword, setShowPassword] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { login, error, clearError, isLoading } = useAuth();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!credentials.username || !credentials.password) return;

    setIsSubmitting(true);
    clearError();

    try {
      await login(credentials);
    } catch (err) {
      console.error('Login error:', err);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleInputChange = (field: string, value: string) => {
    setCredentials(prev => ({ ...prev, [field]: value }));
    if (error) clearError();
  };

  const demoAccounts = [
    {
      role: 'Super Admin',
      username: 'superadmin',
      password: 'password',
      icon: <Shield className="w-4 h-4" />,
      description: 'Full system access'
    },
    {
      role: 'Diagnostic Center',
      username: 'testcenter',
      password: 'password',
      icon: <Stethoscope className="w-4 h-4" />,
      description: 'Center management'
    },
    {
      role: 'Patient',
      username: 'patient',
      password: 'password',
      icon: <Users className="w-4 h-4" />,
      description: 'Patient portal'
    }
  ];

  const fillDemoCredentials = (username: string, password: string) => {
    setCredentials({ username, password });
    clearError();
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 via-teal-50 to-cyan-50 dark:from-blue-950 dark:via-teal-950 dark:to-cyan-950 p-4">
      <div className="w-full max-w-md space-y-6">
        {/* Header */}
        <div className="text-center space-y-2">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="w-12 h-12 bg-gradient-to-br from-blue-600 to-teal-600 rounded-2xl flex items-center justify-center shadow-lg">
              <Stethoscope className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-foreground">Composcale.com</h1>
              <p className="text-sm text-muted-foreground">Diagnostic Center Management</p>
            </div>
          </div>
          <p className="text-sm text-muted-foreground">
            Sign in to access your healthcare management system
          </p>
        </div>

        {/* Login Form */}
        <Card className="shadow-lg border-0 medical-card">
          <CardHeader className="space-y-1">
            <CardTitle className="text-xl">Sign In</CardTitle>
            <CardDescription>
              Enter your credentials to access your account
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {error && (
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="username">Username</Label>
                <Input
                  id="username"
                  type="text"
                  placeholder="Enter your username"
                  value={credentials.username}
                  onChange={(e) => handleInputChange('username', e.target.value)}
                  disabled={isSubmitting || isLoading}
                  className="h-11"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <div className="relative">
                  <Input
                    id="password"
                    type={showPassword ? 'text' : 'password'}
                    placeholder="Enter your password"
                    value={credentials.password}
                    onChange={(e) => handleInputChange('password', e.target.value)}
                    disabled={isSubmitting || isLoading}
                    className="h-11 pr-10"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                    disabled={isSubmitting || isLoading}
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <Button
                type="submit"
                className="w-full h-11 btn-gradient"
                disabled={isSubmitting || isLoading || !credentials.username || !credentials.password}
              >
                {isSubmitting || isLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Signing in...
                  </>
                ) : (
                  'Sign In'
                )}
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Demo Accounts */}
        <Card className="shadow-lg border-0 medical-card">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">Demo Accounts</CardTitle>
            <CardDescription>
              Click on any account to auto-fill credentials for testing
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-2">
            {demoAccounts.map((account, index) => (
              <button
                key={index}
                onClick={() => fillDemoCredentials(account.username, account.password)}
                disabled={isSubmitting || isLoading}
                className="w-full p-3 rounded-lg border border-border hover:bg-accent hover:text-accent-foreground transition-colors text-left group disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center text-primary group-hover:bg-primary/20 transition-colors">
                    {account.icon}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <div className="font-medium text-sm">{account.role}</div>
                      <div className="text-xs text-muted-foreground">
                        {account.username}
                      </div>
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {account.description}
                    </div>
                  </div>
                </div>
              </button>
            ))}
          </CardContent>
        </Card>

        {/* Footer */}
        <div className="text-center space-y-2">
          <p className="text-xs text-muted-foreground">
            Secure healthcare management system
          </p>
          <div className="flex items-center justify-center gap-4 text-xs text-muted-foreground">
            <span>© 2024 Composcale.com</span>
            <span>•</span>
            <span>Healthcare Technology</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoginForm;