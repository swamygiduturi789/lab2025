import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { 
  Settings, Lock, Building2, IndianRupee, FileText, Sparkles, 
  CheckCircle, Star, Crown, Gift, CreditCard, Printer
} from 'lucide-react';
import { PasswordChangeForm } from './PasswordChangeForm';
import { CenterProfileManagement } from './CenterProfileManagement';

export function NewFeaturesDemo() {
  const [isOpen, setIsOpen] = useState(false);

  const demoCenter = {
    id: '1',
    name: 'Apollo Diagnostics Mumbai',
    address: '123 MG Road, Fort',
    city: 'Mumbai',
    state: 'Maharashtra',
    pincode: '400001',
    ownerName: 'Dr. Rajesh Sharma',
    ownerPhone: '9876543210',
    ownerEmail: 'rajesh@apollo.com',
    ownerAddress: '456 Linking Road',
    ownerCity: 'Mumbai',
    ownerState: 'Maharashtra',
    subscriptionType: 'gold' as const,
    paymentType: 'online' as const,
    username: 'apollo_mumbai',
    password: 'password123',
    isActive: true,
    createdDate: '2024-01-15'
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button className="rounded-xl bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700 text-white border-0 focus-enhanced">
          <Sparkles className="h-4 w-4 mr-2" />
          View New Features
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Sparkles className="h-5 w-5 text-purple-600" />
            🎉 New Features Demo - MediLab India
          </DialogTitle>
          <DialogDescription>
            Explore all the new enhanced features added to the diagnostic center management system
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-8 py-4">
          {/* Password Management */}
          <Card className="medical-card border-0 shadow-medical">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Lock className="h-5 w-5 text-orange-600" />
                🔐 Enhanced Password Management
              </CardTitle>
              <CardDescription>
                Secure password change with real-time validation for all user roles
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-3">
                    <h4 className="font-semibold">✅ Features Added:</h4>
                    <ul className="space-y-1 text-sm text-muted-foreground">
                      <li>• Real-time password strength validation</li>
                      <li>• Show/hide password toggles</li>
                      <li>• Enterprise-grade security requirements</li>
                      <li>• Visual validation indicators</li>
                      <li>• Works for all user roles</li>
                    </ul>
                  </div>
                  <div className="flex justify-center">
                    <PasswordChangeForm 
                      userRole="diagnostic_center" 
                      userId="demo-user"
                      onPasswordChanged={() => console.log('Password changed')}
                    />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Center Profile Management */}
          <Card className="medical-card border-0 shadow-medical">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Building2 className="h-5 w-5 text-blue-600" />
                🏥 Complete Center Profile Management
              </CardTitle>
              <CardDescription>
                Comprehensive lab branding and information management system
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-3">
                    <h4 className="font-semibold">✅ Features Added:</h4>
                    <ul className="space-y-1 text-sm text-muted-foreground">
                      <li>• Logo upload and management</li>
                      <li>• Complete business information</li>
                      <li>• License and registration numbers</li>
                      <li>• Services and certifications management</li>
                      <li>• Social media integration</li>
                      <li>• Operating hours and emergency contacts</li>
                      <li>• Professional certifications & accreditations</li>
                    </ul>
                  </div>
                  <div className="space-y-3">
                    <h4 className="font-semibold">🎯 Benefits:</h4>
                    <ul className="space-y-1 text-sm text-muted-foreground">
                      <li>• Complete lab branding</li>
                      <li>• Professional invoices and reports</li>
                      <li>• Enhanced credibility</li>
                      <li>• Better patient communication</li>
                      <li>• Regulatory compliance</li>
                    </ul>
                    <div className="pt-2">
                      <CenterProfileManagement 
                        center={demoCenter}
                        onProfileUpdate={(profile) => console.log('Profile updated:', profile)}
                      />
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Enhanced Bill Management */}
          <Card className="medical-card border-0 shadow-medical">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <IndianRupee className="h-5 w-5 text-green-600" />
                💰 Advanced Bill Management System
              </CardTitle>
              <CardDescription>
                Professional invoicing with payment modes, tax calculations, and print functionality
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="space-y-3">
                    <h4 className="font-semibold">💳 Payment Features:</h4>
                    <div className="space-y-2">
                      {['Cash', 'Card', 'UPI', 'Net Banking', 'Cheque', 'Other'].map((mode) => (
                        <Badge key={mode} variant="outline" className="mr-2 mb-1">
                          <CreditCard className="h-3 w-3 mr-1" />
                          {mode}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  <div className="space-y-3">
                    <h4 className="font-semibold">🧮 Advanced Calculations:</h4>
                    <ul className="space-y-1 text-sm text-muted-foreground">
                      <li>• Flexible discount system</li>
                      <li>• Configurable tax rates</li>
                      <li>• Automatic calculations</li>
                      <li>• Insurance integration</li>
                      <li>• Due date management</li>
                    </ul>
                  </div>
                  <div className="space-y-3">
                    <h4 className="font-semibold">🖨️ Print & Export:</h4>
                    <ul className="space-y-1 text-sm text-muted-foreground">
                      <li>• Professional invoice printing</li>
                      <li>• PDF generation</li>
                      <li>• Download functionality</li>
                      <li>• Custom templates</li>
                      <li>• Lab branding integration</li>
                    </ul>
                    <Button
                      variant="outline"
                      size="sm"
                      className="rounded-xl"
                      onClick={() => alert('Print functionality demo')}
                    >
                      <Printer className="h-4 w-4 mr-2" />
                      Demo Print
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Status & Integration */}
          <Card className="medical-card border-0 shadow-medical">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CheckCircle className="h-5 w-5 text-green-600" />
                📊 Implementation Status
              </CardTitle>
              <CardDescription>
                Current status and upcoming features
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h4 className="font-semibold text-green-600">✅ Implemented Features:</h4>
                  <ul className="space-y-2 text-sm">
                    <li className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-green-600" />
                      Password management system
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-green-600" />
                      Center profile management
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-green-600" />
                      Enhanced bill management
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-green-600" />
                      Payment modes & tax calculations
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-green-600" />
                      Print & download functionality
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-green-600" />
                      Enhanced data models
                    </li>
                  </ul>
                </div>
                <div className="space-y-4">
                  <h4 className="font-semibold text-orange-600">🚧 Coming Next:</h4>
                  <ul className="space-y-2 text-sm text-muted-foreground">
                    <li>• Enhanced report generation with multi-parameters</li>
                    <li>• Patient dashboard with PDF access</li>
                    <li>• Data export (daily/weekly/monthly reports)</li>
                    <li>• 6-month data cleanup options</li>
                    <li>• Recently added patients priority</li>
                    <li>• SMS integration improvements</li>
                    <li>• PDF report enhancements</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Navigation Instructions */}
          <Card className="medical-card border-0 shadow-medical bg-gradient-to-r from-blue-50 to-teal-50 dark:from-blue-950/50 dark:to-teal-950/50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Settings className="h-5 w-5 text-blue-600" />
                🧭 How to Access New Features
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-3">
                  <h4 className="font-semibold">🎯 For Super Admin:</h4>
                  <ul className="space-y-1 text-sm text-muted-foreground">
                    <li>• Go to Settings → Change Password button</li>
                    <li>• Enhanced diagnostic center management</li>
                    <li>• Improved bills and reports section</li>
                  </ul>
                </div>
                <div className="space-y-3">
                  <h4 className="font-semibold">🏥 For Diagnostic Centers:</h4>
                  <ul className="space-y-1 text-sm text-muted-foreground">
                    <li>• Settings → Manage Profile & Change Password</li>
                    <li>• Bill Management → Enhanced billing system</li>
                    <li>• All new features are integrated!</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="flex justify-end gap-3 pt-4 border-t">
          <Button variant="outline" onClick={() => setIsOpen(false)}>
            Close Demo
          </Button>
          <Button 
            onClick={() => {
              setIsOpen(false);
              alert('🎉 All features are now live! Check the Settings page and Bill Management sections.');
            }}
            className="bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white border-0"
          >
            <CheckCircle className="h-4 w-4 mr-2" />
            Start Using Features
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}