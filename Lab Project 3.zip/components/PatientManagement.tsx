import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Alert, AlertDescription } from './ui/alert';
import { 
  UserPlus, Search, Edit, Trash2, Eye, Phone, Mail, MapPin, 
  Calendar, User, Heart, Activity, FileText, Download, Send
} from 'lucide-react';
import { Patient } from '../App';

const mockPatients: Patient[] = [
  {
    id: '1',
    fullName: 'Rajesh Kumar',
    email: 'rajesh.kumar@email.com',
    phone: '9876543210',
    address: '123 MG Road',
    city: 'Mumbai',
    state: 'Maharashtra',
    whatsappNumber: '9876543210',
    passcode: '1234',
    centerId: '1',
    createdDate: '2024-06-01'
  },
  {
    id: '2',
    fullName: 'Priya Sharma',
    email: 'priya.sharma@email.com',
    phone: '9876543211',
    address: '456 Park Street',
    city: 'Delhi',
    state: 'Delhi',
    whatsappNumber: '9876543211',
    passcode: '5678',
    centerId: '1',
    createdDate: '2024-06-02'
  },
  {
    id: '3',
    fullName: 'Amit Patel',
    email: 'amit.patel@email.com',
    phone: '9876543212',
    address: '789 Commercial Street',
    city: 'Bangalore',
    state: 'Karnataka',
    whatsappNumber: '9876543212',
    passcode: '9012',
    centerId: '1',
    createdDate: '2024-06-03'
  }
];

export function PatientManagement() {
  const [patients, setPatients] = useState<Patient[]>(mockPatients);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedPatient, setSelectedPatient] = useState<Patient | null>(null);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false);
  const [newPatient, setNewPatient] = useState<Partial<Patient>>({});
  const [editPatient, setEditPatient] = useState<Partial<Patient>>({});

  const filteredPatients = patients.filter(patient =>
    patient.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    patient.phone.includes(searchTerm) ||
    patient.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    patient.city.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleAddPatient = () => {
    const patient: Patient = {
      id: (patients.length + 1).toString(),
      fullName: newPatient.fullName || '',
      email: newPatient.email || '',
      phone: newPatient.phone || '',
      address: newPatient.address || '',
      city: newPatient.city || '',
      state: newPatient.state || '',
      whatsappNumber: newPatient.whatsappNumber || newPatient.phone || '',
      passcode: Math.floor(1000 + Math.random() * 9000).toString(),
      centerId: '1',
      createdDate: new Date().toISOString().split('T')[0]
    };

    setPatients([...patients, patient]);
    setNewPatient({});
    setIsAddDialogOpen(false);
  };

  const handleEditPatient = () => {
    if (selectedPatient) {
      const updatedPatients = patients.map(p =>
        p.id === selectedPatient.id ? { ...selectedPatient, ...editPatient } : p
      );
      setPatients(updatedPatients);
      setEditPatient({});
      setIsEditDialogOpen(false);
      setSelectedPatient(null);
    }
  };

  const handleDeletePatient = (patientId: string) => {
    if (confirm('Are you sure you want to delete this patient?')) {
      setPatients(patients.filter(p => p.id !== patientId));
    }
  };

  const sendSMS = (patient: Patient, message: string) => {
    // Mock SMS sending
    alert(`SMS sent to ${patient.fullName} (${patient.phone}): ${message}`);
  };

  const exportPatientData = () => {
    const dataStr = JSON.stringify(filteredPatients, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
    const exportFileDefaultName = 'patients_export.json';
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-green-600 via-teal-600 to-blue-600 p-8 text-white shadow-medical-lg">
        <div className="absolute inset-0 opacity-20" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.1'%3E%3Cpath d='M30 15c8.284 0 15 6.716 15 15s-6.716 15-15 15-15-6.716-15-15 6.716-15 15-15z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`
        }}></div>
        <div className="relative z-10">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl md:text-4xl font-bold mb-2 flex items-center gap-3">
                <User className="h-8 w-8 text-green-300" />
                Patient Management
              </h1>
              <p className="text-blue-100 text-lg">Manage patient records and information</p>
            </div>
            <div className="hidden lg:block">
              <div className="text-right">
                <p className="text-blue-100 text-sm">Total Patients</p>
                <div className="flex items-center gap-2 justify-end">
                  <Heart className="h-4 w-4 text-green-300" />
                  <span className="text-green-300 font-medium text-2xl">{patients.length}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Search and Actions */}
      <div className="flex flex-col sm:flex-row gap-4 items-center justify-between">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search patients..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 rounded-xl border-border/50 focus-enhanced"
          />
        </div>
        <div className="flex gap-3">
          <Button
            onClick={exportPatientData}
            variant="outline"
            className="rounded-xl border-border/50 hover:bg-blue-50 hover:border-blue-200 dark:hover:bg-blue-950/50 focus-enhanced"
          >
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button className="rounded-xl bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white border-0 focus-enhanced">
                <UserPlus className="h-4 w-4 mr-2" />
                Add Patient
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  <UserPlus className="h-5 w-5 text-green-600" />
                  Add New Patient
                </DialogTitle>
                <DialogDescription>
                  Enter patient information to create a new record
                </DialogDescription>
              </DialogHeader>
              <div className="grid grid-cols-2 gap-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="fullName">Full Name</Label>
                  <Input
                    id="fullName"
                    placeholder="Enter full name"
                    value={newPatient.fullName || ''}
                    onChange={(e) => setNewPatient({...newPatient, fullName: e.target.value})}
                    className="rounded-lg focus-enhanced"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="Enter email"
                    value={newPatient.email || ''}
                    onChange={(e) => setNewPatient({...newPatient, email: e.target.value})}
                    className="rounded-lg focus-enhanced"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="phone">Phone</Label>
                  <Input
                    id="phone"
                    placeholder="Enter phone number"
                    value={newPatient.phone || ''}
                    onChange={(e) => setNewPatient({...newPatient, phone: e.target.value})}
                    className="rounded-lg focus-enhanced"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="whatsapp">WhatsApp Number</Label>
                  <Input
                    id="whatsapp"
                    placeholder="Enter WhatsApp number"
                    value={newPatient.whatsappNumber || ''}
                    onChange={(e) => setNewPatient({...newPatient, whatsappNumber: e.target.value})}
                    className="rounded-lg focus-enhanced"
                  />
                </div>
                <div className="space-y-2 col-span-2">
                  <Label htmlFor="address">Address</Label>
                  <Input
                    id="address"
                    placeholder="Enter address"
                    value={newPatient.address || ''}
                    onChange={(e) => setNewPatient({...newPatient, address: e.target.value})}
                    className="rounded-lg focus-enhanced"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="city">City</Label>
                  <Input
                    id="city"
                    placeholder="Enter city"
                    value={newPatient.city || ''}
                    onChange={(e) => setNewPatient({...newPatient, city: e.target.value})}
                    className="rounded-lg focus-enhanced"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="state">State</Label>
                  <Input
                    id="state"
                    placeholder="Enter state"
                    value={newPatient.state || ''}
                    onChange={(e) => setNewPatient({...newPatient, state: e.target.value})}
                    className="rounded-lg focus-enhanced"
                  />
                </div>
              </div>
              <div className="flex justify-end gap-3">
                <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={handleAddPatient} className="bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white border-0">
                  Add Patient
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Patients List */}
      <div className="space-y-4">
        {filteredPatients.map((patient) => (
          <Card key={patient.id} className="medical-card hover-lift border-0 shadow-medical">
            <CardContent className="p-6">
              <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
                <div className="space-y-3">
                  <div className="flex flex-col sm:flex-row sm:items-center gap-3">
                    <h3 className="text-xl font-semibold text-foreground">{patient.fullName}</h3>
                    <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200 dark:bg-green-900 dark:text-green-100 w-fit">
                      Active Patient
                    </Badge>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 text-sm text-muted-foreground">
                    <div className="flex items-center gap-2">
                      <Phone className="h-4 w-4 text-blue-600" />
                      <span className="font-medium text-foreground">Phone:</span> {patient.phone}
                    </div>
                    <div className="flex items-center gap-2">
                      <Mail className="h-4 w-4 text-purple-600" />
                      <span className="font-medium text-foreground">Email:</span> {patient.email}
                    </div>
                    <div className="flex items-center gap-2">
                      <MapPin className="h-4 w-4 text-green-600" />
                      <span className="font-medium text-foreground">City:</span> {patient.city}, {patient.state}
                    </div>
                    <div className="flex items-center gap-2">
                      <Calendar className="h-4 w-4 text-orange-600" />
                      <span className="font-medium text-foreground">Joined:</span> {new Date(patient.createdDate).toLocaleDateString('en-IN')}
                    </div>
                    <div className="flex items-center gap-2">
                      <Activity className="h-4 w-4 text-teal-600" />
                      <span className="font-medium text-foreground">Passcode:</span> ****
                    </div>
                  </div>
                </div>
                <div className="flex flex-col sm:flex-row gap-3">
                  <Dialog open={isViewDialogOpen && selectedPatient?.id === patient.id} onOpenChange={(open) => {
                    setIsViewDialogOpen(open);
                    if (!open) setSelectedPatient(null);
                  }}>
                    <DialogTrigger asChild>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setSelectedPatient(patient)}
                        className="rounded-xl border-border/50 hover:bg-blue-50 hover:border-blue-200 dark:hover:bg-blue-950/50 focus-enhanced"
                      >
                        <Eye className="h-4 w-4 mr-2" />
                        View
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-2xl">
                      <DialogHeader>
                        <DialogTitle className="flex items-center gap-2">
                          <User className="h-5 w-5 text-blue-600" />
                          Patient Details
                        </DialogTitle>
                        <DialogDescription>
                          View comprehensive patient information and account details
                        </DialogDescription>
                      </DialogHeader>
                      {selectedPatient && (
                        <div className="space-y-6">
                          <div className="grid grid-cols-2 gap-4">
                            <div className="space-y-2">
                              <Label className="text-sm font-medium">Full Name</Label>
                              <p className="text-foreground">{selectedPatient.fullName}</p>
                            </div>
                            <div className="space-y-2">
                              <Label className="text-sm font-medium">Email</Label>
                              <p className="text-foreground">{selectedPatient.email}</p>
                            </div>
                            <div className="space-y-2">
                              <Label className="text-sm font-medium">Phone</Label>
                              <p className="text-foreground">{selectedPatient.phone}</p>
                            </div>
                            <div className="space-y-2">
                              <Label className="text-sm font-medium">WhatsApp</Label>
                              <p className="text-foreground">{selectedPatient.whatsappNumber}</p>
                            </div>
                            <div className="space-y-2 col-span-2">
                              <Label className="text-sm font-medium">Address</Label>
                              <p className="text-foreground">{selectedPatient.address}</p>
                            </div>
                            <div className="space-y-2">
                              <Label className="text-sm font-medium">City</Label>
                              <p className="text-foreground">{selectedPatient.city}</p>
                            </div>
                            <div className="space-y-2">
                              <Label className="text-sm font-medium">State</Label>
                              <p className="text-foreground">{selectedPatient.state}</p>
                            </div>
                            <div className="space-y-2">
                              <Label className="text-sm font-medium">Passcode</Label>
                              <p className="text-foreground font-mono">{selectedPatient.passcode}</p>
                            </div>
                            <div className="space-y-2">
                              <Label className="text-sm font-medium">Registration Date</Label>
                              <p className="text-foreground">{new Date(selectedPatient.createdDate).toLocaleDateString('en-IN')}</p>
                            </div>
                          </div>
                          <div className="flex gap-3">
                            <Button
                              onClick={() => sendSMS(selectedPatient, `Dear ${selectedPatient.fullName}, your passcode is ${selectedPatient.passcode}. Use this to login to MediLab India patient portal.`)}
                              className="bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white border-0"
                            >
                              <Send className="h-4 w-4 mr-2" />
                              Send Passcode SMS
                            </Button>
                          </div>
                        </div>
                      )}
                    </DialogContent>
                  </Dialog>

                  <Dialog open={isEditDialogOpen && selectedPatient?.id === patient.id} onOpenChange={(open) => {
                    setIsEditDialogOpen(open);
                    if (!open) {
                      setSelectedPatient(null);
                      setEditPatient({});
                    }
                  }}>
                    <DialogTrigger asChild>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          setSelectedPatient(patient);
                          setEditPatient(patient);
                        }}
                        className="rounded-xl border-border/50 hover:bg-yellow-50 hover:border-yellow-200 dark:hover:bg-yellow-950/50 focus-enhanced"
                      >
                        <Edit className="h-4 w-4 mr-2" />
                        Edit
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-2xl">
                      <DialogHeader>
                        <DialogTitle className="flex items-center gap-2">
                          <Edit className="h-5 w-5 text-yellow-600" />
                          Edit Patient
                        </DialogTitle>
                        <DialogDescription>
                          Update patient information and contact details
                        </DialogDescription>
                      </DialogHeader>
                      <div className="grid grid-cols-2 gap-4 py-4">
                        <div className="space-y-2">
                          <Label htmlFor="editFullName">Full Name</Label>
                          <Input
                            id="editFullName"
                            value={editPatient.fullName || ''}
                            onChange={(e) => setEditPatient({...editPatient, fullName: e.target.value})}
                            className="rounded-lg focus-enhanced"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="editEmail">Email</Label>
                          <Input
                            id="editEmail"
                            type="email"
                            value={editPatient.email || ''}
                            onChange={(e) => setEditPatient({...editPatient, email: e.target.value})}
                            className="rounded-lg focus-enhanced"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="editPhone">Phone</Label>
                          <Input
                            id="editPhone"
                            value={editPatient.phone || ''}
                            onChange={(e) => setEditPatient({...editPatient, phone: e.target.value})}
                            className="rounded-lg focus-enhanced"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="editWhatsapp">WhatsApp Number</Label>
                          <Input
                            id="editWhatsapp"
                            value={editPatient.whatsappNumber || ''}
                            onChange={(e) => setEditPatient({...editPatient, whatsappNumber: e.target.value})}
                            className="rounded-lg focus-enhanced"
                          />
                        </div>
                        <div className="space-y-2 col-span-2">
                          <Label htmlFor="editAddress">Address</Label>
                          <Input
                            id="editAddress"
                            value={editPatient.address || ''}
                            onChange={(e) => setEditPatient({...editPatient, address: e.target.value})}
                            className="rounded-lg focus-enhanced"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="editCity">City</Label>
                          <Input
                            id="editCity"
                            value={editPatient.city || ''}
                            onChange={(e) => setEditPatient({...editPatient, city: e.target.value})}
                            className="rounded-lg focus-enhanced"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="editState">State</Label>
                          <Input
                            id="editState"
                            value={editPatient.state || ''}
                            onChange={(e) => setEditPatient({...editPatient, state: e.target.value})}
                            className="rounded-lg focus-enhanced"
                          />
                        </div>
                      </div>
                      <div className="flex justify-end gap-3">
                        <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
                          Cancel
                        </Button>
                        <Button onClick={handleEditPatient} className="bg-gradient-to-r from-yellow-500 to-yellow-600 hover:from-yellow-600 hover:to-yellow-700 text-white border-0">
                          Save Changes
                        </Button>
                      </div>
                    </DialogContent>
                  </Dialog>

                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleDeletePatient(patient.id)}
                    className="rounded-xl border-red-200 text-red-600 hover:bg-red-50 hover:border-red-300 dark:hover:bg-red-950/50 focus-enhanced"
                  >
                    <Trash2 className="h-4 w-4 mr-2" />
                    Delete
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredPatients.length === 0 && (
        <div className="text-center py-12">
          <div className="w-16 h-16 bg-gradient-to-br from-green-500 to-green-600 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg">
            <User className="h-8 w-8 text-white" />
          </div>
          <p className="text-muted-foreground text-lg">No patients found matching your search.</p>
        </div>
      )}
    </div>
  );
}