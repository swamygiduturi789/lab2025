import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { 
  Building2, Search, Plus, Eye, Edit, Trash2, MapPin, 
  User, Phone, Mail, Calendar, Star, Crown, Gift
} from 'lucide-react';
import { DiagnosticCenter } from '../App';
import { AddDiagnosticCenterForm } from './AddDiagnosticCenterForm';
import { EditDiagnosticCenterForm } from './EditDiagnosticCenterForm';

const mockCenters: DiagnosticCenter[] = [
  {
    id: '1',
    name: 'Apollo Diagnostics Mumbai',
    address: '123 MG Road, Fort',
    city: 'Mumbai',
    state: 'Maharashtra',
    ownerName: 'Dr. Rajesh Sharma',
    ownerPhone: '9876543210',
    ownerEmail: 'rajesh@apollo.com',
    ownerAddress: '456 Linking Road',
    ownerCity: 'Mumbai',
    ownerState: 'Maharashtra',
    subscriptionType: 'gold',
    paymentType: 'online',
    username: 'apollo_mumbai',
    password: 'password123',
    isActive: true,
    createdDate: '2024-01-15'
  },
  {
    id: '2',
    name: 'Care Diagnostics Delhi',
    address: '789 CP Block, Connaught Place',
    city: 'Delhi',
    state: 'Delhi',
    ownerName: 'Dr. Priya Verma',
    ownerPhone: '9876543211',
    ownerEmail: 'priya@care.com',
    ownerAddress: '321 GK-1',
    ownerCity: 'Delhi',
    ownerState: 'Delhi',
    subscriptionType: 'standard',
    paymentType: 'online',
    username: 'care_delhi',
    password: 'password123',
    isActive: true,
    createdDate: '2024-02-01'
  },
  {
    id: '3',
    name: 'Metropolis Labs Bangalore',
    address: '456 Brigade Road',
    city: 'Bangalore',
    state: 'Karnataka',
    ownerName: 'Dr. Amit Kumar',
    ownerPhone: '9876543212',
    ownerEmail: 'amit@metropolis.com',
    ownerAddress: '789 MG Road',
    ownerCity: 'Bangalore',
    ownerState: 'Karnataka',
    subscriptionType: 'free',
    paymentType: 'online',
    username: 'metro_bangalore',
    password: 'password123',
    isActive: false,
    createdDate: '2024-03-10'
  }
];

export function DiagnosticCentersList() {
  const [centers, setCenters] = useState<DiagnosticCenter[]>(mockCenters);
  const [searchTerm, setSearchTerm] = useState('');
  const [subscriptionFilter, setSubscriptionFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [selectedCenter, setSelectedCenter] = useState<DiagnosticCenter | null>(null);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false);

  const filteredCenters = centers.filter(center => {
    const matchesSearch = center.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         center.city.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         center.ownerName.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesSubscription = subscriptionFilter === 'all' || center.subscriptionType === subscriptionFilter;
    const matchesStatus = statusFilter === 'all' || 
                         (statusFilter === 'active' && center.isActive) ||
                         (statusFilter === 'inactive' && !center.isActive);
    return matchesSearch && matchesSubscription && matchesStatus;
  });

  const handleAddCenter = (centerData: Partial<DiagnosticCenter>) => {
    const newCenter: DiagnosticCenter = {
      id: (centers.length + 1).toString(),
      ...centerData,
      isActive: true,
      createdDate: new Date().toISOString().split('T')[0]
    } as DiagnosticCenter;

    setCenters([...centers, newCenter]);
    setIsAddDialogOpen(false);
  };

  const handleEditCenter = (centerData: Partial<DiagnosticCenter>) => {
    if (selectedCenter) {
      const updatedCenters = centers.map(center =>
        center.id === selectedCenter.id ? { ...center, ...centerData } : center
      );
      setCenters(updatedCenters);
      setIsEditDialogOpen(false);
      setSelectedCenter(null);
    }
  };

  const handleDeleteCenter = (centerId: string) => {
    if (confirm('Are you sure you want to delete this diagnostic center?')) {
      setCenters(centers.filter(center => center.id !== centerId));
    }
  };

  const toggleCenterStatus = (centerId: string) => {
    setCenters(centers.map(center =>
      center.id === centerId ? { ...center, isActive: !center.isActive } : center
    ));
  };

  const getSubscriptionIcon = (type: string) => {
    switch (type) {
      case 'gold': return <Crown className="h-4 w-4" />;
      case 'standard': return <Star className="h-4 w-4" />;
      case 'free': return <Gift className="h-4 w-4" />;
      default: return <Building2 className="h-4 w-4" />;
    }
  };

  const getSubscriptionColor = (type: string) => {
    switch (type) {
      case 'gold': return 'bg-yellow-50 text-yellow-700 border-yellow-200 dark:bg-yellow-900 dark:text-yellow-100';
      case 'standard': return 'bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-900 dark:text-blue-100';
      case 'free': return 'bg-green-50 text-green-700 border-green-200 dark:bg-green-900 dark:text-green-100';
      default: return 'bg-gray-50 text-gray-700 border-gray-200 dark:bg-gray-900 dark:text-gray-100';
    }
  };

  const getStats = () => {
    return {
      total: centers.length,
      active: centers.filter(c => c.isActive).length,
      gold: centers.filter(c => c.subscriptionType === 'gold').length,
      standard: centers.filter(c => c.subscriptionType === 'standard').length,
      free: centers.filter(c => c.subscriptionType === 'free').length
    };
  };

  const stats = getStats();

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-blue-600 via-teal-600 to-green-600 p-8 text-white shadow-medical-lg">
        <div className="absolute inset-0 opacity-20" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.1'%3E%3Cpath d='M30 8c12.15 0 22 9.85 22 22s-9.85 22-22 22S8 42.15 8 30 17.85 8 30 8z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`
        }}></div>
        <div className="relative z-10">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl md:text-4xl font-bold mb-2 flex items-center gap-3">
                <Building2 className="h-8 w-8 text-blue-300" />
                Diagnostic Centers
              </h1>
              <p className="text-blue-100 text-lg">Manage all registered diagnostic centers</p>
            </div>
            <div className="hidden lg:block">
              <div className="text-right">
                <p className="text-blue-100 text-sm">Active Centers</p>
                <div className="flex items-center gap-2 justify-end">
                  <Building2 className="h-4 w-4 text-blue-300" />
                  <span className="text-blue-300 font-medium text-2xl">{stats.active}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="stats-grid">
        <Card className="medical-card hover-lift border-0 shadow-medical">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground font-medium">Total Centers</p>
                <p className="text-3xl font-bold text-foreground">{stats.total}</p>
              </div>
              <div className="rounded-lg bg-gradient-to-br from-blue-500 to-blue-600 p-3 shadow-lg">
                <Building2 className="h-6 w-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="medical-card hover-lift border-0 shadow-medical">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground font-medium">Gold Subscribers</p>
                <p className="text-3xl font-bold text-yellow-600">{stats.gold}</p>
              </div>
              <div className="rounded-lg bg-gradient-to-br from-yellow-500 to-yellow-600 p-3 shadow-lg">
                <Crown className="h-6 w-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="medical-card hover-lift border-0 shadow-medical">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground font-medium">Standard</p>
                <p className="text-3xl font-bold text-blue-600">{stats.standard}</p>
              </div>
              <div className="rounded-lg bg-gradient-to-br from-blue-500 to-blue-600 p-3 shadow-lg">
                <Star className="h-6 w-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="medical-card hover-lift border-0 shadow-medical">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground font-medium">Free Plan</p>
                <p className="text-3xl font-bold text-green-600">{stats.free}</p>
              </div>
              <div className="rounded-lg bg-gradient-to-br from-green-500 to-green-600 p-3 shadow-lg">
                <Gift className="h-6 w-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Search and Filters */}
      <div className="flex flex-col sm:flex-row gap-4 items-center justify-between">
        <div className="flex flex-1 gap-4 max-w-3xl">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search centers..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 rounded-xl border-border/50 focus-enhanced"
            />
          </div>
          <Select value={subscriptionFilter} onValueChange={setSubscriptionFilter}>
            <SelectTrigger className="w-40 rounded-xl border-border/50 focus-enhanced">
              <SelectValue placeholder="Subscription" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Plans</SelectItem>
              <SelectItem value="gold">Gold</SelectItem>
              <SelectItem value="standard">Standard</SelectItem>
              <SelectItem value="free">Free</SelectItem>
            </SelectContent>
          </Select>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-32 rounded-xl border-border/50 focus-enhanced">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="active">Active</SelectItem>
              <SelectItem value="inactive">Inactive</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button className="rounded-xl bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white border-0 focus-enhanced">
              <Plus className="h-4 w-4 mr-2" />
              Add Center
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Plus className="h-5 w-5 text-blue-600" />
                Add Diagnostic Center
              </DialogTitle>
              <DialogDescription>
                Register a new diagnostic center to the platform
              </DialogDescription>
            </DialogHeader>
            <AddDiagnosticCenterForm onSubmit={handleAddCenter} onCancel={() => setIsAddDialogOpen(false)} />
          </DialogContent>
        </Dialog>
      </div>

      {/* Centers List */}
      <div className="space-y-4">
        {filteredCenters.map((center) => (
          <Card key={center.id} className="medical-card hover-lift border-0 shadow-medical">
            <CardContent className="p-6">
              <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-6">
                <div className="space-y-4 flex-1">
                  <div className="flex flex-col sm:flex-row sm:items-center gap-3">
                    <h3 className="text-xl font-semibold text-foreground">{center.name}</h3>
                    <div className="flex gap-2">
                      <Badge variant="outline" className={getSubscriptionColor(center.subscriptionType)}>
                        {getSubscriptionIcon(center.subscriptionType)}
                        <span className="ml-1 capitalize">{center.subscriptionType}</span>
                      </Badge>
                      <Badge 
                        variant="outline" 
                        className={center.isActive 
                          ? 'bg-green-50 text-green-700 border-green-200 dark:bg-green-900 dark:text-green-100'
                          : 'bg-red-50 text-red-700 border-red-200 dark:bg-red-900 dark:text-red-100'
                        }
                      >
                        {center.isActive ? 'Active' : 'Inactive'}
                      </Badge>
                    </div>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 text-sm text-muted-foreground">
                    <div className="flex items-center gap-2">
                      <MapPin className="h-4 w-4 text-green-600" />
                      <span className="font-medium text-foreground">Location:</span> {center.city}, {center.state}
                    </div>
                    <div className="flex items-center gap-2">
                      <User className="h-4 w-4 text-blue-600" />
                      <span className="font-medium text-foreground">Owner:</span> {center.ownerName}
                    </div>
                    <div className="flex items-center gap-2">
                      <Phone className="h-4 w-4 text-purple-600" />
                      <span className="font-medium text-foreground">Phone:</span> {center.ownerPhone}
                    </div>
                    <div className="flex items-center gap-2">
                      <Mail className="h-4 w-4 text-orange-600" />
                      <span className="font-medium text-foreground">Email:</span> {center.ownerEmail}
                    </div>
                    <div className="flex items-center gap-2">
                      <Calendar className="h-4 w-4 text-teal-600" />
                      <span className="font-medium text-foreground">Joined:</span> {new Date(center.createdDate).toLocaleDateString('en-IN')}
                    </div>
                  </div>
                  <div className="p-3 bg-muted/20 rounded-lg">
                    <p className="text-sm text-muted-foreground">
                      <span className="font-medium text-foreground">Address:</span> {center.address}, {center.city}, {center.state}
                    </p>
                  </div>
                </div>
                <div className="flex flex-col sm:flex-row gap-3">
                  <Dialog open={isViewDialogOpen && selectedCenter?.id === center.id} onOpenChange={(open) => {
                    setIsViewDialogOpen(open);
                    if (!open) setSelectedCenter(null);
                  }}>
                    <DialogTrigger asChild>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setSelectedCenter(center)}
                        className="rounded-xl border-border/50 hover:bg-blue-50 hover:border-blue-200 dark:hover:bg-blue-950/50 focus-enhanced"
                      >
                        <Eye className="h-4 w-4 mr-2" />
                        View
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-3xl">
                      <DialogHeader>
                        <DialogTitle className="flex items-center gap-2">
                          <Building2 className="h-5 w-5 text-blue-600" />
                          Center Details
                        </DialogTitle>
                        <DialogDescription>
                          View detailed information about this diagnostic center
                        </DialogDescription>
                      </DialogHeader>
                      {selectedCenter && (
                        <div className="space-y-6">
                          <div className="grid grid-cols-2 gap-6">
                            <div className="space-y-4">
                              <h4 className="font-semibold text-lg">Center Information</h4>
                              <div className="space-y-3">
                                <div>
                                  <p className="text-sm text-muted-foreground">Name</p>
                                  <p className="font-medium">{selectedCenter.name}</p>
                                </div>
                                <div>
                                  <p className="text-sm text-muted-foreground">Address</p>
                                  <p className="font-medium">{selectedCenter.address}</p>
                                </div>
                                <div>
                                  <p className="text-sm text-muted-foreground">City, State</p>
                                  <p className="font-medium">{selectedCenter.city}, {selectedCenter.state}</p>
                                </div>
                                <div>
                                  <p className="text-sm text-muted-foreground">Username</p>
                                  <p className="font-medium font-mono">{selectedCenter.username}</p>
                                </div>
                              </div>
                            </div>
                            <div className="space-y-4">
                              <h4 className="font-semibold text-lg">Owner Information</h4>
                              <div className="space-y-3">
                                <div>
                                  <p className="text-sm text-muted-foreground">Owner Name</p>
                                  <p className="font-medium">{selectedCenter.ownerName}</p>
                                </div>
                                <div>
                                  <p className="text-sm text-muted-foreground">Phone</p>
                                  <p className="font-medium">{selectedCenter.ownerPhone}</p>
                                </div>
                                <div>
                                  <p className="text-sm text-muted-foreground">Email</p>
                                  <p className="font-medium">{selectedCenter.ownerEmail}</p>
                                </div>
                                <div>
                                  <p className="text-sm text-muted-foreground">Address</p>
                                  <p className="font-medium">{selectedCenter.ownerAddress}, {selectedCenter.ownerCity}</p>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div className="flex gap-4 pt-4 border-t">
                            <div>
                              <p className="text-sm text-muted-foreground">Subscription Plan</p>
                              <Badge variant="outline" className={getSubscriptionColor(selectedCenter.subscriptionType)}>
                                {getSubscriptionIcon(selectedCenter.subscriptionType)}
                                <span className="ml-1 capitalize">{selectedCenter.subscriptionType}</span>
                              </Badge>
                            </div>
                            <div>
                              <p className="text-sm text-muted-foreground">Status</p>
                              <Badge 
                                variant="outline" 
                                className={selectedCenter.isActive 
                                  ? 'bg-green-50 text-green-700 border-green-200'
                                  : 'bg-red-50 text-red-700 border-red-200'
                                }
                              >
                                {selectedCenter.isActive ? 'Active' : 'Inactive'}
                              </Badge>
                            </div>
                            <div>
                              <p className="text-sm text-muted-foreground">Registration Date</p>
                              <p className="font-medium">{new Date(selectedCenter.createdDate).toLocaleDateString('en-IN')}</p>
                            </div>
                          </div>
                        </div>
                      )}
                    </DialogContent>
                  </Dialog>

                  <Dialog open={isEditDialogOpen && selectedCenter?.id === center.id} onOpenChange={(open) => {
                    setIsEditDialogOpen(open);
                    if (!open) setSelectedCenter(null);
                  }}>
                    <DialogTrigger asChild>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setSelectedCenter(center)}
                        className="rounded-xl border-border/50 hover:bg-yellow-50 hover:border-yellow-200 dark:hover:bg-yellow-950/50 focus-enhanced"
                      >
                        <Edit className="h-4 w-4 mr-2" />
                        Edit
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
                      <DialogHeader>
                        <DialogTitle className="flex items-center gap-2">
                          <Edit className="h-5 w-5 text-yellow-600" />
                          Edit Diagnostic Center
                        </DialogTitle>
                        <DialogDescription>
                          Update diagnostic center information and settings
                        </DialogDescription>
                      </DialogHeader>
                      {selectedCenter && (
                        <EditDiagnosticCenterForm 
                          center={selectedCenter}
                          onSubmit={handleEditCenter} 
                          onCancel={() => setIsEditDialogOpen(false)} 
                        />
                      )}
                    </DialogContent>
                  </Dialog>

                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => toggleCenterStatus(center.id)}
                    className={`rounded-xl border-border/50 focus-enhanced ${
                      center.isActive 
                        ? 'hover:bg-red-50 hover:border-red-200 dark:hover:bg-red-950/50' 
                        : 'hover:bg-green-50 hover:border-green-200 dark:hover:bg-green-950/50'
                    }`}
                  >
                    {center.isActive ? 'Deactivate' : 'Activate'}
                  </Button>

                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleDeleteCenter(center.id)}
                    className="rounded-xl border-red-200 text-red-600 hover:bg-red-50 hover:border-red-300 dark:hover:bg-red-950/50 focus-enhanced"
                  >
                    <Trash2 className="h-4 w-4 mr-2" />
                    Delete
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredCenters.length === 0 && (
        <div className="text-center py-12">
          <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg">
            <Building2 className="h-8 w-8 text-white" />
          </div>
          <p className="text-muted-foreground text-lg">No diagnostic centers found matching your criteria.</p>
        </div>
      )}
    </div>
  );
}