import { TestReport, Patient, DiagnosticCenter } from '../App';
import { PDFGenerator } from './PDFUtils';

interface PDFReportGeneratorProps {
  report: TestReport;
  patient: Patient;
  center: DiagnosticCenter;
  centerProfile?: {
    logo?: string;
    tagline?: string;
    licenseNumber?: string;
    website?: string;
  };
}

export function PDFReportGenerator({ report, patient, center, centerProfile }: PDFReportGeneratorProps) {
  
  const generateReportHTML = () => {
    const logoSection = centerProfile?.logo ? `
      <div style="text-align: center; margin-bottom: 15px;">
        <img src="${centerProfile.logo}" alt="${center.name} Logo" style="max-height: 60px; max-width: 180px; object-fit: contain;" />
      </div>
    ` : '';

    return `
      <div class="report-container" style="max-width: 800px; margin: 0 auto; background: white; border: 2px solid #2563eb; border-radius: 8px; overflow: hidden; font-size: 13px;">
        <div class="header" style="background: linear-gradient(135deg, #2563eb, #1d4ed8); color: white; padding: 20px; text-align: center;">
          ${logoSection}
          <div class="center-name" style="font-size: 22px; font-weight: bold; margin-bottom: 6px;">${center.name}</div>
          <div class="center-contact" style="font-size: 12px; margin-top: 10px; opacity: 0.9; line-height: 1.3;">
            <div><strong>📍 ${center.address}</strong></div>
            <div>${center.city}, ${center.state} - ${center.pincode}</div>
            <div>📞 ${center.ownerPhone} | ✉️ ${center.ownerEmail}</div>
            ${centerProfile?.licenseNumber ? `<div>License: ${centerProfile.licenseNumber}</div>` : ''}
          </div>
          <div class="report-title" style="font-size: 16px; font-weight: bold; margin: 12px 0 8px 0; text-transform: uppercase; letter-spacing: 1px;">Medical Test Report</div>
          
          <!-- Patient Passcode Display -->
          <div class="passcode-section" style="background: rgba(255,255,255,0.15); padding: 8px 16px; border-radius: 6px; margin-top: 10px; border: 1px solid rgba(255,255,255,0.2);">
            <div style="font-size: 11px; opacity: 0.8; margin-bottom: 2px;">Patient Access Code</div>
            <div style="font-size: 18px; font-weight: bold; letter-spacing: 2px; font-family: monospace;">${patient.passcode}</div>
          </div>
        </div>
        
        <div class="content" style="padding: 20px;">
          <!-- Compact Patient & Test Info in Grid -->
          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 20px;">
            <div class="info-section" style="background: #f8fafc; padding: 12px; border-radius: 6px; border-left: 3px solid #2563eb;">
              <h4 style="color: #2563eb; margin: 0 0 8px 0; font-size: 14px; font-weight: bold;">Patient Information</h4>
              <div class="info-grid" style="display: grid; grid-template-columns: auto 1fr; gap: 8px 12px; font-size: 12px;">
                <span style="font-weight: bold; color: #374151;">Name:</span><span>${patient.fullName}</span>
                <span style="font-weight: bold; color: #374151;">ID:</span><span>${patient.id}</span>
                <span style="font-weight: bold; color: #374151;">Phone:</span><span>${patient.phone}</span>
                <span style="font-weight: bold; color: #374151;">Address:</span><span>${patient.address}, ${patient.city}</span>
                ${patient.dateOfBirth ? `<span style="font-weight: bold; color: #374151;">DOB:</span><span>${new Date(patient.dateOfBirth).toLocaleDateString('en-IN')}</span>` : ''}
                ${patient.gender ? `<span style="font-weight: bold; color: #374151;">Gender:</span><span>${patient.gender.charAt(0).toUpperCase() + patient.gender.slice(1)}</span>` : ''}
              </div>
            </div>
            
            <div class="info-section" style="background: #f8fafc; padding: 12px; border-radius: 6px; border-left: 3px solid #2563eb;">
              <h4 style="color: #2563eb; margin: 0 0 8px 0; font-size: 14px; font-weight: bold;">Test Information</h4>
              <div class="info-grid" style="display: grid; grid-template-columns: auto 1fr; gap: 8px 12px; font-size: 12px;">
                <span style="font-weight: bold; color: #374151;">Test:</span><span>${report.testName}</span>
                <span style="font-weight: bold; color: #374151;">Type:</span><span>${report.testType}</span>
                <span style="font-weight: bold; color: #374151;">Sample Date:</span><span>${new Date(report.sampleDate).toLocaleDateString('en-IN')}</span>
                <span style="font-weight: bold; color: #374151;">Report Date:</span><span>${report.reportDate ? new Date(report.reportDate).toLocaleDateString('en-IN') : 'Pending'}</span>
                <span style="font-weight: bold; color: #374151;">Referred By:</span><span>${report.referredBy}</span>
                <span style="font-weight: bold; color: #374151;">Report ID:</span><span>${report.passcodeId}</span>
              </div>
            </div>
          </div>

          ${report.results && report.results.length > 0 ? `
          <div>
            <h3 style="color: #2563eb; margin: 0 0 12px 0; font-size: 15px;">Test Results</h3>
            <table style="width: 100%; border-collapse: collapse; font-size: 12px;">
              <thead>
                <tr style="background: #f1f5f9;">
                  <th style="padding: 8px; text-align: left; border: 1px solid #e2e8f0; font-weight: bold; color: #374151;">Parameter</th>
                  <th style="padding: 8px; text-align: left; border: 1px solid #e2e8f0; font-weight: bold; color: #374151;">Result</th>
                  <th style="padding: 8px; text-align: left; border: 1px solid #e2e8f0; font-weight: bold; color: #374151;">Unit</th>
                  <th style="padding: 8px; text-align: left; border: 1px solid #e2e8f0; font-weight: bold; color: #374151;">Reference</th>
                  <th style="padding: 8px; text-align: left; border: 1px solid #e2e8f0; font-weight: bold; color: #374151;">Status</th>
                </tr>
              </thead>
              <tbody>
                ${report.results.map(result => `
                  <tr>
                    <td style="padding: 6px 8px; border: 1px solid #e2e8f0;"><strong>${result.parameter}</strong></td>
                    <td style="padding: 6px 8px; border: 1px solid #e2e8f0;">${result.value}</td>
                    <td style="padding: 6px 8px; border: 1px solid #e2e8f0;">${result.unit}</td>
                    <td style="padding: 6px 8px; border: 1px solid #e2e8f0;">${result.reference}</td>
                    <td style="padding: 6px 8px; border: 1px solid #e2e8f0;"><span style="color: ${result.status === 'normal' ? '#059669' : result.status === 'abnormal' ? '#dc2626' : '#d97706'}; font-weight: bold;">${result.status ? result.status.charAt(0).toUpperCase() + result.status.slice(1) : 'Normal'}</span></td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>
          ` : `
          <div style="text-align: center; padding: 30px; background: #fef3c7; border-radius: 6px; border: 1px solid #f59e0b;">
            <h3 style="color: #92400e; margin-bottom: 8px; font-size: 14px;">Report In Progress</h3>
            <p style="color: #92400e; margin: 0; font-size: 12px;">Test results are being processed and will be available soon.</p>
          </div>
          `}

          ${report.notes ? `
          <div style="margin-top: 15px; padding: 12px; background: #f0f9ff; border-radius: 6px; border-left: 3px solid #0284c7;">
            <h4 style="color: #0284c7; margin: 0 0 6px 0; font-size: 13px;">Clinical Notes</h4>
            <p style="margin: 0; color: #374151; font-size: 12px;">${report.notes}</p>
          </div>
          ` : ''}

          <!-- Compact Signature Section -->
          <div style="margin-top: 20px; display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
            <div style="text-align: center; padding: 15px; border: 1px dashed #94a3b8; border-radius: 6px;">
              <div style="height: 30px; margin-bottom: 8px;"></div>
              <div style="border-top: 1px solid #94a3b8; padding-top: 4px; font-size: 12px;">
                <strong>${report.technician || 'Lab Technician'}</strong><br>
                <small style="font-size: 10px;">Signature & Date</small>
              </div>
            </div>
            <div style="text-align: center; padding: 15px; border: 1px dashed #94a3b8; border-radius: 6px;">
              <div style="height: 30px; margin-bottom: 8px;"></div>
              <div style="border-top: 1px solid #94a3b8; padding-top: 4px; font-size: 12px;">
                <strong>${report.verifiedBy || 'Pathologist'}</strong><br>
                <small style="font-size: 10px;">Signature & Date</small>
              </div>
            </div>
          </div>

          <!-- Simple footer note -->
          <div style="margin-top: 20px; padding-top: 15px; border-top: 1px solid #e2e8f0; text-align: center; color: #6b7280; font-size: 10px;">
            <p style="margin: 0;"><strong>Patient Access Code: ${patient.passcode}</strong> | Generated: ${new Date().toLocaleDateString('en-IN')} ${new Date().toLocaleTimeString('en-IN')}</p>
            <p style="margin: 4px 0 0 0;">This report is computer generated and does not require physical signature.</p>
          </div>
        </div>
      </div>
    `;
  };

  const generatePDF = () => {
    const htmlContent = PDFGenerator.createPrintableHTML(
      generateReportHTML(),
      `Medical Report - ${report.testName}`
    );
    
    PDFGenerator.generatePDF(htmlContent, `report_${report.passcodeId}_${patient.fullName.replace(/\s+/g, '_')}`);
  };

  const downloadPDF = async () => {
    const htmlContent = PDFGenerator.createPrintableHTML(
      generateReportHTML(),
      `Medical Report - ${report.testName}`
    );
    
    await PDFGenerator.downloadAsPDF(htmlContent, `report_${report.passcodeId}_${patient.fullName.replace(/\s+/g, '_')}`);
  };

  const viewReport = () => {
    try {
      const viewWindow = window.open('', '_blank', 'width=900,height=700,scrollbars=yes,resizable=yes');
      
      if (!viewWindow) {
        alert('Please allow popups for this site to view the report. Then try again.');
        return;
      }

      const logoSection = centerProfile?.logo ? `
        <div style="text-align: center; margin-bottom: 20px;">
          <img src="${centerProfile.logo}" alt="${center.name} Logo" style="max-height: 80px; max-width: 200px; object-fit: contain;" />
        </div>
      ` : '';

      const htmlContent = `
        <!DOCTYPE html>
        <html>
          <head>
            <title>View Report - ${report.testName}</title>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <style>
              body {
                font-family: 'Arial', sans-serif;
                margin: 0;
                padding: 20px;
                background: #f5f5f5;
                color: #333;
                line-height: 1.6;
              }
              .container {
                max-width: 900px;
                margin: 0 auto;
                background: white;
                border-radius: 10px;
                box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
                overflow: hidden;
              }
              .action-buttons {
                background: #f1f5f9;
                padding: 20px;
                text-align: center;
                border-bottom: 3px solid #2563eb;
              }
              .btn {
                display: inline-block;
                padding: 12px 24px;
                margin: 0 10px;
                background: #2563eb;
                color: white;
                text-decoration: none;
                border-radius: 6px;
                font-weight: bold;
                cursor: pointer;
                border: none;
                font-size: 14px;
                transition: all 0.3s;
              }
              .btn:hover {
                background: #1d4ed8;
                transform: translateY(-2px);
              }
              .btn-secondary {
                background: #6b7280;
              }
              .btn-secondary:hover {
                background: #4b5563;
              }
              .header {
                background: linear-gradient(135deg, #2563eb, #1d4ed8);
                color: white;
                padding: 30px;
                text-align: center;
              }
              .center-name {
                font-size: 28px;
                font-weight: bold;
                margin-bottom: 8px;
              }
              .center-contact {
                font-size: 14px;
                margin-top: 15px;
                opacity: 0.9;
              }
              .report-title {
                font-size: 20px;
                font-weight: bold;
                margin-top: 15px;
              }
              .passcode-highlight {
                background: rgba(255,255,255,0.15);
                padding: 10px 20px;
                border-radius: 8px;
                margin-top: 15px;
                border: 1px solid rgba(255,255,255,0.2);
              }
              .content {
                padding: 30px;
              }
              .patient-info {
                background: #f8fafc;
                padding: 20px;
                border-radius: 8px;
                margin-bottom: 20px;
                border-left: 4px solid #2563eb;
              }
              .info-row {
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 20px;
                margin-bottom: 10px;
              }
              .info-label {
                font-weight: bold;
                color: #2563eb;
              }
            </style>
          </head>
          <body>
            <div class="container">
              <div class="action-buttons">
                <button class="btn" onclick="window.print()">🖨️ Print Report</button>
                <button class="btn" onclick="downloadReport()">📄 Download PDF</button>
                <button class="btn btn-secondary" onclick="window.close()">❌ Close</button>
              </div>
              
              <div class="header">
                ${logoSection}
                <div class="center-name">${center.name}</div>
                <div class="center-contact">
                  📍 ${center.address}, ${center.city}, ${center.state} - ${center.pincode}<br>
                  📞 ${center.ownerPhone} | ✉️ ${center.ownerEmail}
                </div>
                <div class="report-title">Medical Test Report</div>
                <div class="passcode-highlight">
                  <div style="font-size: 12px; opacity: 0.8;">Patient Access Code</div>
                  <div style="font-size: 20px; font-weight: bold; letter-spacing: 2px; font-family: monospace;">${patient.passcode}</div>
                </div>
              </div>
              
              <div class="content">
                <div class="patient-info">
                  <h3 style="color: #2563eb; margin-bottom: 15px;">Patient Information</h3>
                  <div class="info-row">
                    <div><span class="info-label">Name:</span> ${patient.fullName}</div>
                    <div><span class="info-label">Patient ID:</span> ${patient.id}</div>
                  </div>
                  <div class="info-row">
                    <div><span class="info-label">Phone:</span> ${patient.phone}</div>
                    <div><span class="info-label">Address:</span> ${patient.address}, ${patient.city}</div>
                  </div>
                  <div class="info-row">
                    <div><span class="info-label">Access Code:</span> <strong style="font-family: monospace; color: #2563eb;">${patient.passcode}</strong></div>
                    <div><span class="info-label">Report ID:</span> ${report.passcodeId}</div>
                  </div>
                </div>

                <div class="patient-info">
                  <h3 style="color: #2563eb; margin-bottom: 15px;">Test Information</h3>
                  <div class="info-row">
                    <div><span class="info-label">Test Name:</span> ${report.testName}</div>
                    <div><span class="info-label">Test Type:</span> ${report.testType}</div>
                  </div>
                  <div class="info-row">
                    <div><span class="info-label">Sample Date:</span> ${new Date(report.sampleDate).toLocaleDateString('en-IN')}</div>
                    <div><span class="info-label">Report Date:</span> ${report.reportDate ? new Date(report.reportDate).toLocaleDateString('en-IN') : 'Pending'}</div>
                  </div>
                  <div class="info-row">
                    <div><span class="info-label">Referred By:</span> ${report.referredBy}</div>
                    <div><span class="info-label">Status:</span> <strong>${report.status}</strong></div>
                  </div>
                </div>
                
                ${report.results && report.results.length > 0 ? `
                  <div class="patient-info">
                    <h3 style="color: #2563eb; margin-bottom: 15px;">Test Results</h3>
                    ${report.results.map(result => `
                      <div style="margin-bottom: 15px; padding: 10px; background: white; border-radius: 6px; border: 1px solid #e2e8f0;">
                        <div style="font-weight: bold; color: #374151; margin-bottom: 5px;">${result.parameter}</div>
                        <div style="color: #6b7280;">
                          <strong>Result:</strong> ${result.value} ${result.unit} | 
                          <strong>Reference:</strong> ${result.reference} | 
                          <strong>Status:</strong> <span style="color: ${result.status === 'normal' ? '#059669' : result.status === 'abnormal' ? '#dc2626' : '#d97706'};">${result.status || 'Normal'}</span>
                        </div>
                      </div>
                    `).join('')}
                  </div>
                ` : '<div class="patient-info"><h3 style="color: #d97706;">Results are being processed.</h3></div>'}

                <div style="text-align: center; margin-top: 30px; padding: 20px; background: #f8fafc; border-radius: 8px;">
                  <p style="margin: 0; padding-top: 15px; border-top: 1px solid #e2e8f0;"><strong>Patient Access Code: ${patient.passcode}</strong> | Generated: ${new Date().toLocaleDateString('en-IN')} ${new Date().toLocaleTimeString('en-IN')}</p>
                </div>
              </div>
            </div>
            
            <script>
              function downloadReport() {
                alert('Use Print > Save as PDF to download the report as PDF file');
                window.print();
              }
            </script>
          </body>
        </html>
      `;

      viewWindow.document.write(htmlContent);
      viewWindow.document.close();
      viewWindow.focus();
      
    } catch (error) {
      console.error('Error viewing report:', error);
      alert('Failed to view report. Please try again.');
    }
  };

  return {
    generatePDF,
    downloadPDF,
    viewReport
  };
}