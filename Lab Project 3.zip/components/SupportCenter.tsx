import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Badge } from './ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Textarea } from './ui/textarea';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { 
  MessageSquare, Search, Plus, Eye, Paperclip, 
  Calendar, User, CheckCircle, Clock, AlertCircle, Send
} from 'lucide-react';

interface SupportTicket {
  id: string;
  title: string;
  description: string;
  priority: 'low' | 'medium' | 'high' | 'urgent';
  status: 'open' | 'in_progress' | 'resolved' | 'closed';
  category: string;
  userId: string;
  userRole: string;
  centerId?: string;
  createdDate: string;
  updatedDate: string;
  attachments?: string[];
  responses?: TicketResponse[];
}

interface TicketResponse {
  id: string;
  message: string;
  userId: string;
  userRole: string;
  createdDate: string;
}

interface SupportCenterProps {
  userRole: 'super_admin' | 'diagnostic_center' | 'patient';
  centerId?: string;
}

const mockTickets: SupportTicket[] = [
  {
    id: '1',
    title: 'Unable to generate PDF reports',
    description: 'The PDF generation feature is not working properly. When I try to download patient reports, I get an error message.',
    priority: 'high',
    status: 'open',
    category: 'Technical Issue',
    userId: '2',
    userRole: 'diagnostic_center',
    centerId: '1',
    createdDate: '2024-06-15',
    updatedDate: '2024-06-15',
    attachments: ['error-screenshot.png'],
    responses: []
  },
  {
    id: '2',
    title: 'Request for additional test categories',
    description: 'We would like to add more test categories to our system, specifically for cardiac tests and advanced blood work.',
    priority: 'medium',
    status: 'in_progress',
    category: 'Feature Request',
    userId: '2',
    userRole: 'diagnostic_center',
    centerId: '1',
    createdDate: '2024-06-14',
    updatedDate: '2024-06-15',
    responses: [
      {
        id: '1',
        message: 'Thank you for your request. We are reviewing the feasibility of adding these categories.',
        userId: '1',
        userRole: 'super_admin',
        createdDate: '2024-06-15'
      }
    ]
  },
  {
    id: '3',
    title: 'Payment gateway integration issue',
    description: 'Customers are facing issues while making online payments. The Razorpay integration seems to be failing.',
    priority: 'urgent',
    status: 'resolved',
    category: 'Payment Issue',
    userId: '2',
    userRole: 'diagnostic_center',
    centerId: '1',
    createdDate: '2024-06-13',
    updatedDate: '2024-06-14',
    responses: [
      {
        id: '2',
        message: 'We have identified and fixed the Razorpay integration issue. Please test and confirm.',
        userId: '1',
        userRole: 'super_admin',
        createdDate: '2024-06-14'
      }
    ]
  }
];

const ticketCategories = [
  'Technical Issue',
  'Feature Request',
  'Payment Issue',
  'Account Issue',
  'Data Issue',
  'Training Request',
  'General Inquiry',
  'Bug Report'
];

export function SupportCenter({ userRole, centerId }: SupportCenterProps) {
  const [tickets, setTickets] = useState<SupportTicket[]>(mockTickets);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [priorityFilter, setPriorityFilter] = useState<string>('all');
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [selectedTicket, setSelectedTicket] = useState<SupportTicket | null>(null);
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false);
  const [newTicket, setNewTicket] = useState<Partial<SupportTicket>>({
    priority: 'medium',
    category: '',
    title: '',
    description: ''
  });
  const [newResponse, setNewResponse] = useState('');

  // Filter tickets based on user role
  const userTickets = userRole === 'super_admin' 
    ? tickets 
    : tickets.filter(ticket => ticket.centerId === centerId);

  const filteredTickets = userTickets.filter(ticket => {
    const matchesSearch = ticket.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         ticket.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || ticket.status === statusFilter;
    const matchesPriority = priorityFilter === 'all' || ticket.priority === priorityFilter;
    return matchesSearch && matchesStatus && matchesPriority;
  });

  const handleCreateTicket = () => {
    const ticket: SupportTicket = {
      id: (tickets.length + 1).toString(),
      title: newTicket.title || '',
      description: newTicket.description || '',
      priority: newTicket.priority as any || 'medium',
      status: 'open',
      category: newTicket.category || '',
      userId: userRole === 'super_admin' ? '1' : '2',
      userRole,
      centerId: userRole !== 'super_admin' ? centerId : undefined,
      createdDate: new Date().toISOString().split('T')[0],
      updatedDate: new Date().toISOString().split('T')[0],
      responses: []
    };

    setTickets([...tickets, ticket]);
    setNewTicket({
      priority: 'medium',
      category: '',
      title: '',
      description: ''
    });
    setIsCreateDialogOpen(false);
  };

  const handleAddResponse = () => {
    if (!selectedTicket || !newResponse.trim()) return;

    const response: TicketResponse = {
      id: Date.now().toString(),
      message: newResponse,
      userId: userRole === 'super_admin' ? '1' : '2',
      userRole,
      createdDate: new Date().toISOString().split('T')[0]
    };

    const updatedTickets = tickets.map(ticket => 
      ticket.id === selectedTicket.id 
        ? {
            ...ticket,
            responses: [...(ticket.responses || []), response],
            updatedDate: new Date().toISOString().split('T')[0],
            status: userRole === 'super_admin' && ticket.status === 'open' ? 'in_progress' as const : ticket.status
          }
        : ticket
    );

    setTickets(updatedTickets);
    setSelectedTicket({
      ...selectedTicket,
      responses: [...(selectedTicket.responses || []), response]
    });
    setNewResponse('');
  };

  const updateTicketStatus = (ticketId: string, newStatus: SupportTicket['status']) => {
    setTickets(tickets.map(ticket => 
      ticket.id === ticketId 
        ? { ...ticket, status: newStatus, updatedDate: new Date().toISOString().split('T')[0] }
        : ticket
    ));
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'urgent': return 'bg-red-50 text-red-700 border-red-200 dark:bg-red-900 dark:text-red-100';
      case 'high': return 'bg-orange-50 text-orange-700 border-orange-200 dark:bg-orange-900 dark:text-orange-100';
      case 'medium': return 'bg-yellow-50 text-yellow-700 border-yellow-200 dark:bg-yellow-900 dark:text-yellow-100';
      case 'low': return 'bg-green-50 text-green-700 border-green-200 dark:bg-green-900 dark:text-green-100';
      default: return 'bg-gray-50 text-gray-700 border-gray-200 dark:bg-gray-900 dark:text-gray-100';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'open': return 'bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-900 dark:text-blue-100';
      case 'in_progress': return 'bg-yellow-50 text-yellow-700 border-yellow-200 dark:bg-yellow-900 dark:text-yellow-100';
      case 'resolved': return 'bg-green-50 text-green-700 border-green-200 dark:bg-green-900 dark:text-green-100';
      case 'closed': return 'bg-gray-50 text-gray-700 border-gray-200 dark:bg-gray-900 dark:text-gray-100';
      default: return 'bg-gray-50 text-gray-700 border-gray-200 dark:bg-gray-900 dark:text-gray-100';
    }
  };

  const getStats = () => {
    return {
      total: userTickets.length,
      open: userTickets.filter(t => t.status === 'open').length,
      inProgress: userTickets.filter(t => t.status === 'in_progress').length,
      resolved: userTickets.filter(t => t.status === 'resolved').length
    };
  };

  const stats = getStats();

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-purple-600 via-pink-600 to-indigo-600 p-8 text-white shadow-medical-lg">
        <div className="absolute inset-0 opacity-20" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.1'%3E%3Cpath d='M30 5c13.807 0 25 11.193 25 25S43.807 55 30 55 5 43.807 5 30 16.193 5 30 5z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`
        }}></div>
        <div className="relative z-10">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl md:text-4xl font-bold mb-2 flex items-center gap-3">
                <MessageSquare className="h-8 w-8 text-purple-300" />
                Support Center
              </h1>
              <p className="text-blue-100 text-lg">
                {userRole === 'super_admin' 
                  ? 'Manage support tickets from all diagnostic centers'
                  : 'Get help and submit support requests'
                }
              </p>
            </div>
            <div className="hidden lg:block">
              <div className="text-right">
                <p className="text-blue-100 text-sm">Open Tickets</p>
                <div className="flex items-center gap-2 justify-end">
                  <AlertCircle className="h-4 w-4 text-purple-300" />
                  <span className="text-purple-300 font-medium text-2xl">{stats.open}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="stats-grid">
        <Card className="medical-card hover-lift border-0 shadow-medical">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground font-medium">Total Tickets</p>
                <p className="text-3xl font-bold text-foreground">{stats.total}</p>
              </div>
              <div className="rounded-lg bg-gradient-to-br from-blue-500 to-blue-600 p-3 shadow-lg">
                <MessageSquare className="h-6 w-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="medical-card hover-lift border-0 shadow-medical">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground font-medium">Open Tickets</p>
                <p className="text-3xl font-bold text-blue-600">{stats.open}</p>
              </div>
              <div className="rounded-lg bg-gradient-to-br from-orange-500 to-orange-600 p-3 shadow-lg">
                <AlertCircle className="h-6 w-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="medical-card hover-lift border-0 shadow-medical">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground font-medium">In Progress</p>
                <p className="text-3xl font-bold text-yellow-600">{stats.inProgress}</p>
              </div>
              <div className="rounded-lg bg-gradient-to-br from-yellow-500 to-yellow-600 p-3 shadow-lg">
                <Clock className="h-6 w-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="medical-card hover-lift border-0 shadow-medical">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground font-medium">Resolved</p>
                <p className="text-3xl font-bold text-green-600">{stats.resolved}</p>
              </div>
              <div className="rounded-lg bg-gradient-to-br from-green-500 to-green-600 p-3 shadow-lg">
                <CheckCircle className="h-6 w-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Search and Filters */}
      <div className="flex flex-col sm:flex-row gap-4 items-center justify-between">
        <div className="flex flex-1 gap-4 max-w-3xl">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search tickets..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 rounded-xl border-border/50 focus-enhanced"
            />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-40 rounded-xl border-border/50 focus-enhanced">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="open">Open</SelectItem>
              <SelectItem value="in_progress">In Progress</SelectItem>
              <SelectItem value="resolved">Resolved</SelectItem>
              <SelectItem value="closed">Closed</SelectItem>
            </SelectContent>
          </Select>
          <Select value={priorityFilter} onValueChange={setPriorityFilter}>
            <SelectTrigger className="w-40 rounded-xl border-border/50 focus-enhanced">
              <SelectValue placeholder="Priority" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Priority</SelectItem>
              <SelectItem value="urgent">Urgent</SelectItem>
              <SelectItem value="high">High</SelectItem>
              <SelectItem value="medium">Medium</SelectItem>
              <SelectItem value="low">Low</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button className="rounded-xl bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700 text-white border-0 focus-enhanced">
              <Plus className="h-4 w-4 mr-2" />
              Create Ticket
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Plus className="h-5 w-5 text-purple-600" />
                Create Support Ticket
              </DialogTitle>
              <DialogDescription>
                Submit a new support request or report an issue
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="title">Title</Label>
                <Input
                  id="title"
                  placeholder="Brief description of the issue"
                  value={newTicket.title || ''}
                  onChange={(e) => setNewTicket({...newTicket, title: e.target.value})}
                  className="rounded-lg focus-enhanced"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="category">Category</Label>
                  <Select value={newTicket.category || ''} onValueChange={(value) => setNewTicket({...newTicket, category: value})}>
                    <SelectTrigger className="rounded-lg focus-enhanced">
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      {ticketCategories.map(category => (
                        <SelectItem key={category} value={category}>{category}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="priority">Priority</Label>
                  <Select value={newTicket.priority || 'medium'} onValueChange={(value) => setNewTicket({...newTicket, priority: value as any})}>
                    <SelectTrigger className="rounded-lg focus-enhanced">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                      <SelectItem value="urgent">Urgent</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  placeholder="Detailed description of the issue or request"
                  value={newTicket.description || ''}
                  onChange={(e) => setNewTicket({...newTicket, description: e.target.value})}
                  className="rounded-lg focus-enhanced min-h-[120px]"
                />
              </div>
            </div>
            <div className="flex justify-end gap-3">
              <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                Cancel
              </Button>
              <Button 
                onClick={handleCreateTicket} 
                disabled={!newTicket.title || !newTicket.description}
                className="bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700 text-white border-0"
              >
                Create Ticket
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Tickets List */}
      <div className="space-y-4">
        {filteredTickets.map((ticket) => (
          <Card key={ticket.id} className="medical-card hover-lift border-0 shadow-medical">
            <CardContent className="p-6">
              <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-6">
                <div className="space-y-3 flex-1">
                  <div className="flex flex-col sm:flex-row sm:items-center gap-3">
                    <h3 className="text-xl font-semibold text-foreground">{ticket.title}</h3>
                    <div className="flex gap-2">
                      <Badge variant="outline" className={getPriorityColor(ticket.priority)}>
                        {ticket.priority.toUpperCase()}
                      </Badge>
                      <Badge variant="outline" className={getStatusColor(ticket.status)}>
                        {ticket.status.replace('_', ' ').toUpperCase()}
                      </Badge>
                      <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-900 dark:text-blue-100">
                        {ticket.category}
                      </Badge>
                    </div>
                  </div>
                  <p className="text-muted-foreground line-clamp-2">{ticket.description}</p>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm text-muted-foreground">
                    <div className="flex items-center gap-2">
                      <User className="h-4 w-4 text-blue-600" />
                      <span className="font-medium text-foreground">Role:</span> {ticket.userRole.replace('_', ' ')}
                    </div>
                    <div className="flex items-center gap-2">
                      <Calendar className="h-4 w-4 text-orange-600" />
                      <span className="font-medium text-foreground">Created:</span> {new Date(ticket.createdDate).toLocaleDateString('en-IN')}
                    </div>
                    <div className="flex items-center gap-2">
                      <MessageSquare className="h-4 w-4 text-purple-600" />
                      <span className="font-medium text-foreground">Responses:</span> {ticket.responses?.length || 0}
                    </div>
                    <div className="flex items-center gap-2">
                      <Calendar className="h-4 w-4 text-green-600" />
                      <span className="font-medium text-foreground">Updated:</span> {new Date(ticket.updatedDate).toLocaleDateString('en-IN')}
                    </div>
                  </div>
                </div>
                <div className="flex flex-col sm:flex-row gap-3">
                  <Dialog open={isViewDialogOpen && selectedTicket?.id === ticket.id} onOpenChange={(open) => {
                    setIsViewDialogOpen(open);
                    if (!open) setSelectedTicket(null);
                  }}>
                    <DialogTrigger asChild>
                      <Button
                        variant="outline"
                        onClick={() => setSelectedTicket(ticket)}
                        className="rounded-xl border-border/50 hover:bg-blue-50 hover:border-blue-200 dark:hover:bg-blue-950/50 focus-enhanced"
                      >
                        <Eye className="h-4 w-4 mr-2" />
                        View Details
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
                      <DialogHeader>
                        <DialogTitle className="flex items-center gap-2">
                          <MessageSquare className="h-5 w-5 text-purple-600" />
                          Ticket Details
                        </DialogTitle>
                        <DialogDescription>
                          View ticket information, responses, and manage the support request
                        </DialogDescription>
                      </DialogHeader>
                      {selectedTicket && (
                        <div className="space-y-6">
                          <div className="space-y-4">
                            <div>
                              <h3 className="text-lg font-semibold mb-2">{selectedTicket.title}</h3>
                              <p className="text-muted-foreground">{selectedTicket.description}</p>
                            </div>
                            <div className="flex gap-2">
                              <Badge variant="outline" className={getPriorityColor(selectedTicket.priority)}>
                                {selectedTicket.priority.toUpperCase()}
                              </Badge>
                              <Badge variant="outline" className={getStatusColor(selectedTicket.status)}>
                                {selectedTicket.status.replace('_', ' ').toUpperCase()}
                              </Badge>
                            </div>
                          </div>
                          
                          {selectedTicket.responses && selectedTicket.responses.length > 0 && (
                            <div className="space-y-4">
                              <h4 className="font-semibold">Responses</h4>
                              <div className="space-y-3 max-h-60 overflow-y-auto">
                                {selectedTicket.responses.map((response) => (
                                  <div key={response.id} className="p-3 bg-muted/20 rounded-lg">
                                    <div className="flex justify-between items-start mb-2">
                                      <span className="font-medium text-sm">
                                        {response.userRole === 'super_admin' ? 'Support Team' : 'You'}
                                      </span>
                                      <span className="text-xs text-muted-foreground">
                                        {new Date(response.createdDate).toLocaleDateString('en-IN')}
                                      </span>
                                    </div>
                                    <p className="text-sm">{response.message}</p>
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}
                          
                          <div className="space-y-3">
                            <Label htmlFor="newResponse">Add Response</Label>
                            <Textarea
                              id="newResponse"
                              placeholder="Type your response..."
                              value={newResponse}
                              onChange={(e) => setNewResponse(e.target.value)}
                              className="rounded-lg focus-enhanced"
                            />
                            <div className="flex justify-between">
                              <div className="flex gap-2">
                                {userRole === 'super_admin' && (
                                  <>
                                    <Button
                                      variant="outline"
                                      size="sm"
                                      onClick={() => updateTicketStatus(selectedTicket.id, 'in_progress')}
                                      disabled={selectedTicket.status === 'in_progress'}
                                    >
                                      Mark In Progress
                                    </Button>
                                    <Button
                                      variant="outline"
                                      size="sm"
                                      onClick={() => updateTicketStatus(selectedTicket.id, 'resolved')}
                                      disabled={selectedTicket.status === 'resolved'}
                                    >
                                      Mark Resolved
                                    </Button>
                                  </>
                                )}
                              </div>
                              <Button 
                                onClick={handleAddResponse}
                                disabled={!newResponse.trim()}
                                className="bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700 text-white border-0"
                              >
                                <Send className="h-4 w-4 mr-2" />
                                Send Response
                              </Button>
                            </div>
                          </div>
                        </div>
                      )}
                    </DialogContent>
                  </Dialog>
                  
                  {userRole === 'super_admin' && ticket.status !== 'resolved' && (
                    <Button
                      onClick={() => updateTicketStatus(ticket.id, 'resolved')}
                      className="rounded-xl bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white border-0 focus-enhanced"
                    >
                      <CheckCircle className="h-4 w-4 mr-2" />
                      Resolve
                    </Button>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredTickets.length === 0 && (
        <div className="text-center py-12">
          <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-purple-600 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg">
            <MessageSquare className="h-8 w-8 text-white" />
          </div>
          <p className="text-muted-foreground text-lg">No support tickets found matching your criteria.</p>
        </div>
      )}
    </div>
  );
}