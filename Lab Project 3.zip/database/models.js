// =====================================================
// Database Models for MediLab India
// =====================================================

const { executeQuery, executeTransaction } = require('./connection');
const bcrypt = require('bcrypt');
const { v4: uuidv4 } = require('uuid');

// =====================================================
// USER MODEL
// =====================================================
class UserModel {
  static async create(userData) {
    const { username, password, role, name, phone, centerName } = userData;
    const hashedPassword = await bcrypt.hash(password, 10);
    const userId = uuidv4();
    
    const query = `
      INSERT INTO users (id, username, password, role, name, phone, center_name) 
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `;
    
    return executeQuery(query, [userId, username, hashedPassword, role, name, phone, centerName]);
  }

  static async findByUsername(username) {
    const query = 'SELECT * FROM users WHERE username = ?';
    return executeQuery(query, [username]);
  }

  static async findById(id) {
    const query = 'SELECT * FROM users WHERE id = ?';
    return executeQuery(query, [id]);
  }

  static async authenticate(username, password) {
    const result = await this.findByUsername(username);
    if (!result.success || result.data.length === 0) {
      return { success: false, error: 'User not found' };
    }

    const user = result.data[0];
    const isValid = await bcrypt.compare(password, user.password);
    
    if (!isValid) {
      return { success: false, error: 'Invalid password' };
    }

    // Remove password from response
    delete user.password;
    return { success: true, data: user };
  }

  static async updatePassword(userId, newPassword) {
    const hashedPassword = await bcrypt.hash(newPassword, 10);
    const query = 'UPDATE users SET password = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?';
    return executeQuery(query, [hashedPassword, userId]);
  }

  static async getAll(role = null) {
    let query = 'SELECT id, username, role, name, phone, center_name, is_active, created_at FROM users';
    const params = [];
    
    if (role) {
      query += ' WHERE role = ?';
      params.push(role);
    }
    
    query += ' ORDER BY created_at DESC';
    return executeQuery(query, params);
  }
}

// =====================================================
// DIAGNOSTIC CENTER MODEL
// =====================================================
class DiagnosticCenterModel {
  static async create(centerData) {
    const centerId = uuidv4();
    const hashedPassword = await bcrypt.hash(centerData.password, 10);
    
    const queries = [
      {
        query: `
          INSERT INTO diagnostic_centers (
            id, name, address, city, state, pincode, owner_name, owner_phone, 
            owner_email, owner_address, owner_city, owner_state, subscription_type,
            username, password, license_number, registration_number, website,
            description, operating_hours, emergency_contact
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `,
        params: [
          centerId, centerData.name, centerData.address, centerData.city,
          centerData.state, centerData.pincode, centerData.ownerName,
          centerData.ownerPhone, centerData.ownerEmail, centerData.ownerAddress,
          centerData.ownerCity, centerData.ownerState, centerData.subscriptionType,
          centerData.username, hashedPassword, centerData.licenseNumber,
          centerData.registrationNumber, centerData.website, centerData.description,
          centerData.operatingHours, centerData.emergencyContact
        ]
      },
      {
        query: `
          INSERT INTO users (id, username, password, role, name, phone, center_name)
          VALUES (?, ?, ?, 'diagnostic_center', ?, ?, ?)
        `,
        params: [
          uuidv4(), centerData.username, hashedPassword,
          centerData.ownerName, centerData.ownerPhone, centerData.name
        ]
      }
    ];
    
    if (centerData.services && centerData.services.length > 0) {
      centerData.services.forEach(service => {
        queries.push({
          query: 'INSERT INTO center_services (center_id, service_name) VALUES (?, ?)',
          params: [centerId, service]
        });
      });
    }
    
    const result = await executeTransaction(queries);
    if (result.success) {
      result.data = { id: centerId, ...centerData };
    }
    return result;
  }

  static async findById(id) {
    const query = `
      SELECT dc.*, 
             GROUP_CONCAT(cs.service_name) as services
      FROM diagnostic_centers dc
      LEFT JOIN center_services cs ON dc.id = cs.center_id
      WHERE dc.id = ?
      GROUP BY dc.id
    `;
    return executeQuery(query, [id]);
  }

  static async getAll(filters = {}) {
    let query = `
      SELECT dc.*, 
             GROUP_CONCAT(cs.service_name) as services
      FROM diagnostic_centers dc
      LEFT JOIN center_services cs ON dc.id = cs.center_id
    `;
    
    const conditions = [];
    const params = [];
    
    if (filters.city) {
      conditions.push('dc.city = ?');
      params.push(filters.city);
    }
    
    if (filters.state) {
      conditions.push('dc.state = ?');
      params.push(filters.state);
    }
    
    if (filters.subscriptionType) {
      conditions.push('dc.subscription_type = ?');
      params.push(filters.subscriptionType);
    }
    
    if (filters.isActive !== undefined) {
      conditions.push('dc.is_active = ?');
      params.push(filters.isActive);
    }
    
    if (conditions.length > 0) {
      query += ' WHERE ' + conditions.join(' AND ');
    }
    
    query += ' GROUP BY dc.id ORDER BY dc.created_date DESC';
    
    if (filters.limit) {
      query += ' LIMIT ?';
      params.push(parseInt(filters.limit));
    }
    
    return executeQuery(query, params);
  }

  static async update(id, updateData) {
    const fields = [];
    const params = [];
    
    const allowedFields = [
      'name', 'address', 'city', 'state', 'pincode', 'owner_name',
      'owner_phone', 'owner_email', 'subscription_type', 'website',
      'description', 'operating_hours', 'emergency_contact', 'is_active'
    ];
    
    allowedFields.forEach(field => {
      if (updateData[field] !== undefined) {
        fields.push(`${field} = ?`);
        params.push(updateData[field]);
      }
    });
    
    if (fields.length === 0) {
      return { success: false, error: 'No fields to update' };
    }
    
    params.push(id);
    const query = `UPDATE diagnostic_centers SET ${fields.join(', ')} WHERE id = ?`;
    
    return executeQuery(query, params);
  }

  static async getStats(centerId = null) {
    let query = `
      SELECT 
        COUNT(DISTINCT p.id) as total_patients,
        COUNT(DISTINCT tr.id) as total_reports,
        COUNT(DISTINCT b.id) as total_bills,
        SUM(CASE WHEN b.status = 'paid' THEN b.final_amount ELSE 0 END) as total_revenue
      FROM diagnostic_centers dc
      LEFT JOIN patients p ON dc.id = p.center_id
      LEFT JOIN test_reports tr ON dc.id = tr.center_id
      LEFT JOIN bills b ON dc.id = b.center_id
    `;
    
    const params = [];
    if (centerId) {
      query += ' WHERE dc.id = ?';
      params.push(centerId);
    }
    
    return executeQuery(query, params);
  }
}

// =====================================================
// PATIENT MODEL
// =====================================================
class PatientModel {
  static async create(patientData) {
    const patientId = uuidv4();
    
    const query = `
      INSERT INTO patients (
        id, full_name, email, phone, address, city, state, pincode,
        whatsapp_number, passcode, center_id, date_of_birth, gender,
        emergency_contact, blood_group, allergies
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;
    
    const params = [
      patientId, patientData.fullName, patientData.email, patientData.phone,
      patientData.address, patientData.city, patientData.state, patientData.pincode,
      patientData.whatsappNumber, patientData.passcode, patientData.centerId,
      patientData.dateOfBirth, patientData.gender, patientData.emergencyContact,
      patientData.bloodGroup, patientData.allergies
    ];
    
    const result = await executeQuery(query, params);
    if (result.success) {
      result.data = { id: patientId, ...patientData };
    }
    return result;
  }

  static async findById(id) {
    const query = `
      SELECT p.*, dc.name as center_name
      FROM patients p
      LEFT JOIN diagnostic_centers dc ON p.center_id = dc.id
      WHERE p.id = ?
    `;
    return executeQuery(query, [id]);
  }

  static async findByPasscode(passcode, centerId = null) {
    let query = `
      SELECT p.*, dc.name as center_name
      FROM patients p
      LEFT JOIN diagnostic_centers dc ON p.center_id = dc.id
      WHERE p.passcode = ?
    `;
    
    const params = [passcode];
    if (centerId) {
      query += ' AND p.center_id = ?';
      params.push(centerId);
    }
    
    return executeQuery(query, params);
  }

  static async getByCenterId(centerId, filters = {}) {
    let query = `
      SELECT p.*, dc.name as center_name
      FROM patients p
      LEFT JOIN diagnostic_centers dc ON p.center_id = dc.id
      WHERE p.center_id = ?
    `;
    
    const params = [centerId];
    
    if (filters.search) {
      query += ' AND (p.full_name LIKE ? OR p.phone LIKE ? OR p.email LIKE ?)';
      const searchTerm = `%${filters.search}%`;
      params.push(searchTerm, searchTerm, searchTerm);
    }
    
    query += ' ORDER BY p.created_date DESC';
    
    if (filters.limit) {
      query += ' LIMIT ?';
      params.push(parseInt(filters.limit));
    }
    
    return executeQuery(query, params);
  }

  static async update(id, updateData) {
    const fields = [];
    const params = [];
    
    const allowedFields = [
      'full_name', 'email', 'phone', 'address', 'city', 'state', 'pincode',
      'whatsapp_number', 'date_of_birth', 'gender', 'emergency_contact',
      'blood_group', 'allergies'
    ];
    
    allowedFields.forEach(field => {
      if (updateData[field] !== undefined) {
        fields.push(`${field} = ?`);
        params.push(updateData[field]);
      }
    });
    
    if (fields.length === 0) {
      return { success: false, error: 'No fields to update' };
    }
    
    params.push(id);
    const query = `UPDATE patients SET ${fields.join(', ')} WHERE id = ?`;
    
    return executeQuery(query, params);
  }

  static async generatePasscode() {
    let passcode;
    let exists = true;
    
    while (exists) {
      passcode = Math.floor(1000 + Math.random() * 9000).toString();
      const result = await executeQuery('SELECT id FROM patients WHERE passcode = ?', [passcode]);
      exists = result.success && result.data.length > 0;
    }
    
    return passcode;
  }
}

// =====================================================
// TEST REPORT MODEL
// =====================================================
class TestReportModel {
  static async create(reportData) {
    const reportId = uuidv4();
    
    const queries = [
      {
        query: `
          INSERT INTO test_reports (
            id, patient_id, center_id, test_type, test_name, referred_by,
            sample_date, report_date, passcode_id, status, notes, technician,
            verified_by, priority, sample_type, methodology
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `,
        params: [
          reportId, reportData.patientId, reportData.centerId, reportData.testType,
          reportData.testName, reportData.referredBy, reportData.sampleDate,
          reportData.reportDate, reportData.passcodeId, reportData.status,
          reportData.notes, reportData.technician, reportData.verifiedBy,
          reportData.priority, reportData.sampleType, reportData.methodology
        ]
      }
    ];
    
    // Add test results if provided
    if (reportData.results && reportData.results.length > 0) {
      reportData.results.forEach(result => {
        queries.push({
          query: `
            INSERT INTO test_results (
              report_id, parameter_name, value, unit, reference_range, status, flag
            ) VALUES (?, ?, ?, ?, ?, ?, ?)
          `,
          params: [
            reportId, result.parameter, result.value, result.unit,
            result.reference, result.status, result.flag
          ]
        });
      });
    }
    
    const result = await executeTransaction(queries);
    if (result.success) {
      result.data = { id: reportId, ...reportData };
    }
    return result;
  }

  static async findById(id) {
    const query = `
      SELECT tr.*, p.full_name as patient_name, dc.name as center_name
      FROM test_reports tr
      LEFT JOIN patients p ON tr.patient_id = p.id
      LEFT JOIN diagnostic_centers dc ON tr.center_id = dc.id
      WHERE tr.id = ?
    `;
    
    const reportResult = await executeQuery(query, [id]);
    
    if (reportResult.success && reportResult.data.length > 0) {
      const resultsQuery = 'SELECT * FROM test_results WHERE report_id = ?';
      const resultsData = await executeQuery(resultsQuery, [id]);
      
      if (resultsData.success) {
        reportResult.data[0].results = resultsData.data;
      }
    }
    
    return reportResult;
  }

  static async getByCenterId(centerId, filters = {}) {
    let query = `
      SELECT tr.*, p.full_name as patient_name, p.phone as patient_phone
      FROM test_reports tr
      LEFT JOIN patients p ON tr.patient_id = p.id
      WHERE tr.center_id = ?
    `;
    
    const params = [centerId];
    
    if (filters.status) {
      query += ' AND tr.status = ?';
      params.push(filters.status);
    }
    
    if (filters.startDate && filters.endDate) {
      query += ' AND tr.sample_date BETWEEN ? AND ?';
      params.push(filters.startDate, filters.endDate);
    }
    
    if (filters.search) {
      query += ' AND (tr.test_name LIKE ? OR p.full_name LIKE ? OR tr.passcode_id LIKE ?)';
      const searchTerm = `%${filters.search}%`;
      params.push(searchTerm, searchTerm, searchTerm);
    }
    
    query += ' ORDER BY tr.created_at DESC';
    
    if (filters.limit) {
      query += ' LIMIT ?';
      params.push(parseInt(filters.limit));
    }
    
    return executeQuery(query, params);
  }

  static async getByPatientId(patientId) {
    const query = `
      SELECT tr.*, dc.name as center_name
      FROM test_reports tr
      LEFT JOIN diagnostic_centers dc ON tr.center_id = dc.id
      WHERE tr.patient_id = ?
      ORDER BY tr.created_at DESC
    `;
    
    return executeQuery(query, [patientId]);
  }

  static async updateStatus(id, status, reportData = {}) {
    const fields = ['status = ?'];
    const params = [status];
    
    if (reportData.reportDate) {
      fields.push('report_date = ?');
      params.push(reportData.reportDate);
    }
    
    if (reportData.verifiedBy) {
      fields.push('verified_by = ?');
      params.push(reportData.verifiedBy);
    }
    
    if (reportData.notes) {
      fields.push('notes = ?');
      params.push(reportData.notes);
    }
    
    params.push(id);
    const query = `UPDATE test_reports SET ${fields.join(', ')}, updated_at = CURRENT_TIMESTAMP WHERE id = ?`;
    
    return executeQuery(query, params);
  }
}

// =====================================================
// BILL MODEL
// =====================================================
class BillModel {
  static async create(billData) {
    const billId = uuidv4();
    
    const queries = [
      {
        query: `
          INSERT INTO bills (
            id, patient_id, center_id, invoice_number, amount, discount,
            final_amount, status, payment_date, payment_mode, transaction_id,
            payment_notes, due_date, tax, total_tax, insurance_provider,
            insurance_policy_number, insurance_claim_amount
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `,
        params: [
          billId, billData.patientId, billData.centerId, billData.invoiceNumber,
          billData.amount, billData.discount, billData.finalAmount, billData.status,
          billData.paymentDate, billData.paymentMode, billData.transactionId,
          billData.paymentNotes, billData.dueDate, billData.tax, billData.totalTax,
          billData.insuranceProvider, billData.insurancePolicyNumber, billData.insuranceClaimAmount
        ]
      }
    ];
    
    // Add bill tests
    if (billData.tests && billData.tests.length > 0) {
      billData.tests.forEach(test => {
        queries.push({
          query: 'INSERT INTO bill_tests (bill_id, test_name, test_price) VALUES (?, ?, ?)',
          params: [billId, test.name, test.price || 0]
        });
      });
    }
    
    const result = await executeTransaction(queries);
    if (result.success) {
      result.data = { id: billId, ...billData };
    }
    return result;
  }

  static async findById(id) {
    const query = `
      SELECT b.*, p.full_name as patient_name, dc.name as center_name
      FROM bills b
      LEFT JOIN patients p ON b.patient_id = p.id
      LEFT JOIN diagnostic_centers dc ON b.center_id = dc.id
      WHERE b.id = ?
    `;
    
    const billResult = await executeQuery(query, [id]);
    
    if (billResult.success && billResult.data.length > 0) {
      const testsQuery = 'SELECT test_name, test_price FROM bill_tests WHERE bill_id = ?';
      const testsData = await executeQuery(testsQuery, [id]);
      
      if (testsData.success) {
        billResult.data[0].tests = testsData.data;
      }
    }
    
    return billResult;
  }

  static async getByCenterId(centerId, filters = {}) {
    let query = `
      SELECT b.*, p.full_name as patient_name, p.phone as patient_phone
      FROM bills b
      LEFT JOIN patients p ON b.patient_id = p.id
      WHERE b.center_id = ?
    `;
    
    const params = [centerId];
    
    if (filters.status) {
      query += ' AND b.status = ?';
      params.push(filters.status);
    }
    
    if (filters.startDate && filters.endDate) {
      query += ' AND b.created_date BETWEEN ? AND ?';
      params.push(filters.startDate, filters.endDate);
    }
    
    query += ' ORDER BY b.created_date DESC';
    
    if (filters.limit) {
      query += ' LIMIT ?';
      params.push(parseInt(filters.limit));
    }
    
    return executeQuery(query, params);
  }

  static async getByPatientId(patientId) {
    const query = `
      SELECT b.*, dc.name as center_name
      FROM bills b
      LEFT JOIN diagnostic_centers dc ON b.center_id = dc.id
      WHERE b.patient_id = ?
      ORDER BY b.created_date DESC
    `;
    
    return executeQuery(query, [patientId]);
  }

  static async updatePaymentStatus(id, status, paymentData = {}) {
    const fields = ['status = ?'];
    const params = [status];
    
    if (paymentData.paymentDate) {
      fields.push('payment_date = ?');
      params.push(paymentData.paymentDate);
    }
    
    if (paymentData.paymentMode) {
      fields.push('payment_mode = ?');
      params.push(paymentData.paymentMode);
    }
    
    if (paymentData.transactionId) {
      fields.push('transaction_id = ?');
      params.push(paymentData.transactionId);
    }
    
    if (paymentData.paymentNotes) {
      fields.push('payment_notes = ?');
      params.push(paymentData.paymentNotes);
    }
    
    params.push(id);
    const query = `UPDATE bills SET ${fields.join(', ')} WHERE id = ?`;
    
    return executeQuery(query, params);
  }

  static async generateInvoiceNumber(centerId) {
    const year = new Date().getFullYear();
    const query = `
      SELECT COUNT(*) as count 
      FROM bills 
      WHERE center_id = ? AND YEAR(created_date) = ?
    `;
    
    const result = await executeQuery(query, [centerId, year]);
    if (result.success) {
      const count = result.data[0].count + 1;
      return `INV-${year}-${String(count).padStart(4, '0')}`;
    }
    
    return `INV-${year}-0001`;
  }
}

module.exports = {
  UserModel,
  DiagnosticCenterModel,
  PatientModel,
  TestReportModel,
  BillModel
};