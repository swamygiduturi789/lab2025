-- =====================================================
-- MediLab India - Sample Data for Testing
-- =====================================================

USE medilab_india;

-- =====================================================
-- INSERT USERS
-- =====================================================
-- Super Admin
INSERT INTO users (id, username, password, role, name, phone) VALUES
('1', 'superadmin', '$2b$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'super_admin', 'System Administrator', '+91-9876543210');

-- Diagnostic Center Users
INSERT INTO users (id, username, password, role, name, phone, center_name) VALUES
('2', 'apollo_mumbai', '$2b$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'diagnostic_center', 'Dr. Rajesh Kumar', '+91-9876543211', 'Apollo Diagnostics Mumbai'),
('3', 'lifelab_delhi', '$2b$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'diagnostic_center', 'Dr. Priya Sharma', '+91-9876543212', 'LifeLab Diagnostics Delhi'),
('4', 'metropolis_bangalore', '$2b$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'diagnostic_center', 'Dr. Amit Patel', '+91-9876543213', 'Metropolis Healthcare Bangalore');

-- Patient Users
INSERT INTO users (id, username, password, role, name, phone) VALUES
('5', 'patient_001', '$2b$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'patient', 'Rahul Verma', '+91-9876543214'),
('6', 'patient_002', '$2b$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'patient', 'Sneha Agarwal', '+91-9876543215'),
('7', 'patient_003', '$2b$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'patient', 'Arjun Singh', '+91-9876543216');

-- =====================================================
-- INSERT DIAGNOSTIC CENTERS
-- =====================================================
INSERT INTO diagnostic_centers (
    id, name, address, city, state, pincode, owner_name, owner_phone, owner_email,
    owner_address, owner_city, owner_state, subscription_type, username, password,
    license_number, registration_number, website, description, operating_hours, emergency_contact
) VALUES
('center_1', 'Apollo Diagnostics Mumbai', '123 MG Road, Fort', 'Mumbai', 'Maharashtra', '400001',
 'Dr. Rajesh Kumar', '+91-9876543211', 'rajesh@apollodiagnostics.com',
 '456 Bandra West', 'Mumbai', 'Maharashtra', 'gold', 'apollo_mumbai',
 '$2b$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',
 'MH/MUM/2024/001', 'REG/MH/2024/001', 'https://apollodiagnostics.com',
 'Leading diagnostic center in Mumbai with state-of-the-art facilities', 
 'Mon-Sat: 7:00 AM - 9:00 PM, Sun: 8:00 AM - 6:00 PM', '+91-9876543299'),

('center_2', 'LifeLab Diagnostics Delhi', '789 Connaught Place', 'New Delhi', 'Delhi', '110001',
 'Dr. Priya Sharma', '+91-9876543212', 'priya@lifelab.com',
 '321 Greater Kailash', 'New Delhi', 'Delhi', 'standard', 'lifelab_delhi',
 '$2b$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',
 'DL/DEL/2024/002', 'REG/DL/2024/002', 'https://lifelab.com',
 'Comprehensive diagnostic services with advanced technology',
 'Mon-Fri: 8:00 AM - 8:00 PM, Sat-Sun: 9:00 AM - 5:00 PM', '+91-9876543298'),

('center_3', 'Metropolis Healthcare Bangalore', '456 Brigade Road', 'Bangalore', 'Karnataka', '560001',
 'Dr. Amit Patel', '+91-9876543213', 'amit@metropolis.com',
 '789 Koramangala', 'Bangalore', 'Karnataka', 'free', 'metropolis_bangalore',
 '$2b$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',
 'KA/BLR/2024/003', 'REG/KA/2024/003', 'https://metropolis.com',
 'Trusted healthcare partner with nationwide presence',
 'Mon-Sat: 6:00 AM - 10:00 PM, Sun: 7:00 AM - 7:00 PM', '+91-9876543297');

-- =====================================================
-- INSERT CENTER SERVICES
-- =====================================================
INSERT INTO center_services (center_id, service_name) VALUES
('center_1', 'Blood Tests'), ('center_1', 'Urine Analysis'), ('center_1', 'X-Ray'), ('center_1', 'ECG'),
('center_1', 'Ultrasound'), ('center_1', 'CT Scan'), ('center_1', 'MRI'), ('center_1', 'Pathology'),
('center_2', 'Blood Tests'), ('center_2', 'Urine Analysis'), ('center_2', 'ECG'), ('center_2', 'Ultrasound'),
('center_2', 'Pathology'), ('center_2', 'Microbiology'), ('center_2', 'Biochemistry'),
('center_3', 'Blood Tests'), ('center_3', 'Urine Analysis'), ('center_3', 'X-Ray'), ('center_3', 'ECG'),
('center_3', 'Pathology'), ('center_3', 'Cardiology Tests');

-- =====================================================
-- INSERT PATIENTS
-- =====================================================
INSERT INTO patients (
    id, full_name, email, phone, address, city, state, pincode, whatsapp_number, 
    passcode, center_id, date_of_birth, gender, blood_group
) VALUES
('patient_1', 'Rahul Verma', 'rahul.verma@email.com', '+91-9876543214', 
 '123 Linking Road, Bandra', 'Mumbai', 'Maharashtra', '400050', '+91-9876543214',
 '1234', 'center_1', '1990-05-15', 'male', 'O+'),

('patient_2', 'Sneha Agarwal', 'sneha.agarwal@email.com', '+91-9876543215',
 '456 Khan Market', 'New Delhi', 'Delhi', '110003', '+91-9876543215',
 '5678', 'center_2', '1985-08-22', 'female', 'A+'),

('patient_3', 'Arjun Singh', 'arjun.singh@email.com', '+91-9876543216',
 '789 MG Road', 'Bangalore', 'Karnataka', '560001', '+91-9876543216',
 '9012', 'center_3', '1992-12-10', 'male', 'B+'),

('patient_4', 'Maya Patel', 'maya.patel@email.com', '+91-9876543217',
 '321 Juhu Beach Road', 'Mumbai', 'Maharashtra', '400049', '+91-9876543217',
 '3456', 'center_1', '1988-03-18', 'female', 'AB+'),

('patient_5', 'Vikram Gupta', 'vikram.gupta@email.com', '+91-9876543218',
 '654 Lajpat Nagar', 'New Delhi', 'Delhi', '110024', '+91-9876543218',
 '7890', 'center_2', '1995-11-05', 'male', 'O-');

-- =====================================================
-- INSERT TEST REPORTS
-- =====================================================
INSERT INTO test_reports (
    id, patient_id, center_id, test_type, test_name, referred_by, sample_date, 
    report_date, passcode_id, status, technician, verified_by, priority
) VALUES
('report_1', 'patient_1', 'center_1', 'Blood Test', 'Complete Blood Count (CBC)', 
 'Dr. Smith', '2024-06-15', '2024-06-16', 'PC001', 'completed', 
 'Tech. Ravi Kumar', 'Dr. Rajesh Kumar', 'normal'),

('report_2', 'patient_2', 'center_2', 'Urine Test', 'Urine Routine & Microscopy',
 'Dr. Johnson', '2024-06-14', '2024-06-15', 'PC002', 'completed',
 'Tech. Sunita Sharma', 'Dr. Priya Sharma', 'normal'),

('report_3', 'patient_3', 'center_3', 'Blood Test', 'Lipid Profile',
 'Dr. Brown', '2024-06-13', '2024-06-14', 'PC003', 'completed',
 'Tech. Ramesh Patel', 'Dr. Amit Patel', 'urgent'),

('report_4', 'patient_1', 'center_1', 'Blood Test', 'Liver Function Test',
 'Dr. Wilson', '2024-06-12', NULL, 'PC004', 'pending',
 'Tech. Ravi Kumar', NULL, 'normal'),

('report_5', 'patient_4', 'center_1', 'Radiology', 'Chest X-Ray',
 'Dr. Davis', '2024-06-11', '2024-06-12', 'PC005', 'completed',
 'Tech. Neha Joshi', 'Dr. Rajesh Kumar', 'stat');

-- =====================================================
-- INSERT TEST RESULTS
-- =====================================================
INSERT INTO test_results (report_id, parameter_name, value, unit, reference_range, status) VALUES
-- CBC Results for report_1
('report_1', 'Hemoglobin', '13.5', 'g/dL', '12.0-15.5', 'normal'),
('report_1', 'RBC Count', '4.2', 'million/µL', '3.8-5.2', 'normal'),
('report_1', 'WBC Count', '6800', '/µL', '4000-11000', 'normal'),
('report_1', 'Platelet Count', '285000', '/µL', '150000-450000', 'normal'),
('report_1', 'Hematocrit', '41.2', '%', '36-46', 'normal'),

-- Lipid Profile Results for report_3
('report_3', 'Total Cholesterol', '185', 'mg/dL', '<200', 'normal'),
('report_3', 'LDL Cholesterol', '110', 'mg/dL', '<100', 'abnormal'),
('report_3', 'HDL Cholesterol', '45', 'mg/dL', '>40', 'normal'),
('report_3', 'Triglycerides', '150', 'mg/dL', '<150', 'normal');

-- =====================================================
-- INSERT BILLS
-- =====================================================
INSERT INTO bills (
    id, patient_id, center_id, invoice_number, amount, discount, final_amount,
    status, payment_date, payment_mode, transaction_id, tax, total_tax, due_date
) VALUES
('bill_1', 'patient_1', 'center_1', 'INV-2024-001', 1500.00, 150.00, 1485.00,
 'paid', '2024-06-16', 'upi', 'TXN123456789', 135.00, 135.00, '2024-06-20'),

('bill_2', 'patient_2', 'center_2', 'INV-2024-002', 800.00, 0.00, 880.00,
 'pending', NULL, NULL, NULL, 80.00, 80.00, '2024-06-19'),

('bill_3', 'patient_3', 'center_3', 'INV-2024-003', 1200.00, 100.00, 1210.00,
 'paid', '2024-06-14', 'card', 'TXN987654321', 110.00, 110.00, '2024-06-18'),

('bill_4', 'patient_4', 'center_1', 'INV-2024-004', 600.00, 50.00, 605.00,
 'partially_paid', NULL, NULL, NULL, 55.00, 55.00, '2024-06-21'),

('bill_5', 'patient_5', 'center_2', 'INV-2024-005', 2000.00, 200.00, 1980.00,
 'pending', NULL, NULL, NULL, 180.00, 180.00, '2024-06-25');

-- =====================================================
-- INSERT BILL TESTS
-- =====================================================
INSERT INTO bill_tests (bill_id, test_name, test_price) VALUES
('bill_1', 'Complete Blood Count (CBC)', 500.00),
('bill_1', 'Blood Sugar Fasting', 150.00),
('bill_1', 'Urine Routine', 300.00),
('bill_1', 'ECG', 550.00),

('bill_2', 'Urine Routine & Microscopy', 300.00),
('bill_2', 'Blood Pressure Check', 100.00),
('bill_2', 'Basic Health Checkup', 400.00),

('bill_3', 'Lipid Profile', 800.00),
('bill_3', 'Liver Function Test', 400.00),

('bill_4', 'Chest X-Ray', 400.00),
('bill_4', 'ECG', 200.00),

('bill_5', 'Comprehensive Health Package', 2000.00);

-- =====================================================
-- INSERT CENTER PROFILES
-- =====================================================
INSERT INTO center_profiles (
    id, center_id, tagline, license_number, registration_number, website,
    description, operating_hours, emergency_contact, facebook_url, instagram_url
) VALUES
('profile_1', 'center_1', 'Your Health, Our Priority', 'MH/MUM/2024/001', 'REG/MH/2024/001',
 'https://apollodiagnostics.com', 'Leading diagnostic center in Mumbai with state-of-the-art facilities and experienced medical professionals.',
 'Mon-Sat: 7:00 AM - 9:00 PM, Sun: 8:00 AM - 6:00 PM', '+91-9876543299',
 'https://facebook.com/apollodiagnostics', 'https://instagram.com/apollodiagnostics'),

('profile_2', 'center_2', 'Advanced Diagnostics, Personalized Care', 'DL/DEL/2024/002', 'REG/DL/2024/002',
 'https://lifelab.com', 'Comprehensive diagnostic services with advanced technology and personalized patient care.',
 'Mon-Fri: 8:00 AM - 8:00 PM, Sat-Sun: 9:00 AM - 5:00 PM', '+91-9876543298',
 'https://facebook.com/lifelab', 'https://instagram.com/lifelab'),

('profile_3', 'center_3', 'Trusted Healthcare Partner', 'KA/BLR/2024/003', 'REG/KA/2024/003',
 'https://metropolis.com', 'Trusted healthcare partner with nationwide presence and commitment to quality.',
 'Mon-Sat: 6:00 AM - 10:00 PM, Sun: 7:00 AM - 7:00 PM', '+91-9876543297',
 'https://facebook.com/metropolis', 'https://instagram.com/metropolis');

-- =====================================================
-- INSERT CENTER PROFILE SERVICES
-- =====================================================
INSERT INTO center_profile_services (profile_id, service_name) VALUES
('profile_1', 'Complete Blood Count'), ('profile_1', 'Lipid Profile'), ('profile_1', 'Liver Function Test'),
('profile_1', 'Kidney Function Test'), ('profile_1', 'Thyroid Profile'), ('profile_1', 'Diabetes Screening'),
('profile_1', 'ECG'), ('profile_1', 'Chest X-Ray'), ('profile_1', 'Ultrasound Abdomen'),
('profile_2', 'Comprehensive Health Checkup'), ('profile_2', 'Cardiac Profile'), ('profile_2', 'Diabetes Panel'),
('profile_2', 'Anemia Profile'), ('profile_2', 'Allergy Testing'), ('profile_2', 'Hormone Testing'),
('profile_3', 'Preventive Health Checkup'), ('profile_3', 'Women Health Package'), ('profile_3', 'Executive Health Checkup'),
('profile_3', 'Senior Citizen Package'), ('profile_3', 'Fitness Package');

-- =====================================================
-- INSERT CENTER CERTIFICATIONS
-- =====================================================
INSERT INTO center_certifications (profile_id, certification_name, issuing_authority, issue_date, expiry_date) VALUES
('profile_1', 'ISO 15189:2012', 'Bureau of Indian Standards', '2023-01-15', '2026-01-14'),
('profile_1', 'NABL Accreditation', 'National Accreditation Board for Testing', '2023-03-20', '2026-03-19'),
('profile_1', 'CAP Certification', 'College of American Pathologists', '2023-05-10', '2025-05-09'),
('profile_2', 'ISO 15189:2012', 'Bureau of Indian Standards', '2023-02-10', '2026-02-09'),
('profile_2', 'NABL Accreditation', 'National Accreditation Board for Testing', '2023-04-15', '2026-04-14'),
('profile_3', 'ISO 9001:2015', 'Bureau of Indian Standards', '2023-01-20', '2026-01-19'),
('profile_3', 'NABL Accreditation', 'National Accreditation Board for Testing', '2023-06-01', '2026-05-31');

-- =====================================================
-- INSERT CENTER ACCREDITATIONS
-- =====================================================
INSERT INTO center_accreditations (profile_id, accreditation_name, accrediting_body, accreditation_date, validity_period) VALUES
('profile_1', 'Joint Commission International', 'JCI', '2023-07-15', '3 Years'),
('profile_1', 'National Quality Assurance Standards', 'NQAS', '2023-08-20', '2 Years'),
('profile_2', 'Quality Council of India', 'QCI', '2023-09-10', '3 Years'),
('profile_2', 'Indian Medical Association', 'IMA', '2023-10-05', '1 Year'),
('profile_3', 'Healthcare Quality Assessment', 'HQA', '2023-11-15', '2 Years'),
('profile_3', 'Medical Council Accreditation', 'MCI', '2023-12-01', '3 Years');

-- =====================================================
-- INSERT SYSTEM SETTINGS
-- =====================================================
INSERT INTO system_settings (setting_key, setting_value, setting_type, description, is_public) VALUES
('app_name', 'MediLab India', 'string', 'Application name', TRUE),
('app_version', '1.0.0', 'string', 'Current application version', TRUE),
('default_currency', 'INR', 'string', 'Default currency for billing', TRUE),
('default_country', 'India', 'string', 'Default country', TRUE),
('max_file_upload_size', '10485760', 'number', 'Maximum file upload size in bytes (10MB)', FALSE),
('session_timeout', '3600', 'number', 'Session timeout in seconds', FALSE),
('enable_email_notifications', 'true', 'boolean', 'Enable email notifications', FALSE),
('enable_sms_notifications', 'true', 'boolean', 'Enable SMS notifications', FALSE),
('backup_retention_days', '30', 'number', 'Number of days to retain backups', FALSE),
('default_timezone', 'Asia/Kolkata', 'string', 'Default timezone', TRUE);

-- =====================================================
-- INSERT SAMPLE REPORT EXPORTS
-- =====================================================
INSERT INTO report_exports (
    id, center_id, report_type, period_type, start_date, end_date, 
    status, download_url
) VALUES
('export_1', 'center_1', 'patients', 'monthly', '2024-06-01', '2024-06-30', 'ready',
 '/exports/patients_center_1_202406.pdf'),
('export_2', 'center_2', 'bills', 'weekly', '2024-06-10', '2024-06-16', 'ready',
 '/exports/bills_center_2_week25.pdf'),
('export_3', 'center_3', 'comprehensive', 'monthly', '2024-05-01', '2024-05-31', 'expired',
 '/exports/comprehensive_center_3_202405.pdf');