const { executeQuery, executeTransaction } = require('./connection');
const bcrypt = require('bcrypt');

// Admin accounts configuration
const ADMIN_ACCOUNTS = [
  {
    username: 'superadmin',
    password: 'password', // Change this in production!
    role: 'super_admin',
    name: 'Super Administrator',
    email: 'admin@medilab-india.com',
    phone: '+91 9876543210',
    isActive: true
  },
  {
    username: 'admin',
    password: 'admin123',
    role: 'super_admin',
    name: 'System Admin',
    email: 'system@medilab-india.com',
    phone: '+91 9876543211',
    isActive: true
  }
];

// Demo diagnostic center account
const DEMO_CENTER = {
  name: 'MediLab Test Center',
  address: '123 Healthcare Street',
  city: 'Mumbai',
  state: 'Maharashtra',
  pincode: '400001',
  phone: '+91 9876543212',
  email: 'testcenter@medilab-india.com',
  ownerName: 'Dr. Rajesh Kumar',
  ownerPhone: '+91 9876543213',
  ownerEmail: 'owner@testcenter.com',
  ownerAddress: '456 Doctor Lane',
  ownerCity: 'Mumbai',
  ownerState: 'Maharashtra',
  subscriptionType: 'gold',
  paymentType: 'online',
  username: 'testcenter',
  password: 'password',
  isActive: true,
  licenseNumber: 'MH-LAB-2024-001',
  registrationNumber: 'REG-2024-001',
  website: 'https://testcenter.medilab-india.com',
  description: 'Premier diagnostic center with state-of-the-art equipment',
  services: ['Blood Tests', 'Urine Tests', 'X-Ray', 'ECG', 'Ultrasound'],
  operatingHours: 'Mon-Sat: 8:00 AM - 8:00 PM, Sun: 9:00 AM - 5:00 PM',
  emergencyContact: '+91 9876543214'
};

// Demo patient account
const DEMO_PATIENT = {
  fullName: 'Priya Sharma',
  email: 'patient@medilab-india.com',
  phone: '+91 9876543215',
  address: '789 Patient Street',
  city: 'Mumbai',
  state: 'Maharashtra',
  pincode: '400002',
  whatsappNumber: '+91 9876543215',
  passcode: 'PATIENT123',
  dateOfBirth: '1990-05-15',
  gender: 'female',
  emergencyContact: '+91 9876543216',
  bloodGroup: 'B+',
  allergies: 'None',
  username: 'patient',
  password: 'password'
};

async function createAdminAccounts() {
  console.log('🔧 Initializing admin accounts...');
  
  try {
    // Hash passwords for admin accounts
    const adminQueries = [];
    
    for (const admin of ADMIN_ACCOUNTS) {
      const hashedPassword = await bcrypt.hash(admin.password, 12);
      
      // Check if admin already exists
      const existingAdmin = await executeQuery(
        'SELECT id FROM users WHERE username = ?',
        [admin.username]
      );
      
      if (existingAdmin.success && existingAdmin.data.length === 0) {
        adminQueries.push({
          query: `
            INSERT INTO users (username, password, role, name, email, phone, is_active, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
          `,
          params: [
            admin.username,
            hashedPassword,
            admin.role,
            admin.name,
            admin.email,
            admin.phone,
            admin.isActive
          ]
        });
      }
    }
    
    if (adminQueries.length > 0) {
      const adminResult = await executeTransaction(adminQueries);
      if (adminResult.success) {
        console.log(`✅ Created ${adminQueries.length} admin account(s)`);
      } else {
        console.error('❌ Failed to create admin accounts:', adminResult.error);
        return false;
      }
    } else {
      console.log('ℹ️ Admin accounts already exist');
    }
    
    return true;
  } catch (error) {
    console.error('❌ Error creating admin accounts:', error);
    return false;
  }
}

async function createDemoCenter() {
  console.log('🏥 Creating demo diagnostic center...');
  
  try {
    // Check if demo center already exists
    const existingCenter = await executeQuery(
      'SELECT id FROM diagnostic_centers WHERE name = ?',
      [DEMO_CENTER.name]
    );
    
    if (existingCenter.success && existingCenter.data.length > 0) {
      console.log('ℹ️ Demo center already exists');
      return existingCenter.data[0].id;
    }
    
    // Hash password for center user
    const hashedPassword = await bcrypt.hash(DEMO_CENTER.password, 12);
    
    // Create diagnostic center and user in transaction
    const centerQueries = [
      {
        query: `
          INSERT INTO diagnostic_centers (
            name, address, city, state, pincode, phone, email,
            owner_name, owner_phone, owner_email, owner_address, owner_city, owner_state,
            subscription_type, payment_type, is_active, created_date,
            license_number, registration_number, website, description,
            services, operating_hours, emergency_contact
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), ?, ?, ?, ?, ?, ?, ?)
        `,
        params: [
          DEMO_CENTER.name, DEMO_CENTER.address, DEMO_CENTER.city, DEMO_CENTER.state,
          DEMO_CENTER.pincode, DEMO_CENTER.phone, DEMO_CENTER.email,
          DEMO_CENTER.ownerName, DEMO_CENTER.ownerPhone, DEMO_CENTER.ownerEmail,
          DEMO_CENTER.ownerAddress, DEMO_CENTER.ownerCity, DEMO_CENTER.ownerState,
          DEMO_CENTER.subscriptionType, DEMO_CENTER.paymentType, DEMO_CENTER.isActive,
          DEMO_CENTER.licenseNumber, DEMO_CENTER.registrationNumber, DEMO_CENTER.website,
          DEMO_CENTER.description, JSON.stringify(DEMO_CENTER.services),
          DEMO_CENTER.operatingHours, DEMO_CENTER.emergencyContact
        ]
      }
    ];
    
    const centerResult = await executeTransaction(centerQueries);
    if (!centerResult.success) {
      console.error('❌ Failed to create demo center:', centerResult.error);
      return null;
    }
    
    // Get the created center ID
    const centerQuery = await executeQuery(
      'SELECT id FROM diagnostic_centers WHERE name = ?',
      [DEMO_CENTER.name]
    );
    
    if (!centerQuery.success || centerQuery.data.length === 0) {
      console.error('❌ Failed to retrieve created center ID');
      return null;
    }
    
    const centerId = centerQuery.data[0].id;
    
    // Create user account for the center
    const userQuery = await executeQuery(
      `
        INSERT INTO users (username, password, role, name, email, phone, center_id, is_active, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
      `,
      [
        DEMO_CENTER.username,
        hashedPassword,
        'diagnostic_center',
        DEMO_CENTER.ownerName,
        DEMO_CENTER.ownerEmail,
        DEMO_CENTER.ownerPhone,
        centerId,
        DEMO_CENTER.isActive
      ]
    );
    
    if (userQuery.success) {
      console.log('✅ Created demo diagnostic center and user account');
      return centerId;
    } else {
      console.error('❌ Failed to create center user account:', userQuery.error);
      return null;
    }
    
  } catch (error) {
    console.error('❌ Error creating demo center:', error);
    return null;
  }
}

async function createDemoPatient(centerId) {
  console.log('👤 Creating demo patient...');
  
  try {
    // Check if demo patient already exists
    const existingPatient = await executeQuery(
      'SELECT id FROM patients WHERE phone = ?',
      [DEMO_PATIENT.phone]
    );
    
    if (existingPatient.success && existingPatient.data.length > 0) {
      console.log('ℹ️ Demo patient already exists');
      return existingPatient.data[0].id;
    }
    
    // Create patient
    const patientResult = await executeQuery(
      `
        INSERT INTO patients (
          full_name, email, phone, address, city, state, pincode,
          whatsapp_number, passcode, center_id, created_date,
          date_of_birth, gender, emergency_contact, blood_group, allergies
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), ?, ?, ?, ?, ?)
      `,
      [
        DEMO_PATIENT.fullName, DEMO_PATIENT.email, DEMO_PATIENT.phone,
        DEMO_PATIENT.address, DEMO_PATIENT.city, DEMO_PATIENT.state,
        DEMO_PATIENT.pincode, DEMO_PATIENT.whatsappNumber, DEMO_PATIENT.passcode,
        centerId, DEMO_PATIENT.dateOfBirth, DEMO_PATIENT.gender,
        DEMO_PATIENT.emergencyContact, DEMO_PATIENT.bloodGroup, DEMO_PATIENT.allergies
      ]
    );
    
    if (!patientResult.success) {
      console.error('❌ Failed to create demo patient:', patientResult.error);
      return null;
    }
    
    // Get the created patient ID
    const patientQuery = await executeQuery(
      'SELECT id FROM patients WHERE phone = ?',
      [DEMO_PATIENT.phone]
    );
    
    if (!patientQuery.success || patientQuery.data.length === 0) {
      console.error('❌ Failed to retrieve created patient ID');
      return null;
    }
    
    const patientId = patientQuery.data[0].id;
    
    // Hash password for patient user
    const hashedPassword = await bcrypt.hash(DEMO_PATIENT.password, 12);
    
    // Create user account for the patient
    const userResult = await executeQuery(
      `
        INSERT INTO users (username, password, role, name, email, phone, patient_id, is_active, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
      `,
      [
        DEMO_PATIENT.username,
        hashedPassword,
        'patient',
        DEMO_PATIENT.fullName,
        DEMO_PATIENT.email,
        DEMO_PATIENT.phone,
        patientId,
        true
      ]
    );
    
    if (userResult.success) {
      console.log('✅ Created demo patient and user account');
      return patientId;
    } else {
      console.error('❌ Failed to create patient user account:', userResult.error);
      return null;
    }
    
  } catch (error) {
    console.error('❌ Error creating demo patient:', error);
    return null;
  }
}

async function createDemoData(centerId, patientId) {
  console.log('📊 Creating demo test reports and bills...');
  
  try {
    // Create demo test report
    const reportResult = await executeQuery(
      `
        INSERT INTO test_reports (
          patient_id, center_id, test_type, test_name, referred_by,
          sample_date, report_date, passcode_id, status, priority,
          sample_type, methodology, notes, technician, verified_by, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
      `,
      [
        patientId, centerId, 'Blood Test', 'Complete Blood Count (CBC)',
        'Dr. Amit Patel', '2024-01-15', '2024-01-16', 'RPT001',
        'completed', 'normal', 'Blood', 'Automated Analyzer',
        'All parameters within normal range', 'Tech. Suresh Kumar',
        'Dr. Rajesh Kumar'
      ]
    );
    
    if (reportResult.success) {
      // Get the report ID and add test results
      const reportQuery = await executeQuery(
        'SELECT id FROM test_reports WHERE passcode_id = ?',
        ['RPT001']
      );
      
      if (reportQuery.success && reportQuery.data.length > 0) {
        const reportId = reportQuery.data[0].id;
        
        // Add test results
        const testResults = [
          ['Hemoglobin', '13.5', 'g/dL', '12.0-16.0', 'normal'],
          ['RBC Count', '4.8', 'million/μL', '4.5-5.5', 'normal'],
          ['WBC Count', '7200', '/μL', '4000-11000', 'normal'],
          ['Platelets', '285000', '/μL', '150000-450000', 'normal']
        ];
        
        for (const result of testResults) {
          await executeQuery(
            `
              INSERT INTO test_results (
                report_id, parameter_name, value, unit, reference_range, status
              ) VALUES (?, ?, ?, ?, ?, ?)
            `,
            [reportId, ...result]
          );
        }
      }
      
      console.log('✅ Created demo test report with results');
    }
    
    // Create demo bill
    const billResult = await executeQuery(
      `
        INSERT INTO bills (
          patient_id, center_id, invoice_number, amount, discount,
          tax, total_tax, final_amount, status, payment_mode,
          payment_date, created_date, due_date
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), ?)
      `,
      [
        patientId, centerId, 'INV-2024-001', 1500.00, 150.00,
        135.00, 135.00, 1485.00, 'paid', 'upi',
        '2024-01-16', '2024-01-30'
      ]
    );
    
    if (billResult.success) {
      // Get the bill ID and add test items
      const billQuery = await executeQuery(
        'SELECT id FROM bills WHERE invoice_number = ?',
        ['INV-2024-001']
      );
      
      if (billQuery.success && billQuery.data.length > 0) {
        const billId = billQuery.data[0].id;
        
        // Add bill tests
        const billTests = [
          ['Complete Blood Count (CBC)', 800.00],
          ['Lipid Profile', 600.00],
          ['Liver Function Test', 400.00]
        ];
        
        for (const test of billTests) {
          await executeQuery(
            'INSERT INTO bill_tests (bill_id, test_name, test_price) VALUES (?, ?, ?)',
            [billId, ...test]
          );
        }
      }
      
      console.log('✅ Created demo bill with test items');
    }
    
  } catch (error) {
    console.error('❌ Error creating demo data:', error);
  }
}

async function initializeAdminAccountsAndData() {
  console.log('🚀 Starting admin accounts and demo data initialization...\n');
  
  try {
    // Step 1: Create admin accounts
    const adminSuccess = await createAdminAccounts();
    if (!adminSuccess) {
      console.error('❌ Failed to create admin accounts');
      return false;
    }
    
    // Step 2: Create demo diagnostic center
    const centerId = await createDemoCenter();
    if (!centerId) {
      console.error('❌ Failed to create demo center');
      return false;
    }
    
    // Step 3: Create demo patient
    const patientId = await createDemoPatient(centerId);
    if (!patientId) {
      console.error('❌ Failed to create demo patient');
      return false;
    }
    
    // Step 4: Create demo data
    await createDemoData(centerId, patientId);
    
    console.log('\n🎉 Admin accounts and demo data initialization completed successfully!');
    console.log('\n📋 Login Credentials:');
    console.log('┌─────────────────────────────────────────────────────────────┐');
    console.log('│ Role             │ Username     │ Password                   │');
    console.log('├─────────────────────────────────────────────────────────────┤');
    console.log('│ Super Admin      │ superadmin   │ password                   │');
    console.log('│ Super Admin      │ admin        │ admin123                   │');
    console.log('│ Diagnostic Center│ testcenter   │ password                   │');
    console.log('│ Patient          │ patient      │ password                   │');
    console.log('└─────────────────────────────────────────────────────────────┘');
    console.log('\n⚠️  IMPORTANT: Change default passwords in production!');
    
    return true;
    
  } catch (error) {
    console.error('❌ Error during initialization:', error);
    return false;
  }
}

// Run if called directly
if (require.main === module) {
  initializeAdminAccountsAndData()
    .then(success => {
      process.exit(success ? 0 : 1);
    })
    .catch(error => {
      console.error('Fatal error:', error);
      process.exit(1);
    });
}

module.exports = {
  initializeAdminAccountsAndData,
  createAdminAccounts,
  createDemoCenter,
  createDemoPatient,
  createDemoData
};