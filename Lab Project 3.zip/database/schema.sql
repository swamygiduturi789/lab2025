-- =====================================================
-- Composcale.com - Diagnostic Center Management System
-- MySQL Database Schema
-- =====================================================

-- Create Database
CREATE DATABASE IF NOT EXISTS composcale_com CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE composcale_com;

-- =====================================================
-- USERS TABLE
-- =====================================================
CREATE TABLE users (
    id VARCHAR(36) PRIMARY KEY DEFAULT (UUID()),
    username VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL, -- Will store hashed passwords
    role ENUM('super_admin', 'diagnostic_center', 'patient') NOT NULL,
    name VARCHAR(255) NOT NULL,
    phone VARCHAR(20),
    center_name VARCHAR(255), -- For diagnostic center users
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    INDEX idx_username (username),
    INDEX idx_role (role),
    INDEX idx_created_at (created_at)
);

-- =====================================================
-- DIAGNOSTIC CENTERS TABLE
-- =====================================================
CREATE TABLE diagnostic_centers (
    id VARCHAR(36) PRIMARY KEY DEFAULT (UUID()),
    name VARCHAR(255) NOT NULL,
    address TEXT NOT NULL,
    city VARCHAR(100) NOT NULL,
    state VARCHAR(100) NOT NULL,
    pincode VARCHAR(10) NOT NULL,
    owner_name VARCHAR(255) NOT NULL,
    owner_phone VARCHAR(20) NOT NULL,
    owner_email VARCHAR(255) NOT NULL,
    owner_address TEXT,
    owner_city VARCHAR(100),
    owner_state VARCHAR(100),
    subscription_type ENUM('free', 'standard', 'gold') DEFAULT 'free',
    payment_type ENUM('online') DEFAULT 'online',
    username VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL, -- Will store hashed passwords
    is_active BOOLEAN DEFAULT TRUE,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    -- New profile fields
    logo TEXT, -- URL or base64 string
    license_number VARCHAR(100),
    registration_number VARCHAR(100),
    website VARCHAR(255),
    description TEXT,
    operating_hours TEXT,
    emergency_contact VARCHAR(20),
    
    INDEX idx_name (name),
    INDEX idx_city_state (city, state),
    INDEX idx_subscription_type (subscription_type),
    INDEX idx_is_active (is_active),
    INDEX idx_created_date (created_date),
    
    FOREIGN KEY (username) REFERENCES users(username) ON DELETE CASCADE
);

-- =====================================================
-- DIAGNOSTIC CENTER SERVICES TABLE
-- =====================================================
CREATE TABLE center_services (
    id VARCHAR(36) PRIMARY KEY DEFAULT (UUID()),
    center_id VARCHAR(36) NOT NULL,
    service_name VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (center_id) REFERENCES diagnostic_centers(id) ON DELETE CASCADE,
    INDEX idx_center_id (center_id)
);

-- =====================================================
-- PATIENTS TABLE
-- =====================================================
CREATE TABLE patients (
    id VARCHAR(36) PRIMARY KEY DEFAULT (UUID()),
    full_name VARCHAR(255) NOT NULL,
    email VARCHAR(255),
    phone VARCHAR(20) NOT NULL,
    address TEXT NOT NULL,
    city VARCHAR(100) NOT NULL,
    state VARCHAR(100) NOT NULL,
    pincode VARCHAR(10) NOT NULL,
    whatsapp_number VARCHAR(20),
    passcode VARCHAR(10) NOT NULL,
    center_id VARCHAR(36) NOT NULL,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    -- New fields
    date_of_birth DATE,
    gender ENUM('male', 'female', 'other'),
    emergency_contact VARCHAR(20),
    blood_group VARCHAR(5),
    allergies TEXT,
    
    INDEX idx_full_name (full_name),
    INDEX idx_phone (phone),
    INDEX idx_passcode (passcode),
    INDEX idx_center_id (center_id),
    INDEX idx_created_date (created_date),
    
    FOREIGN KEY (center_id) REFERENCES diagnostic_centers(id) ON DELETE CASCADE
);

-- =====================================================
-- TEST REPORTS TABLE
-- =====================================================
CREATE TABLE test_reports (
    id VARCHAR(36) PRIMARY KEY DEFAULT (UUID()),
    patient_id VARCHAR(36) NOT NULL,
    center_id VARCHAR(36) NOT NULL,
    test_type VARCHAR(255) NOT NULL,
    test_name VARCHAR(255) NOT NULL,
    referred_by VARCHAR(255) NOT NULL,
    sample_date DATE NOT NULL,
    report_date DATE,
    passcode_id VARCHAR(20) NOT NULL,
    status ENUM('pending', 'completed') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    -- New fields
    notes TEXT,
    technician VARCHAR(255),
    verified_by VARCHAR(255),
    priority ENUM('normal', 'urgent', 'stat') DEFAULT 'normal',
    sample_type VARCHAR(100),
    methodology TEXT,
    
    INDEX idx_patient_id (patient_id),
    INDEX idx_center_id (center_id),
    INDEX idx_status (status),
    INDEX idx_sample_date (sample_date),
    INDEX idx_report_date (report_date),
    INDEX idx_passcode_id (passcode_id),
    INDEX idx_created_at (created_at),
    
    FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE,
    FOREIGN KEY (center_id) REFERENCES diagnostic_centers(id) ON DELETE CASCADE
);

-- =====================================================
-- TEST RESULTS TABLE
-- =====================================================
CREATE TABLE test_results (
    id VARCHAR(36) PRIMARY KEY DEFAULT (UUID()),
    report_id VARCHAR(36) NOT NULL,
    parameter_name VARCHAR(255) NOT NULL,
    value VARCHAR(255) NOT NULL,
    unit VARCHAR(50),
    reference_range VARCHAR(255),
    status ENUM('normal', 'abnormal', 'critical') DEFAULT 'normal',
    flag VARCHAR(10),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_report_id (report_id),
    INDEX idx_parameter_name (parameter_name),
    INDEX idx_status (status),
    
    FOREIGN KEY (report_id) REFERENCES test_reports(id) ON DELETE CASCADE
);

-- =====================================================
-- BILLS TABLE
-- =====================================================
CREATE TABLE bills (
    id VARCHAR(36) PRIMARY KEY DEFAULT (UUID()),
    patient_id VARCHAR(36) NOT NULL,
    center_id VARCHAR(36) NOT NULL,
    invoice_number VARCHAR(100) NOT NULL UNIQUE,
    amount DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
    discount DECIMAL(10, 2) DEFAULT 0.00,
    final_amount DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
    status ENUM('paid', 'pending', 'partially_paid', 'cancelled') DEFAULT 'pending',
    payment_date DATE,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    -- New payment fields
    payment_mode ENUM('cash', 'card', 'upi', 'net_banking', 'cheque', 'other'),
    transaction_id VARCHAR(255),
    payment_notes TEXT,
    due_date DATE,
    tax DECIMAL(10, 2) DEFAULT 0.00,
    total_tax DECIMAL(10, 2) DEFAULT 0.00,
    
    -- Insurance details
    insurance_provider VARCHAR(255),
    insurance_policy_number VARCHAR(100),
    insurance_claim_amount DECIMAL(10, 2),
    
    INDEX idx_patient_id (patient_id),
    INDEX idx_center_id (center_id),
    INDEX idx_invoice_number (invoice_number),
    INDEX idx_status (status),
    INDEX idx_payment_date (payment_date),
    INDEX idx_created_date (created_date),
    INDEX idx_due_date (due_date),
    
    FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE,
    FOREIGN KEY (center_id) REFERENCES diagnostic_centers(id) ON DELETE CASCADE
);

-- =====================================================
-- BILL TESTS TABLE (Many-to-Many relationship)
-- =====================================================
CREATE TABLE bill_tests (
    id VARCHAR(36) PRIMARY KEY DEFAULT (UUID()),
    bill_id VARCHAR(36) NOT NULL,
    test_name VARCHAR(255) NOT NULL,
    test_price DECIMAL(10, 2) DEFAULT 0.00,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_bill_id (bill_id),
    INDEX idx_test_name (test_name),
    
    FOREIGN KEY (bill_id) REFERENCES bills(id) ON DELETE CASCADE
);

-- =====================================================
-- CENTER PROFILES TABLE
-- =====================================================
CREATE TABLE center_profiles (
    id VARCHAR(36) PRIMARY KEY DEFAULT (UUID()),
    center_id VARCHAR(36) NOT NULL UNIQUE,
    logo TEXT, -- URL or base64 string
    tagline VARCHAR(500),
    license_number VARCHAR(100) NOT NULL,
    registration_number VARCHAR(100) NOT NULL,
    website VARCHAR(255),
    description TEXT,
    operating_hours TEXT NOT NULL,
    emergency_contact VARCHAR(20) NOT NULL,
    
    -- Social media
    facebook_url VARCHAR(255),
    twitter_url VARCHAR(255),
    instagram_url VARCHAR(255),
    
    updated_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_center_id (center_id),
    INDEX idx_license_number (license_number),
    INDEX idx_updated_date (updated_date),
    
    FOREIGN KEY (center_id) REFERENCES diagnostic_centers(id) ON DELETE CASCADE
);

-- =====================================================
-- CENTER PROFILE SERVICES TABLE
-- =====================================================
CREATE TABLE center_profile_services (
    id VARCHAR(36) PRIMARY KEY DEFAULT (UUID()),
    profile_id VARCHAR(36) NOT NULL,
    service_name VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_profile_id (profile_id),
    INDEX idx_service_name (service_name),
    
    FOREIGN KEY (profile_id) REFERENCES center_profiles(id) ON DELETE CASCADE
);

-- =====================================================
-- CENTER CERTIFICATIONS TABLE
-- =====================================================
CREATE TABLE center_certifications (
    id VARCHAR(36) PRIMARY KEY DEFAULT (UUID()),
    profile_id VARCHAR(36) NOT NULL,
    certification_name VARCHAR(255) NOT NULL,
    issuing_authority VARCHAR(255),
    issue_date DATE,
    expiry_date DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_profile_id (profile_id),
    INDEX idx_certification_name (certification_name),
    INDEX idx_expiry_date (expiry_date),
    
    FOREIGN KEY (profile_id) REFERENCES center_profiles(id) ON DELETE CASCADE
);

-- =====================================================
-- CENTER ACCREDITATIONS TABLE
-- =====================================================
CREATE TABLE center_accreditations (
    id VARCHAR(36) PRIMARY KEY DEFAULT (UUID()),
    profile_id VARCHAR(36) NOT NULL,
    accreditation_name VARCHAR(255) NOT NULL,
    accrediting_body VARCHAR(255),
    accreditation_date DATE,
    validity_period VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_profile_id (profile_id),
    INDEX idx_accreditation_name (accreditation_name),
    
    FOREIGN KEY (profile_id) REFERENCES center_profiles(id) ON DELETE CASCADE
);

-- =====================================================
-- REPORT EXPORTS TABLE
-- =====================================================
CREATE TABLE report_exports (
    id VARCHAR(36) PRIMARY KEY DEFAULT (UUID()),
    center_id VARCHAR(36) NOT NULL,
    report_type ENUM('patients', 'bills', 'reports', 'comprehensive') NOT NULL,
    period_type ENUM('daily', 'weekly', 'monthly', 'yearly', 'custom') NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    generated_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    download_url TEXT,
    status ENUM('generating', 'ready', 'expired') DEFAULT 'generating',
    expires_at TIMESTAMP,
    
    INDEX idx_center_id (center_id),
    INDEX idx_report_type (report_type),
    INDEX idx_status (status),
    INDEX idx_generated_date (generated_date),
    INDEX idx_expires_at (expires_at),
    
    FOREIGN KEY (center_id) REFERENCES diagnostic_centers(id) ON DELETE CASCADE
);

-- =====================================================
-- AUDIT LOG TABLE
-- =====================================================
CREATE TABLE audit_logs (
    id VARCHAR(36) PRIMARY KEY DEFAULT (UUID()),
    user_id VARCHAR(36),
    action VARCHAR(100) NOT NULL,
    table_name VARCHAR(100) NOT NULL,
    record_id VARCHAR(36),
    old_values JSON,
    new_values JSON,
    ip_address VARCHAR(45),
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_user_id (user_id),
    INDEX idx_action (action),
    INDEX idx_table_name (table_name),
    INDEX idx_created_at (created_at),
    
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

-- =====================================================
-- SYSTEM SETTINGS TABLE
-- =====================================================
CREATE TABLE system_settings (
    id VARCHAR(36) PRIMARY KEY DEFAULT (UUID()),
    setting_key VARCHAR(100) NOT NULL UNIQUE,
    setting_value TEXT,
    setting_type ENUM('string', 'number', 'boolean', 'json') DEFAULT 'string',
    description TEXT,
    is_public BOOLEAN DEFAULT FALSE,
    updated_by VARCHAR(36),
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    INDEX idx_setting_key (setting_key),
    INDEX idx_is_public (is_public),
    
    FOREIGN KEY (updated_by) REFERENCES users(id) ON DELETE SET NULL
);