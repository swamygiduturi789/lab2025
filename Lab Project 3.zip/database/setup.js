const { testConnection, executeQuery, executeTransaction } = require('./connection');
const fs = require('fs');
const path = require('path');
const { initializeAdminAccountsAndData } = require('./init-admin-accounts');

async function setupDatabase() {
  console.log('🗄️ Composcale.com Database Setup');
  console.log('=================================\n');

  try {
    // Test database connection
    console.log('1️⃣ Testing database connection...');
    const isConnected = await testConnection();
    
    if (!isConnected) {
      console.error('❌ Database connection failed. Please check your configuration.');
      console.error('   Make sure MySQL is running and credentials in .env are correct.');
      return false;
    }
    console.log('✅ Database connection successful\n');

    // Read and execute schema
    console.log('2️⃣ Creating database schema...');
    const schemaPath = path.join(__dirname, 'schema.sql');
    
    if (!fs.existsSync(schemaPath)) {
      console.error('❌ Schema file not found:', schemaPath);
      return false;
    }

    const schemaSQL = fs.readFileSync(schemaPath, 'utf8');
    
    // Split SQL statements and execute them
    const statements = schemaSQL
      .split(';')
      .map(stmt => stmt.trim())
      .filter(stmt => stmt.length > 0);

    let createdTables = 0;
    for (const statement of statements) {
      if (statement.trim()) {
        const result = await executeQuery(statement);
        if (!result.success) {
          // Don't fail on "already exists" errors
          if (!result.error.includes('already exists')) {
            console.error(`❌ Error executing statement: ${statement.substring(0, 50)}...`);
            console.error(`Error: ${result.error}`);
            return false;
          }
        } else {
          if (statement.toUpperCase().includes('CREATE TABLE')) {
            createdTables++;
          }
        }
      }
    }
    
    console.log(`✅ Database schema created successfully (${createdTables} tables)\n`);

    // Initialize admin accounts and demo data
    console.log('3️⃣ Initializing admin accounts and demo data...');
    const initSuccess = await initializeAdminAccountsAndData();
    
    if (!initSuccess) {
      console.error('❌ Failed to initialize admin accounts and demo data');
      return false;
    }

    // Verify setup
    console.log('\n4️⃣ Verifying database setup...');
    const verificationQueries = [
      { name: 'Users', query: 'SELECT COUNT(*) as count FROM users' },
      { name: 'Diagnostic Centers', query: 'SELECT COUNT(*) as count FROM diagnostic_centers' },
      { name: 'Patients', query: 'SELECT COUNT(*) as count FROM patients' },
      { name: 'Test Reports', query: 'SELECT COUNT(*) as count FROM test_reports' },
      { name: 'Bills', query: 'SELECT COUNT(*) as count FROM bills' }
    ];

    for (const { name, query } of verificationQueries) {
      const result = await executeQuery(query);
      if (result.success) {
        console.log(`✅ ${name}: ${result.data[0].count} records`);
      } else {
        console.log(`❌ ${name}: Verification failed`);
      }
    }

    console.log('\n🎉 Database setup completed successfully!');
    console.log('\n📋 Default Login Credentials:');
    console.log('  Super Admin: superadmin / password');
    console.log('  Test Center: testcenter / password');
    console.log('  Test Patient: patient / password');
    console.log('\n📋 Next Steps:');
    console.log('1. Start development: npm run dev');
    console.log('2. Or production build: npm run full-build');
    console.log('\n🌐 Application URLs:');
    console.log('  Frontend: http://localhost:3000');
    console.log('  Backend API: http://localhost:3001');
    console.log('  Health Check: http://localhost:3001/api/health');

    return true;

  } catch (error) {
    console.error('❌ Database setup failed:', error);
    return false;
  }
}

// Additional utility functions
async function resetDatabase() {
  console.log('🔄 Resetting Composcale.com database...');
  
  try {
    // Drop all tables in correct order (reverse of dependencies)
    const tables = [
      'test_results',
      'test_reports', 
      'bill_tests',
      'bills',
      'center_profile_services',
      'center_certifications',
      'center_accreditations',
      'center_profiles',
      'center_services',
      'patients',
      'diagnostic_centers',
      'audit_logs',
      'system_settings',
      'report_exports',
      'users',
      'sessions'
    ];

    console.log('Dropping existing tables...');
    for (const table of tables) {
      const result = await executeQuery(`DROP TABLE IF EXISTS ${table}`);
      if (!result.success) {
        console.error(`❌ Failed to drop table ${table}:`, result.error);
      } else {
        console.log(`✅ Dropped table: ${table}`);
      }
    }

    console.log('✅ Database reset completed');
    return true;

  } catch (error) {
    console.error('❌ Database reset failed:', error);
    return false;
  }
}

async function checkDatabaseHealth() {
  console.log('🔍 Checking Composcale.com database health...');
  
  try {
    const healthChecks = [
      {
        name: 'Connection Test',
        check: async () => await testConnection()
      },
      {
        name: 'Admin Users',
        check: async () => {
          const result = await executeQuery("SELECT COUNT(*) as count FROM users WHERE role = 'super_admin'");
          return result.success && result.data[0].count > 0;
        }
      },
      {
        name: 'Database Tables',
        check: async () => {
          const result = await executeQuery("SHOW TABLES");
          return result.success && result.data.length >= 10;
        }
      },
      {
        name: 'Foreign Key Constraints',
        check: async () => {
          const result = await executeQuery(`
            SELECT COUNT(*) as count 
            FROM information_schema.table_constraints 
            WHERE constraint_schema = DATABASE() 
            AND constraint_type = 'FOREIGN KEY'
          `);
          return result.success && result.data[0].count > 0;
        }
      },
      {
        name: 'Sample Data',
        check: async () => {
          const result = await executeQuery("SELECT COUNT(*) as count FROM diagnostic_centers");
          return result.success && result.data[0].count > 0;
        }
      }
    ];

    let allHealthy = true;
    for (const { name, check } of healthChecks) {
      try {
        const isHealthy = await check();
        console.log(`${isHealthy ? '✅' : '❌'} ${name}: ${isHealthy ? 'OK' : 'FAILED'}`);
        if (!isHealthy) allHealthy = false;
      } catch (error) {
        console.log(`❌ ${name}: ERROR - ${error.message}`);
        allHealthy = false;
      }
    }

    console.log(`\n${allHealthy ? '🎉' : '⚠️'} Overall Health: ${allHealthy ? 'HEALTHY' : 'ISSUES DETECTED'}`);
    
    if (allHealthy) {
      console.log('\n✅ Database is ready for use!');
      console.log('🚀 You can start the application with: npm run dev');
    } else {
      console.log('\n⚠️ Database issues detected. Try running: npm run db:reset && npm run setup:db');
    }
    
    return allHealthy;

  } catch (error) {
    console.error('❌ Health check failed:', error);
    return false;
  }
}

// Command line interface
if (require.main === module) {
  const command = process.argv[2];
  
  switch (command) {
    case 'reset':
      resetDatabase()
        .then(success => process.exit(success ? 0 : 1))
        .catch(error => {
          console.error('Fatal error:', error);
          process.exit(1);
        });
      break;
      
    case 'health':
      checkDatabaseHealth()
        .then(success => process.exit(success ? 0 : 1))
        .catch(error => {
          console.error('Fatal error:', error);
          process.exit(1);
        });
      break;
      
    case 'init-admin':
      initializeAdminAccountsAndData()
        .then(success => process.exit(success ? 0 : 1))
        .catch(error => {
          console.error('Fatal error:', error);
          process.exit(1);
        });
      break;
      
    default:
      setupDatabase()
        .then(success => process.exit(success ? 0 : 1))
        .catch(error => {
          console.error('Fatal error:', error);
          process.exit(1);
        });
  }
}

module.exports = {
  setupDatabase,
  resetDatabase,
  checkDatabaseHealth
};