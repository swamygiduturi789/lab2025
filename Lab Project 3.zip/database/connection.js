const mysql = require('mysql2/promise');
require('dotenv').config();

// Database configuration
const dbConfig = {
  host: process.env.DB_HOST || 'localhost',
  port: process.env.DB_PORT || 3306,
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'composcale_com',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
  acquireTimeout: 60000,
  timeout: 60000,
  enableKeepAlive: true,
  keepAliveInitialDelay: 0
};

// Create connection pool
let pool = null;

function createPool() {
  try {
    pool = mysql.createPool(dbConfig);
    console.log('📊 MySQL connection pool created');
    return pool;
  } catch (error) {
    console.error('❌ Failed to create MySQL pool:', error.message);
    return null;
  }
}

// Test database connection
async function testConnection() {
  try {
    if (!pool) {
      pool = createPool();
    }
    
    if (!pool) {
      return false;
    }

    const connection = await pool.getConnection();
    await connection.ping();
    connection.release();
    
    console.log('✅ Database connection successful');
    return true;
  } catch (error) {
    console.warn('⚠️ Database connection failed:', error.message);
    return false;
  }
}

// Execute query with error handling
async function executeQuery(query, params = []) {
  try {
    if (!pool) {
      const isConnected = await testConnection();
      if (!isConnected) {
        return {
          success: false,
          error: 'Database connection unavailable',
          data: []
        };
      }
    }

    const [rows] = await pool.execute(query, params);
    
    return {
      success: true,
      data: rows,
      error: null
    };
  } catch (error) {
    console.error('❌ Database query error:', error.message);
    console.error('Query:', query);
    console.error('Params:', params);
    
    return {
      success: false,
      error: error.message,
      data: []
    };
  }
}

// Execute multiple queries in transaction
async function executeTransaction(queries) {
  const connection = await pool.getConnection();
  
  try {
    await connection.beginTransaction();
    
    const results = [];
    for (const { query, params } of queries) {
      const [rows] = await connection.execute(query, params);
      results.push(rows);
    }
    
    await connection.commit();
    
    return {
      success: true,
      data: results,
      error: null
    };
  } catch (error) {
    await connection.rollback();
    console.error('❌ Transaction error:', error.message);
    
    return {
      success: false,
      error: error.message,
      data: []
    };
  } finally {
    connection.release();
  }
}

// Graceful shutdown
function closePool() {
  if (pool) {
    pool.end();
    console.log('📊 MySQL connection pool closed');
  }
}

// Handle process termination
process.on('SIGINT', () => {
  console.log('\n🔄 Gracefully shutting down database connections...');
  closePool();
  process.exit(0);
});

process.on('SIGTERM', () => {
  console.log('\n🔄 Gracefully shutting down database connections...');
  closePool();
  process.exit(0);
});

module.exports = {
  executeQuery,
  executeTransaction,
  testConnection,
  closePool,
  dbConfig
};