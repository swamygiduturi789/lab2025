# Composcale.com - Database Setup Guide

## Overview
This directory contains the complete MySQL database schema and setup scripts for the Composcale.com diagnostic center management system.

## Prerequisites
- MySQL 8.0 or higher
- Node.js 16.0 or higher
- npm or yarn package manager

## Database Structure

### Core Tables
- **users** - Authentication and user management
- **diagnostic_centers** - Diagnostic center information
- **patients** - Patient records and details
- **test_reports** - Medical test reports
- **test_results** - Individual test result parameters
- **bills** - Billing and payment information

### Profile & Configuration Tables
- **center_profiles** - Extended center profile information
- **center_services** - Services offered by centers
- **center_certifications** - Center certifications
- **center_accreditations** - Center accreditations
- **system_settings** - Application configuration

### Utility Tables
- **bill_tests** - Many-to-many relationship for bill tests
- **report_exports** - Export job tracking
- **audit_logs** - System audit trail

## Setup Instructions

### 1. Install Dependencies
```bash
npm install mysql2 bcrypt uuid dotenv
```

### 2. Create Database
```sql
CREATE DATABASE composcale_com CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

### 3. Configure Environment
Copy `.env.example` to `.env` and update the values:
```bash
cp .env.example .env
```

Edit `.env` with your database credentials:
```
DB_HOST=localhost
DB_PORT=3306
DB_USER=root
DB_PASSWORD=your_password
DB_NAME=composcale_com
```

### 4. Run Database Setup
```bash
# Initialize database with schema and sample data
node setup.js
```

### 5. Verify Installation
```bash
# Test database connection
node test-connection.js
```

## Sample Data

The system includes comprehensive sample data for testing:

### Users
- **Super Admin**: `superadmin` / `password`
- **Diagnostic Centers**: 
  - `apollo_mumbai` / `password`
  - `lifelab_delhi` / `password`
  - `metropolis_bangalore` / `password`
- **Patients**: 
  - `patient_001` / `password`
  - `patient_002` / `password`
  - `patient_003` / `password`

### Sample Centers
- Apollo Diagnostics Mumbai (Gold subscription)
- LifeLab Diagnostics Delhi (Standard subscription)
- Metropolis Healthcare Bangalore (Free subscription)

### Sample Data Includes
- 5 patients with complete profiles
- 5 test reports with results
- 5 bills with different payment statuses
- Center profiles with services and certifications
- Audit logs and system settings

## Database Models

The `models.js` file provides easy-to-use classes for database operations:

### UserModel
```javascript
// Create user
await UserModel.create(userData);

// Authenticate user
await UserModel.authenticate(username, password);

// Find user
await UserModel.findById(userId);
```

### DiagnosticCenterModel
```javascript
// Create center
await DiagnosticCenterModel.create(centerData);

// Get centers with filters
await DiagnosticCenterModel.getAll({ city: 'Mumbai' });

// Get center statistics
await DiagnosticCenterModel.getStats(centerId);
```

### PatientModel
```javascript
// Create patient
await PatientModel.create(patientData);

// Find by passcode
await PatientModel.findByPasscode(passcode);

// Generate unique passcode
await PatientModel.generatePasscode();
```

### TestReportModel
```javascript
// Create report with results
await TestReportModel.create(reportData);

// Get center reports
await TestReportModel.getByCenterId(centerId, filters);

// Update report status
await TestReportModel.updateStatus(reportId, 'completed');
```

### BillModel
```javascript
// Create bill
await BillModel.create(billData);

// Update payment status
await BillModel.updatePaymentStatus(billId, 'paid', paymentData);

// Generate invoice number
await BillModel.generateInvoiceNumber(centerId);
```

## Security Features

### Password Hashing
- Uses bcrypt with 10 salt rounds
- Passwords are never stored in plain text

### Data Validation
- Input sanitization and validation
- SQL injection prevention
- XSS protection

### Audit Trail
- All database operations are logged
- User actions are tracked
- IP addresses and user agents recorded

## Backup & Maintenance

### Automated Backups
```bash
# Create backup
mysqldump -u root -p medilab_india > backup_$(date +%Y%m%d_%H%M%S).sql

# Restore backup
mysql -u root -p medilab_india < backup_file.sql
```

### Database Maintenance
```sql
-- Optimize tables
OPTIMIZE TABLE users, diagnostic_centers, patients, test_reports, bills;

-- Check table integrity
CHECK TABLE users, diagnostic_centers, patients, test_reports, bills;

-- Analyze tables for query optimization
ANALYZE TABLE users, diagnostic_centers, patients, test_reports, bills;
```

## Performance Optimization

### Indexes
- Primary keys on all tables
- Foreign key indexes for relationships
- Composite indexes for common queries
- Search indexes on name, phone, email fields

### Query Optimization
- Use prepared statements
- Implement connection pooling
- Cache frequently accessed data
- Paginate large result sets

### Monitoring
```sql
-- Check slow queries
SELECT * FROM mysql.slow_log WHERE start_time > DATE_SUB(NOW(), INTERVAL 1 HOUR);

-- Monitor connection usage
SHOW PROCESSLIST;

-- Check table sizes
SELECT 
    table_name,
    ROUND(((data_length + index_length) / 1024 / 1024), 2) AS 'Size (MB)'
FROM information_schema.tables 
WHERE table_schema = 'composcale_com'
ORDER BY (data_length + index_length) DESC;
```

## Troubleshooting

### Common Issues

1. **Connection Refused**
   - Check MySQL service is running
   - Verify host and port configuration
   - Check firewall settings

2. **Authentication Failed**
   - Verify username and password
   - Check user privileges
   - Ensure database exists

3. **Schema Errors**
   - Drop and recreate database
   - Run schema.sql again
   - Check MySQL version compatibility

4. **Performance Issues**
   - Analyze slow query log
   - Add missing indexes
   - Optimize large tables

### Support
For database-related issues:
1. Check the error logs in MySQL
2. Verify environment configuration
3. Test connection with MySQL client
4. Review the application logs

## Migration Guide

### From Development to Production
1. Export schema without data
2. Create production database
3. Import schema
4. Configure production environment
5. Set up automated backups
6. Enable monitoring and alerts

### Schema Updates
1. Create migration scripts
2. Test in development environment
3. Backup production database
4. Apply migrations during maintenance window
5. Verify data integrity
6. Update application code if needed