import React, { createContext, useContext, useReducer, useEffect, ReactNode } from 'react';
import { apiService } from '../services/api';

export interface User {
  id: string;
  username: string;
  role: 'super_admin' | 'diagnostic_center' | 'patient';
  name: string;
  phone?: string;
  email?: string;
  centerId?: string;
  centerName?: string;
  isActive?: boolean;
  createdAt?: string;
  lastLogin?: string;
}

interface AuthState {
  user: User | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  error: string | null;
  connectionStatus: 'online' | 'offline' | 'connecting';
  initialized: boolean;
}

type AuthAction =
  | { type: 'INIT_START' }
  | { type: 'INIT_COMPLETE'; payload: { connectionStatus: 'online' | 'offline'; user?: User } }
  | { type: 'LOGIN_START' }
  | { type: 'LOGIN_SUCCESS'; payload: User }
  | { type: 'LOGIN_FAILURE'; payload: string }
  | { type: 'LOGOUT' }
  | { type: 'SET_LOADING'; payload: boolean }
  | { type: 'CLEAR_ERROR' }
  | { type: 'SET_USER'; payload: User }
  | { type: 'SET_CONNECTION_STATUS'; payload: 'online' | 'offline' | 'connecting' };

const initialState: AuthState = {
  user: null,
  isLoading: true,
  isAuthenticated: false,
  error: null,
  connectionStatus: 'connecting',
  initialized: false,
};

const authReducer = (state: AuthState, action: AuthAction): AuthState => {
  switch (action.type) {
    case 'INIT_START':
      return {
        ...state,
        isLoading: true,
        connectionStatus: 'connecting',
        initialized: false,
      };
    case 'INIT_COMPLETE':
      return {
        ...state,
        isLoading: false,
        connectionStatus: action.payload.connectionStatus,
        initialized: true,
        user: action.payload.user || null,
        isAuthenticated: !!action.payload.user,
      };
    case 'LOGIN_START':
      return {
        ...state,
        isLoading: true,
        error: null,
      };
    case 'LOGIN_SUCCESS':
      return {
        ...state,
        user: action.payload,
        isLoading: false,
        isAuthenticated: true,
        error: null,
        connectionStatus: apiService.isApiOnline() ? 'online' : 'offline',
      };
    case 'LOGIN_FAILURE':
      return {
        ...state,
        user: null,
        isLoading: false,
        isAuthenticated: false,
        error: action.payload,
        connectionStatus: apiService.isApiOnline() ? 'online' : 'offline',
      };
    case 'LOGOUT':
      return {
        ...state,
        user: null,
        isAuthenticated: false,
        error: null,
        connectionStatus: apiService.isApiOnline() ? 'online' : 'offline',
      };
    case 'SET_LOADING':
      return {
        ...state,
        isLoading: action.payload,
      };
    case 'CLEAR_ERROR':
      return {
        ...state,
        error: null,
      };
    case 'SET_USER':
      return {
        ...state,
        user: action.payload,
        isAuthenticated: true,
        isLoading: false,
        connectionStatus: apiService.isApiOnline() ? 'online' : 'offline',
      };
    case 'SET_CONNECTION_STATUS':
      return {
        ...state,
        connectionStatus: action.payload,
      };
    default:
      return state;
  }
};

interface AuthContextType extends AuthState {
  login: (credentials: { username: string; password: string }) => Promise<void>;
  logout: () => Promise<void>;
  clearError: () => void;
  refreshUser: () => Promise<void>;
  checkConnection: () => Promise<void>;
  toggleOfflineMode?: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [state, dispatch] = useReducer(authReducer, initialState);

  // Initialize the app immediately
  useEffect(() => {
    initializeAuth();
  }, []);

  // Periodic connection check (only when online and in background)
  useEffect(() => {
    if (!state.initialized || state.connectionStatus !== 'online') return;

    const interval = setInterval(() => {
      checkConnection();
    }, 60000); // Check every minute when online

    return () => clearInterval(interval);
  }, [state.initialized, state.connectionStatus]);

  const initializeAuth = async () => {
    try {
      dispatch({ type: 'INIT_START' });
      
      // Initialize API service with quick connection check
      const isOnline = await apiService.initialize();
      const connectionStatus = isOnline ? 'online' : 'offline';
      
      // Always try to get current user (will use mock data if offline)
      let user = null;
      try {
        const response = await apiService.getCurrentUser();
        if (response.success && response.data) {
          user = response.data;
        }
      } catch (error) {
        // Ignore auth check errors during initialization
      }

      dispatch({ 
        type: 'INIT_COMPLETE', 
        payload: { connectionStatus, user } 
      });
      
    } catch (error) {
      console.error('Auth initialization failed:', error);
      // Always complete initialization, defaulting to offline mode
      dispatch({ 
        type: 'INIT_COMPLETE', 
        payload: { connectionStatus: 'offline' } 
      });
    }
  };

  const checkConnection = async () => {
    try {
      const isOnline = await apiService.checkConnection();
      const status = isOnline ? 'online' : 'offline';
      
      if (state.connectionStatus !== status) {
        dispatch({ type: 'SET_CONNECTION_STATUS', payload: status });
        
        if (status === 'online') {
          console.log('✅ Connection restored');
        } else {
          console.log('⚠️ Connection lost, switching to offline mode');
        }
      }
    } catch (error) {
      dispatch({ type: 'SET_CONNECTION_STATUS', payload: 'offline' });
    }
  };

  const login = async (credentials: { username: string; password: string }) => {
    try {
      dispatch({ type: 'LOGIN_START' });
      const response = await apiService.login(credentials);
      
      if (response.success && response.data) {
        dispatch({ type: 'LOGIN_SUCCESS', payload: response.data });
        
        // Show appropriate message based on connection status
        if (!apiService.isApiOnline()) {
          console.log('🔄 Logged in using demo mode');
        }
      } else {
        dispatch({ type: 'LOGIN_FAILURE', payload: response.error || 'Login failed' });
      }
    } catch (error) {
      dispatch({ 
        type: 'LOGIN_FAILURE', 
        payload: error instanceof Error ? error.message : 'Login failed' 
      });
    }
  };

  const logout = async () => {
    try {
      console.log('🔐 Starting logout process...');
      await apiService.logout();
      console.log('✅ Logout API call successful');
    } catch (error) {
      console.error('❌ Logout API error:', error);
    } finally {
      console.log('🔄 Clearing authentication state...');
      dispatch({ type: 'LOGOUT' });
      console.log('✅ Logout completed');
    }
  };

  const clearError = () => {
    dispatch({ type: 'CLEAR_ERROR' });
  };

  const refreshUser = async () => {
    try {
      dispatch({ type: 'SET_LOADING', payload: true });
      
      const response = await apiService.getCurrentUser();
      
      if (response.success && response.data) {
        dispatch({ type: 'SET_USER', payload: response.data });
      } else {
        dispatch({ type: 'LOGOUT' });
      }
    } catch (error) {
      console.error('Auth refresh failed:', error);
      dispatch({ type: 'LOGOUT' });
    } finally {
      dispatch({ type: 'SET_LOADING', payload: false });
    }
  };

  const toggleOfflineMode = () => {
    if (process.env.NODE_ENV === 'development') {
      apiService.toggleOfflineMode();
      const newStatus = apiService.isApiOnline() ? 'online' : 'offline';
      dispatch({ type: 'SET_CONNECTION_STATUS', payload: newStatus });
    }
  };

  const value: AuthContextType = {
    ...state,
    login,
    logout,
    clearError,
    refreshUser,
    checkConnection,
    ...(process.env.NODE_ENV === 'development' && { toggleOfflineMode }),
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};

export default AuthContext;