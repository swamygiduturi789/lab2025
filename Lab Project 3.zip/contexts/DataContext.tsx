import React, { createContext, useContext, useReducer, ReactNode } from 'react';
import { apiService } from '../services/api';
import { useAuth } from './AuthContext';

export interface DiagnosticCenter {
  id: string;
  name: string;
  address: string;
  city: string;
  state: string;
  pincode: string;
  phone?: string;
  email?: string;
  ownerName: string;
  ownerPhone: string;
  ownerEmail: string;
  ownerAddress?: string;
  ownerCity?: string;
  ownerState?: string;
  subscriptionType: 'free' | 'standard' | 'gold';
  paymentType: 'online';
  username: string;
  isActive: boolean;
  createdDate: string;
  logo?: string;
  licenseNumber?: string;
  registrationNumber?: string;
  website?: string;
  description?: string;
  services?: string[];
  operatingHours?: string;
  emergencyContact?: string;
}

export interface Patient {
  id: string;
  fullName: string;
  email?: string;
  phone: string;
  address: string;
  city: string;
  state: string;
  pincode: string;
  whatsappNumber?: string;
  passcode: string;
  centerId: string;
  centerName?: string;
  createdDate: string;
  dateOfBirth?: string;
  gender?: 'male' | 'female' | 'other';
  emergencyContact?: string;
  bloodGroup?: string;
  allergies?: string;
}

export interface TestReport {
  id: string;
  patientId: string;
  patientName?: string;
  centerId: string;
  centerName?: string;
  testType: string;
  testName: string;
  referredBy: string;
  sampleDate: string;
  reportDate?: string;
  passcodeId: string;
  results?: TestResult[];
  status: 'pending' | 'completed';
  notes?: string;
  technician?: string;
  verifiedBy?: string;
  priority?: 'normal' | 'urgent' | 'stat';
  sampleType?: string;
  methodology?: string;
  createdAt: string;
  updatedAt?: string;
}

export interface TestResult {
  parameter: string;
  value: string;
  unit: string;
  reference: string;
  status?: 'normal' | 'abnormal' | 'critical';
  flag?: string;
}

export interface Bill {
  id: string;
  patientId: string;
  patientName?: string;
  centerId: string;
  centerName?: string;
  invoiceNumber: string;
  amount: number;
  discount?: number;
  tax?: number;
  totalTax?: number;
  finalAmount: number;
  status: 'paid' | 'pending' | 'partially_paid' | 'cancelled';
  paymentDate?: string;
  createdDate: string;
  tests: BillTest[];
  paymentMode?: 'cash' | 'card' | 'upi' | 'net_banking' | 'cheque' | 'other';
  transactionId?: string;
  paymentNotes?: string;
  dueDate?: string;
}

export interface BillTest {
  name: string;
  price: number;
}

interface DataState {
  centers: DiagnosticCenter[];
  patients: Patient[];
  reports: TestReport[];
  bills: Bill[];
  stats: {
    dashboard?: any;
    patients?: any;
    reports?: any;
    bills?: any;
  };
  loading: {
    centers: boolean;
    patients: boolean;
    reports: boolean;
    bills: boolean;
    stats: boolean;
  };
  error: string | null;
}

type DataAction =
  | { type: 'SET_LOADING'; payload: { key: keyof DataState['loading']; value: boolean } }
  | { type: 'SET_ERROR'; payload: string }
  | { type: 'CLEAR_ERROR' }
  | { type: 'SET_CENTERS'; payload: DiagnosticCenter[] }
  | { type: 'SET_PATIENTS'; payload: Patient[] }
  | { type: 'SET_REPORTS'; payload: TestReport[] }
  | { type: 'SET_BILLS'; payload: Bill[] }
  | { type: 'SET_STATS'; payload: { key: keyof DataState['stats']; value: any } }
  | { type: 'ADD_PATIENT'; payload: Patient }
  | { type: 'UPDATE_PATIENT'; payload: Patient }
  | { type: 'ADD_REPORT'; payload: TestReport }
  | { type: 'UPDATE_REPORT'; payload: TestReport }
  | { type: 'ADD_BILL'; payload: Bill }
  | { type: 'UPDATE_BILL'; payload: Bill }
  | { type: 'ADD_CENTER'; payload: DiagnosticCenter }
  | { type: 'UPDATE_CENTER'; payload: DiagnosticCenter };

const initialState: DataState = {
  centers: [],
  patients: [],
  reports: [],
  bills: [],
  stats: {},
  loading: {
    centers: false,
    patients: false,
    reports: false,
    bills: false,
    stats: false,
  },
  error: null,
};

const dataReducer = (state: DataState, action: DataAction): DataState => {
  switch (action.type) {
    case 'SET_LOADING':
      return {
        ...state,
        loading: {
          ...state.loading,
          [action.payload.key]: action.payload.value,
        },
      };
    case 'SET_ERROR':
      return {
        ...state,
        error: action.payload,
      };
    case 'CLEAR_ERROR':
      return {
        ...state,
        error: null,
      };
    case 'SET_CENTERS':
      return {
        ...state,
        centers: action.payload,
      };
    case 'SET_PATIENTS':
      return {
        ...state,
        patients: action.payload,
      };
    case 'SET_REPORTS':
      return {
        ...state,
        reports: action.payload,
      };
    case 'SET_BILLS':
      return {
        ...state,
        bills: action.payload,
      };
    case 'SET_STATS':
      return {
        ...state,
        stats: {
          ...state.stats,
          [action.payload.key]: action.payload.value,
        },
      };
    case 'ADD_PATIENT':
      return {
        ...state,
        patients: [action.payload, ...state.patients],
      };
    case 'UPDATE_PATIENT':
      return {
        ...state,
        patients: state.patients.map(p => 
          p.id === action.payload.id ? action.payload : p
        ),
      };
    case 'ADD_REPORT':
      return {
        ...state,
        reports: [action.payload, ...state.reports],
      };
    case 'UPDATE_REPORT':
      return {
        ...state,
        reports: state.reports.map(r => 
          r.id === action.payload.id ? action.payload : r
        ),
      };
    case 'ADD_BILL':
      return {
        ...state,
        bills: [action.payload, ...state.bills],
      };
    case 'UPDATE_BILL':
      return {
        ...state,
        bills: state.bills.map(b => 
          b.id === action.payload.id ? action.payload : b
        ),
      };
    case 'ADD_CENTER':
      return {
        ...state,
        centers: [action.payload, ...state.centers],
      };
    case 'UPDATE_CENTER':
      return {
        ...state,
        centers: state.centers.map(c => 
          c.id === action.payload.id ? action.payload : c
        ),
      };
    default:
      return state;
  }
};

interface DataContextType extends DataState {
  // Centers
  fetchCenters: () => Promise<void>;
  createCenter: (centerData: Partial<DiagnosticCenter>) => Promise<void>;
  updateCenter: (id: string, centerData: Partial<DiagnosticCenter>) => Promise<void>;
  
  // Patients
  fetchPatients: (filters?: Record<string, any>) => Promise<void>;
  createPatient: (patientData: Partial<Patient>) => Promise<void>;
  updatePatient: (id: string, patientData: Partial<Patient>) => Promise<void>;
  findPatientByPasscode: (passcode: string) => Promise<Patient | null>;
  
  // Reports
  fetchReports: (filters?: Record<string, any>) => Promise<void>;
  createReport: (reportData: Partial<TestReport>) => Promise<void>;
  updateReport: (id: string, reportData: Partial<TestReport>) => Promise<void>;
  updateReportStatus: (id: string, status: string, reportData?: any) => Promise<void>;
  
  // Bills
  fetchBills: (filters?: Record<string, any>) => Promise<void>;
  createBill: (billData: Partial<Bill>) => Promise<void>;
  updateBill: (id: string, billData: Partial<Bill>) => Promise<void>;
  updateBillPayment: (id: string, status: string, paymentData?: any) => Promise<void>;
  
  // Stats
  fetchDashboardStats: () => Promise<void>;
  fetchPatientStats: () => Promise<void>;
  fetchReportStats: () => Promise<void>;
  fetchBillStats: () => Promise<void>;
  
  // Utility
  clearError: () => void;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export const useData = () => {
  const context = useContext(DataContext);
  if (context === undefined) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
};

interface DataProviderProps {
  children: ReactNode;
}

export const DataProvider: React.FC<DataProviderProps> = ({ children }) => {
  const [state, dispatch] = useReducer(dataReducer, initialState);
  const { user } = useAuth();

  const handleError = (error: any) => {
    const message = error?.error || error?.message || 'An error occurred';
    dispatch({ type: 'SET_ERROR', payload: message });
    console.error('Data operation error:', error);
  };

  // Centers
  const fetchCenters = async () => {
    try {
      dispatch({ type: 'SET_LOADING', payload: { key: 'centers', value: true } });
      const response = await apiService.getAllCenters();
      
      if (response.success && response.data) {
        dispatch({ type: 'SET_CENTERS', payload: response.data });
      } else {
        handleError(response);
      }
    } catch (error) {
      handleError(error);
    } finally {
      dispatch({ type: 'SET_LOADING', payload: { key: 'centers', value: false } });
    }
  };

  const createCenter = async (centerData: Partial<DiagnosticCenter>) => {
    try {
      const response = await apiService.createCenter(centerData);
      
      if (response.success && response.data) {
        dispatch({ type: 'ADD_CENTER', payload: response.data });
      } else {
        handleError(response);
      }
    } catch (error) {
      handleError(error);
    }
  };

  const updateCenter = async (id: string, centerData: Partial<DiagnosticCenter>) => {
    try {
      const response = await apiService.updateCenter(id, centerData);
      
      if (response.success) {
        const updatedCenter = { ...centerData, id } as DiagnosticCenter;
        dispatch({ type: 'UPDATE_CENTER', payload: updatedCenter });
      } else {
        handleError(response);
      }
    } catch (error) {
      handleError(error);
    }
  };

  // Patients
  const fetchPatients = async (filters?: Record<string, any>) => {
    try {
      dispatch({ type: 'SET_LOADING', payload: { key: 'patients', value: true } });
      const response = await apiService.getPatients(filters);
      
      if (response.success && response.data) {
        dispatch({ type: 'SET_PATIENTS', payload: response.data });
      } else {
        handleError(response);
      }
    } catch (error) {
      handleError(error);
    } finally {
      dispatch({ type: 'SET_LOADING', payload: { key: 'patients', value: false } });
    }
  };

  const createPatient = async (patientData: Partial<Patient>) => {
    try {
      const response = await apiService.createPatient(patientData);
      
      if (response.success && response.data) {
        dispatch({ type: 'ADD_PATIENT', payload: response.data });
      } else {
        handleError(response);
      }
    } catch (error) {
      handleError(error);
    }
  };

  const updatePatient = async (id: string, patientData: Partial<Patient>) => {
    try {
      const response = await apiService.updatePatient(id, patientData);
      
      if (response.success) {
        const updatedPatient = { ...patientData, id } as Patient;
        dispatch({ type: 'UPDATE_PATIENT', payload: updatedPatient });
      } else {
        handleError(response);
      }
    } catch (error) {
      handleError(error);
    }
  };

  const findPatientByPasscode = async (passcode: string): Promise<Patient | null> => {
    try {
      const response = await apiService.findPatientByPasscode(passcode);
      
      if (response.success && response.data) {
        return response.data;
      } else {
        handleError(response);
        return null;
      }
    } catch (error) {
      handleError(error);
      return null;
    }
  };

  // Reports
  const fetchReports = async (filters?: Record<string, any>) => {
    try {
      dispatch({ type: 'SET_LOADING', payload: { key: 'reports', value: true } });
      const response = await apiService.getReports(filters);
      
      if (response.success && response.data) {
        dispatch({ type: 'SET_REPORTS', payload: response.data });
      } else {
        handleError(response);
      }
    } catch (error) {
      handleError(error);
    } finally {
      dispatch({ type: 'SET_LOADING', payload: { key: 'reports', value: false } });
    }
  };

  const createReport = async (reportData: Partial<TestReport>) => {
    try {
      const response = await apiService.createReport(reportData);
      
      if (response.success && response.data) {
        dispatch({ type: 'ADD_REPORT', payload: response.data });
      } else {
        handleError(response);
      }
    } catch (error) {
      handleError(error);
    }
  };

  const updateReport = async (id: string, reportData: Partial<TestReport>) => {
    try {
      const response = await apiService.updateReportStatus(id, reportData.status || 'pending', reportData);
      
      if (response.success) {
        const updatedReport = { ...reportData, id } as TestReport;
        dispatch({ type: 'UPDATE_REPORT', payload: updatedReport });
      } else {
        handleError(response);
      }
    } catch (error) {
      handleError(error);
    }
  };

  const updateReportStatus = async (id: string, status: string, reportData?: any) => {
    try {
      const response = await apiService.updateReportStatus(id, status, reportData);
      
      if (response.success) {
        const updatedReport = { ...reportData, id, status } as TestReport;
        dispatch({ type: 'UPDATE_REPORT', payload: updatedReport });
      } else {
        handleError(response);
      }
    } catch (error) {
      handleError(error);
    }
  };

  // Bills
  const fetchBills = async (filters?: Record<string, any>) => {
    try {
      dispatch({ type: 'SET_LOADING', payload: { key: 'bills', value: true } });
      const response = await apiService.getBills(filters);
      
      if (response.success && response.data) {
        dispatch({ type: 'SET_BILLS', payload: response.data });
      } else {
        handleError(response);
      }
    } catch (error) {
      handleError(error);
    } finally {
      dispatch({ type: 'SET_LOADING', payload: { key: 'bills', value: false } });
    }
  };

  const createBill = async (billData: Partial<Bill>) => {
    try {
      const response = await apiService.createBill(billData);
      
      if (response.success && response.data) {
        dispatch({ type: 'ADD_BILL', payload: response.data });
      } else {
        handleError(response);
      }
    } catch (error) {
      handleError(error);
    }
  };

  const updateBill = async (id: string, billData: Partial<Bill>) => {
    try {
      const response = await apiService.updateBillPayment(id, billData.status || 'pending', billData);
      
      if (response.success) {
        const updatedBill = { ...billData, id } as Bill;
        dispatch({ type: 'UPDATE_BILL', payload: updatedBill });
      } else {
        handleError(response);
      }
    } catch (error) {
      handleError(error);
    }
  };

  const updateBillPayment = async (id: string, status: string, paymentData?: any) => {
    try {
      const response = await apiService.updateBillPayment(id, status, paymentData);
      
      if (response.success) {
        const updatedBill = { ...paymentData, id, status } as Bill;
        dispatch({ type: 'UPDATE_BILL', payload: updatedBill });
      } else {
        handleError(response);
      }
    } catch (error) {
      handleError(error);
    }
  };

  // Stats
  const fetchDashboardStats = async () => {
    try {
      dispatch({ type: 'SET_LOADING', payload: { key: 'stats', value: true } });
      const response = await apiService.getDashboardStats();
      
      if (response.success && response.data) {
        dispatch({ type: 'SET_STATS', payload: { key: 'dashboard', value: response.data } });
      } else {
        handleError(response);
      }
    } catch (error) {
      handleError(error);
    } finally {
      dispatch({ type: 'SET_LOADING', payload: { key: 'stats', value: false } });
    }
  };

  const fetchPatientStats = async () => {
    try {
      const response = await apiService.getPatientStats();
      
      if (response.success && response.data) {
        dispatch({ type: 'SET_STATS', payload: { key: 'patients', value: response.data } });
      } else {
        handleError(response);
      }
    } catch (error) {
      handleError(error);
    }
  };

  const fetchReportStats = async () => {
    try {
      const response = await apiService.getReportStats();
      
      if (response.success && response.data) {
        dispatch({ type: 'SET_STATS', payload: { key: 'reports', value: response.data } });
      } else {
        handleError(response);
      }
    } catch (error) {
      handleError(error);
    }
  };

  const fetchBillStats = async () => {
    try {
      const response = await apiService.getBillStats();
      
      if (response.success && response.data) {
        dispatch({ type: 'SET_STATS', payload: { key: 'bills', value: response.data } });
      } else {
        handleError(response);
      }
    } catch (error) {
      handleError(error);
    }
  };

  const clearError = () => {
    dispatch({ type: 'CLEAR_ERROR' });
  };

  const value: DataContextType = {
    ...state,
    fetchCenters,
    createCenter,
    updateCenter,
    fetchPatients,
    createPatient,
    updatePatient,
    findPatientByPasscode,
    fetchReports,
    createReport,
    updateReport,
    updateReportStatus,
    fetchBills,
    createBill,
    updateBill,
    updateBillPayment,
    fetchDashboardStats,
    fetchPatientStats,
    fetchReportStats,
    fetchBillStats,
    clearError,
  };

  return <DataContext.Provider value={value}>{children}</DataContext.Provider>;
};

export default DataContext;